import torch
from torch.nn.parallel import DistributedDataParallel as DDP
from addict import Dict as adict
import numpy as np
import os
from rl_utils.rewards import get_tokens_seq_from_token_ids
from rl_utils.rewards import self_critical_reward_triple
import torch.nn as nn
import logging

from pynvml import *
def print_gpu_utilization():
    nvmlInit()
    handle = nvmlDeviceGetHandleByIndex(0)
    info = nvmlDeviceGetMemoryInfo(handle)
    print(f"GPU memory occupied: {info.used//1024**2} MB.")

logger = logging.getLogger(__name__)
log = logger

from transformers import StoppingCriteria
class KeywordsStoppingCriteria(StoppingCriteria):
    def __init__(self, keywords_ids:list):
        self.keywords = keywords_ids

    def __call__(self, input_ids: torch.LongTensor, scores: torch.FloatTensor, **kwargs) -> bool:
        if input_ids[0][-1] in self.keywords:
            return True
        return False

def SCST4UNILM(model, source_ids, source_mask, source_token_type_ids, target_ids, tokenizer, pad_token_id, task_dict={}, schema_dict={}, **kargs):
    '''
    SCST forward pass
    https://github.com/IBM/regen/blob/main/model/model.py
    https://github.com/vklabmipt/implicit-unlikelihood-training/blob/master/src/once_reward_pg.py
    https://github.com/oceanypt/A-DEEP-REINFORCED-MODEL-FOR-ABSTRACTIVE-SUMMARIZATION/blob/master/nmt.RL.py
    '''
    
    # print(tokenizer.batch_decode(source_ids, skip_special_tokens=False, clean_up_tokenization_spaces=False), '=====')
    
    gen_model = model.module if isinstance(model, DDP) else model
    # gen_model = model

    max_length = target_ids.size(1)  # target_ids = [batch_size, seq_len]
    source_len = source_ids.shape[1]
    
    decoded_len = max_length + source_len + 2
    rank = int(os.environ.get("RANK", "0"))
    global_step = kargs.get('global_step', -1)
    if rank == 0 and np.mod(global_step, 1000) == 0:
        print(decoded_len, '===decoded_len===')

    gen_model.eval()
    torch.cuda.empty_cache()
    with torch.no_grad():
        # greedy max decode
        greedy_outputs = gen_model(input_ids=source_ids, input_mask=source_mask, segment_ids=source_token_type_ids, mode='generation',
                   output_scores=True, do_sample=False, max_length=decoded_len, num_beams=1, return_dict_in_generate=True,
                   early_stopping=True
                   )
    torch.cuda.empty_cache()
        
    gen_model.train()

    # prepare hypotheses
    greedy_seq = get_tokens_seq_from_token_ids(greedy_outputs.sequences[:, source_len:], tokenizer)
    target_seq = get_tokens_seq_from_token_ids(target_ids, tokenizer)  # "ground truth"
    source_seq = get_tokens_seq_from_token_ids(source_ids, tokenizer)  # "ground truth"
    
    # sampling
    sample_outputs = gen_model(input_ids=source_ids, input_mask=source_mask, segment_ids=source_token_type_ids, mode='sample',
                   output_scores=True, do_sample=True, max_length=decoded_len, num_beams=1, return_dict_in_generate=True,
                   early_stopping=True
                   )
    torch.cuda.empty_cache()

    # output: custom SamplingSeq2SeqLMOutput

    # We need the sequence of tokens... out of the fw sampling:
    # output.sequences : [batch_size, max_length]

    with torch.no_grad():
        # remove the first token (decoder_start_token_id) from the sampling_outputs.sequences
        sample_seq = tokenizer.batch_decode(sample_outputs.sequences[:, source_len:], skip_special_tokens=False, clean_up_tokenization_spaces=False)
        rewards = self_critical_reward_triple(source_seq, greedy_seq, target_seq, sample_seq, tokenizer, task_dict, schema_dict, exact_F1_weight=1.0, **kargs)
    
    # need to have logprobs
    logits = sample_outputs.scores  #(max_len, ) [max_len, batch*num_sequences, vocab_size]
    logits = torch.stack(logits, dim=1) # [batch*num_sequences, max_len, vocab_size]
    generated_ids = sample_outputs.sequences[:, source_len:] # [batch_num*num_sequences, max_len]
    
    lm_loss_fn = nn.CrossEntropyLoss(reduction='none').to(logits.device)
    word_loss = lm_loss_fn(logits.transpose(1, 2).float(), generated_ids)
    mask = (generated_ids != pad_token_id).float()  # [bs, max_length]
    
    """
    https://zhuanlan.zhihu.com/p/383585103
    https://github.com/oceanypt/A-DEEP-REINFORCED-MODEL-FOR-ABSTRACTIVE-SUMMARIZATION/blob/master/nmt.RL.py
    https://github.com/IBM/regen/blob/main/utils/model_sampling.py
    """
    #gen_probs = torch.gather(logprobs, 2, generated_ids[:, :, None]).squeeze(-1)  # [batch_num*num_sequences, max_len]

    reward = rewards['reward']
    reward = torch.from_numpy(reward).to(logits.device).float()  # [bs]
    reward = torch.unsqueeze(reward, 1)  # [bs, 1]
    
    # REINFORCE J(theta) for gradient descent
    """
    word_loss = cross_entropy_loss( scores.view(-1, scores.size(2)), sample_y.view(-1) ).view(scores.size(0), scores.size(1),1)
    word_loss = -word_loss * (reward_RL_base - reward_RL_sample) # + word_loss
    --> word_loss * (reward_RL_sample - reward_RL_base) # + word_loss
    reward = score_sample['f1'] - score_greedy['f1']
    https://github.com/oceanypt/A-DEEP-REINFORCED-MODEL-FOR-ABSTRACTIVE-SUMMARIZATION/blob/master/nmt.RL.py
    https://github.com/IBM/regen
    """
    scst_loss = word_loss * mask * reward
    loss = torch.sum(scst_loss) / (torch.sum(mask)+1e-10)
    
    rank = int(os.environ.get("RANK", "0"))
    global_step = kargs.get('global_step', -1)
    if rank == 0 and np.mod(global_step, 1000) == 0:
        logger.info(" epoch=%d, loss=%.5f, reward=%.5f, rand=%d ", global_step, loss.item(), torch.sum(reward).item(), rank)
        print('====device=====', word_loss.device, loss.device)

    output = adict()
    output.loss = loss
    output.reward = reward
    output.rewards = rewards

    return output