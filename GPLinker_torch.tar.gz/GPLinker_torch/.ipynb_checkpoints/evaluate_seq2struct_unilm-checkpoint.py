# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys, os
import numpy as np
import torch.nn as nn
from transformers import BertTokenizerFast
from utils.seq2struct_dataloader import (data_generator_single_schema, 
                                         load_ie_schema, load_ee_schema, load_entity_schema, 
                                         load_entity, load_duie, load_duee)
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
from multidataset_balanced_sampler import BalancedBatchSchedulerSampler
import logging
import torch
import io
import torch.nn.functional as F
import random
import numpy as np
import time
import math
import datetime
import torch.nn as nn
import logging
from torch.nn.modules.loss import _Loss
from tqdm import tqdm
from torch.utils.data.dataset import ConcatDataset

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
con.read('./config_unilm.ini', encoding='utf8')
# con.read('./config_unilm_large.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained('hfl/chinese-roberta-wwm-ext', do_lower_case=True)

print(tokenizer.tokenize('我是中国人[SEP]'))

class MyUniLM(nn.Module):
    def __init__(self, config_path, model_path, eos_token_id, **kargs):
        super().__init__()
        
        from nets.unilm_bert import BertForCausalLM
        from transformers import BertConfig

        self.model_path = model_path
        self.config_path = config_path
        self.eos_token_id = eos_token_id
        
        self.config = BertConfig.from_pretrained(config_path)
        self.config.is_decoder = True
        self.config.eos_token_id = self.eos_token_id
        
        self.transformer = BertForCausalLM.from_pretrained(
                                pretrained_model_name_or_path=model_path,
                                config=self.config)
        
    def forward(self, input_ids, input_mask, segment_ids=None, mode='train', **kargs):
        if mode == "train":
            idxs = torch.cumsum(segment_ids, dim=1)
            attention_mask_3d = (idxs[:, None, :] <= idxs[:, :, None]).to(dtype=torch.float32)
            model_outputs = self.transformer(input_ids, 
                                             attention_mask=attention_mask_3d, 
                                             token_type_ids=segment_ids)
            return model_outputs # return prediction-scores
        elif mode == "generation":
            model_outputs = self.transformer.generate(
                                            input_ids=input_ids, 
                                            attention_mask=input_mask, 
                                            token_type_ids=segment_ids, 
                                            **kargs) # we need to generate output-scors
        return model_outputs

duie_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'信息抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

duee_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'事件抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

entity_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'实体抽取',
    'sentinel_start_idx':1,
    'add_schema_type':False
}

schema = []
for schema_info in args_path["schema_data"].split(','):
    schema_type, schema_path = schema_info.split(':')
    print(schema_type, schema_path, '===schema-path===')
    if schema_type == 'duie':
        schema.extend(load_ie_schema(schema_path))
    elif schema_type == 'duee':
        schema.extend(load_ee_schema(schema_path))
    elif schema_type == 'entity':
        schema.extend(load_entity_schema(schema_path))
    
dev_data = {}
largest_size = 0
for label_index, data_info in enumerate(args_path["val_file"].split(',')):
    data_type, data_path = data_info.split(':')
    print(data_type, data_path, '==data-path==')
    if data_type == 'duee':
        load_fn = load_duee
        task_dict = duee_task_dict
    elif data_type == 'duie':
        load_fn = load_duie
        task_dict = duie_task_dict
    else:
        continue
    examples = load_fn(data_path)
    data_name = data_path.split('/')[-2]
    dev_data['{}&{}'.format(data_name, data_type)] = examples
    print(data_name, data_type, '=====')
    
    train_dataset = data_generator_single_schema(examples, tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, label=label_index,
                                                task_dict=task_dict, mode='debug', build_data=False)
    schema_dict = train_dataset.schema_dict

def search(pattern, sequence):
    """从sequence中寻找子串pattern
    如果找到，返回第一个下标；否则返回-1。
    """
    n = len(pattern)
    for i in range(len(sequence)):
        if sequence[i:i + n] == pattern:
            return i
    return -1

from collections import namedtuple
_DocSpan = namedtuple(  # pylint: disable=invalid-name
        "DocSpan", ["start", "length"])

def slide_window(all_doc_tokens, max_length, doc_stride, offset=32):
    doc_spans = []
    start_offset = 0
    while start_offset < len(all_doc_tokens):
        length = len(all_doc_tokens) - start_offset
        if length > max_length - offset:
            length = max_length - offset
        doc_spans.append(_DocSpan(start=start_offset, length=length))
        if start_offset + length == len(all_doc_tokens):
            break
        start_offset += min(length, doc_stride)
    return doc_spans

def extract(item, task_dict, all_schema_dict, target_type, max_len, data_type):
    text = item['text']
    
    # generate instruction input-ids
    instruction_text = task_dict['start_token'] + task_dict['instruction'] + task_dict['sep_token']
    encoder_instruction_text = tokenizer(instruction_text, return_offsets_mapping=True, max_length=max_len, truncation=True, add_special_tokens=False)
    instruction_input_ids = encoder_instruction_text["input_ids"]
    instruction_token_type_ids = encoder_instruction_text["token_type_ids"] #RoBERTa不需要NSP任务
    instruction_attention_mask = encoder_instruction_text["attention_mask"] #RoBERTa不需要NSP任务
    
    # generate input-ids
    encoder_text = tokenizer(text, return_offsets_mapping=True, truncation=False, add_special_tokens=False)
    input_ids = encoder_text["input_ids"]
    token_type_ids = encoder_text["token_type_ids"] #RoBERTa不需要NSP任务
    attention_mask = encoder_text["attention_mask"]

    # generate schema
    offset_mapping = encoder_text.offset_mapping
    schema_dict = all_schema_dict[target_type]
    if task_dict['add_schema_type']:
        schema_strings = target_type + task_dict['sep_token']
    else:
        schema_strings = ''
    key_list = list(schema_dict['role2sentinel'])
    
    # import random
    # if data_type == 'duee':
    #     random.shuffle(key_list)
    
    for role in key_list:
        schema_strings += role + schema_dict['role2sentinel'][role] # role sentinel

    schema_strings += task_dict['sep_token']

    encoder_schema_text = tokenizer(schema_strings, return_offsets_mapping=True, max_length=max_len, truncation=False, add_special_tokens=False)
    schema_input_ids = encoder_schema_text["input_ids"]
    schema_token_type_ids = encoder_schema_text["token_type_ids"] #RoBERTa不需要NSP任务
    schema_attention_mask = encoder_schema_text["attention_mask"]
        
    output_list = []
    doc_spans = slide_window(input_ids, max_len, 32, offset=0)
    for doc_span in doc_spans:
        span_start = doc_span.start
        span_end = doc_span.start + doc_span.length

        span_input_ids = input_ids[span_start:span_end] + tokenizer(task_dict['sep_token'], add_special_tokens=False)['input_ids']

        span_type_ids = [0] * len(span_input_ids)
        span_attention_mask = [1] * len(span_input_ids)
        output_list.append((offset_mapping, instruction_input_ids, span_input_ids, schema_input_ids, input_ids))
    return output_list

    
from utils.seq2struct_decoder import single_schema_decoder
decoder = single_schema_decoder(tokenizer, con.getint("para", "maxlen"), schema, label=0, 
                 task_dict=entity_task_dict, mode='train')

output_path = args_path['output_path']

print(output_path, '===============')

device = torch.device("cuda:0")
net = MyUniLM(config_path=args_path["config_path"], 
              model_path=args_path["model_path"], 
              eos_token_id=tokenizer.sep_token_id)
net.to(device)
eo = 9
try:
    ckpt = torch.load(os.path.join(output_path, 'unilm_mixture.pth.{}'.format(eo)))
    net.load_state_dict(ckpt)
except:
    ckpt = torch.load(os.path.join(output_path, 'unilm_mixture.pth.{}'.format(eo)))
    new_ckpt = {}
    for key in ckpt:
        name = key.split('.')
        new_ckpt[".".join(name[1:])] = ckpt[key]
    net.load_state_dict(new_ckpt)

# print(type(ckpt))


net.eval()

def evaluate_seq2struct_ie(net, data_key, data_list, schema_dict, data_type):
    data_name, data_type = data_key.split('&')
    task_dict = duie_task_dict
    
    dev_result_path = os.path.join(output_path, '{}_{}_dev.json'.format(data_key, eo))
    f = open(dev_result_path, 'w', encoding='utf-8')
    
    X, Y, Z = 0.0, 0.0, 0.0
    pbar = tqdm()
    
    for i, data in enumerate(data_list):
        T = set()
        R = set()
        target_type_set = set()
        for target in data['target_list']:
            target_type = target['type']
            target_type_set.add(target_type)
            spo_subject = set()
            spo_object = set()
            for role_dict in target['role_list']:
                if role_dict['type'] == 'subject-':
                    spo_subject.add(('subject', role_dict['role'], role_dict['argument']))
                else:
                    spo_object.add(('object', role_dict['role'], role_dict['argument']))
            for subject in list(spo_subject):
                for object_ in list(spo_object):
                    T.add((target_type,)+subject+object_)
                    
        for target_type in target_type_set:            
            # [('丈夫', '人物', '赵楚'), ('丈夫', '人物', '柳思孝')]
            output_list = extract(data, task_dict, train_dataset.schema_dict, target_type, max_len=con.getint("para", "maxlen"), data_type=data_type)
            for output_input in output_list:
                (offset_mapping, instruction_input_ids, input_ids, schema_input_ids, ori_input_ids) = output_input
                text = data['text']

                query_token_ids = instruction_input_ids + input_ids + schema_input_ids

                batch_token_ids = torch.tensor(query_token_ids).long().unsqueeze(0).to(device)
                batch_mask_ids = torch.tensor([1] * len(query_token_ids)).long().unsqueeze(0).to(device)
                batch_token_type_ids = torch.tensor([0] * len(query_token_ids)).long().unsqueeze(0).to(device)
                
                from nets.constrained_decoder import get_end_to_end_prefix_allowed_tokens_fn_hf
                prefix_allowed_tokens_fn = get_end_to_end_prefix_allowed_tokens_fn_hf(input_ids, task_dict, tokenizer)

                model_outputs = net(input_ids=batch_token_ids, input_mask=batch_mask_ids, segment_ids=batch_token_type_ids, mode='generation',
                       output_scores=True, do_sample=False, max_length=1024, num_beams=2, return_dict_in_generate=True,
                                   prefix_allowed_tokens_fn=prefix_allowed_tokens_fn
                                   )
                decode_output_list = decoder.single_schema_decode(text, offset_mapping, target_type, model_outputs, query_token_ids, ori_input_ids, mode='unilm')

                for output in decode_output_list:
                    # [('退赛', '触发词', '伤退'), ('退赛', '退赛方', '考辛斯')]
                    spo_subject_pred = set()
                    spo_object_pred = set()
                    if len(output) >= 2:
                        target_type_pred = output[0][0]
                        spo_subject_pred.add(('subject', output[0][1], output[0][2]))
                        for object_ in output[1:]:
                            spo_object_pred.add(('object', object_[1], object_[2]))
                        for subject in spo_subject_pred:
                            for object_ in spo_object_pred:
                                R.add((target_type_pred,)+subject+object_)
        
        X += len(R & T)
        Y += len(R)
        Z += len(T)
        
        s = json.dumps({
            'text': data['text'],
            'spo_list': list(T),
            'spo_list_pred': list(R),
            'new': list(R - T),
            'lack': list(T - R),
            'id':data.get('id', i)
        },
           ensure_ascii=False,
           indent=4)
        f.write(s + '\n')

        f1, precision, recall = 2 * X / (Y + Z + 1e-10), X / (Y+1e-10), X / (Z+1e-10)

        pbar.update()
        pbar.set_description(
            'f1: %.5f, precision: %.5f, recall: %.5f, data-key=%s' % (f1, precision, recall, data_key)
        )
        
    f1, precision, recall = 2 * X / (Y + Z + 1e-10), X / (Y+1e-10), X / (Z+1e-10)
    pbar.close()
    f.close()
    return f1, precision, recall

def evaluate_seq2struct_ee(net, data_key, data_list, schema_dict, data_type):
    data_name, data_type = data_key.split('&')
    task_dict = duee_task_dict
    X, Y, Z = 0.0, 0.0, 0.0
    pbar = tqdm()
    
    dev_result_path = os.path.join(output_path, '{}_{}_dev.json'.format(data_key, eo))
    f = open(dev_result_path, 'w', encoding='utf-8')

    for i, data in enumerate(data_list):
        T = set()
        R = set()
        target_type_set = set()
        for target in data['target_list']:
            target_type = target['type']
            target_type_set.add(target_type)
            for role_dict in target['role_list']:
                if role_dict['role'] != '触发词':
                    T.add((target_type, role_dict['role'], role_dict['argument']))
        
        decoded_list = []
        for target_type in target_type_set:
            output_list = extract(data, task_dict, train_dataset.schema_dict, target_type, max_len=con.getint("para", "maxlen"), data_type=data_type)
            for output_input in output_list:            
                (offset_mapping, instruction_input_ids, input_ids, schema_input_ids, ori_input_ids) = output_input
                text = data['text']

                query_token_ids = instruction_input_ids + input_ids + schema_input_ids
                
                from nets.constrained_decoder import get_end_to_end_prefix_allowed_tokens_fn_hf
                prefix_allowed_tokens_fn = get_end_to_end_prefix_allowed_tokens_fn_hf(input_ids, task_dict, tokenizer)

                batch_token_ids = torch.tensor(query_token_ids).long().unsqueeze(0).to(device)
                batch_mask_ids = torch.tensor([1] * len(query_token_ids)).long().unsqueeze(0).to(device)
                batch_token_type_ids = torch.tensor([0] * len(query_token_ids)).long().unsqueeze(0).to(device)

                model_outputs = net(input_ids=batch_token_ids, input_mask=batch_mask_ids, segment_ids=batch_token_type_ids, mode='generation',
                       output_scores=True, do_sample=False, max_length=1024, num_beams=2, return_dict_in_generate=True,
                        prefix_allowed_tokens_fn=prefix_allowed_tokens_fn
                       )

#                 batch_token_ids = torch.tensor(query_token_ids).long().unsqueeze(0).to(device)
#                 batch_mask_ids = torch.tensor([1] * len(query_token_ids)).long().unsqueeze(0).to(device)
#                 batch_token_type_ids = torch.tensor([0] * len(query_token_ids)).long().unsqueeze(0).to(device)

#                 model_outputs = net(input_ids=batch_token_ids, input_mask=batch_mask_ids, segment_ids=batch_token_type_ids, mode='generation',
#                        output_scores=True, do_sample=False, max_length=1024, num_beams=2, return_dict_in_generate=True)
                decode_output_list = decoder.single_schema_decode(text, offset_mapping, target_type, model_outputs, query_token_ids, ori_input_ids, mode='unilm')
                decoded_list.append(decode_output_list)
                for output in decode_output_list:
                    # [('退赛', '触发词', '伤退'), ('退赛', '退赛方', '考辛斯')]
                    for item in output:
                        if item[1] == '触发词':
                            continue
                        R.add((item[0], item[1], item[2]))
        
        X += len(R & T)
        Y += len(R)
        Z += len(T)
        
        s = json.dumps({
            'text': data['text'],
            'spo_list': list(T),
            'spo_list_pred': list(R),
            'new': list(R - T),
            'lack': list(T - R),
            'id':data.get('id', i)
        },
           ensure_ascii=False,
           indent=4)
        f.write(s + '\n')

        f1, precision, recall = 2 * X / (Y + Z + 1e-10), X / (Y+1e-10), X / (Z+1e-10)

        pbar.update()
        pbar.set_description(
            'f1: %.5f, precision: %.5f, recall: %.5f, data-key=%s' % (f1, precision, recall, data_key)
        )
        
    f1, precision, recall = 2 * X / (Y + Z + 1e-10), X / (Y+1e-10), X / (Z+1e-10)
    pbar.close()
    f.close()
    return f1, precision, recall

for data_key in dev_data:
    print("==dev_data key==", data_key)
    data_name, data_type = data_key.split('&')
    if data_type == 'duie':
        f1, precision, recall = evaluate_seq2struct_ie(net, data_key, dev_data[data_key], schema_dict, data_type)
        results_dict = {
            'f1':f1,
            'precision':precision,
            'recall':recall,
            'data_key':data_key
        }
        print(json.dumps(results_dict, ensure_ascii=False))
        logger.info("results of data_key: %s, results: %s" %
                    (data_key, json.dumps(results_dict, ensure_ascii=False)))
    elif data_type == 'duee':
        f1, precision, recall = evaluate_seq2struct_ee(net, data_key, dev_data[data_key], schema_dict, data_type)
        results_dict = {
            'f1':f1,
            'precision':precision,
            'recall':recall,
            'data_key':data_key
        }
        print(json.dumps(results_dict, ensure_ascii=False))
        logger.info("results of data_key: %s, results: %s" %
                    (data_key, json.dumps(results_dict, ensure_ascii=False)))
