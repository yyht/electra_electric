# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys, os
import numpy as np
import torch.nn as nn
from transformers import BertTokenizerFast
from utils.seq2struct_dataloader import (data_generator_single_schema, 
                                         load_ie_schema, load_ee_schema, load_entity_schema, 
                                         load_entity, load_duie, load_duee)
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
from multidataset_balanced_sampler import BalancedBatchSchedulerSampler
import logging
import torch
import io
import torch.nn.functional as F
import random
import numpy as np
import time
import math
import datetime
import torch.nn as nn
import logging
from torch.nn.modules.loss import _Loss
from tqdm import tqdm
from torch.utils.data.dataset import ConcatDataset
import random
from nets import constrained_decoder

prefix_allowed_tokens_fn=lambda batch_id, sent: trie.get(sent.tolist())

class LabelSmoothingLoss(_Loss):
    """
    With label smoothing,
    KL-divergence between q_{smoothed ground truth prob.}(w)
    and p_{prob. computed by model}(w) is minimized.
    """

    def __init__(self, label_smoothing=0, tgt_vocab_size=0, ignore_index=0, size_average=None, reduce=None, reduction='mean'):
        assert 0.0 < label_smoothing <= 1.0
        self.ignore_index = ignore_index
        super(LabelSmoothingLoss, self).__init__(
            size_average=size_average, reduce=reduce, reduction=reduction)

        assert label_smoothing > 0
        assert tgt_vocab_size > 0

        smoothing_value = label_smoothing / (tgt_vocab_size - 2)
        one_hot = torch.full((tgt_vocab_size,), smoothing_value)
        one_hot[self.ignore_index] = 0
        self.register_buffer('one_hot', one_hot.unsqueeze(0))
        self.confidence = 1.0 - label_smoothing
        self.tgt_vocab_size = tgt_vocab_size

    def forward(self, output, target):
        """
        output (FloatTensor): batch_size * num_pos * n_classes
        target (LongTensor): batch_size * num_pos
        """
        assert self.tgt_vocab_size == output.size(2)
        batch_size, num_pos = target.size(0), target.size(1)
        output = output.view(-1, self.tgt_vocab_size)
        target = target.reshape(-1)
        model_prob = self.one_hot.float().repeat(target.size(0), 1).to(output.device)
        model_prob.scatter_(1, target.unsqueeze(1), self.confidence)
        model_prob.masked_fill_((target == self.ignore_index).unsqueeze(1), 0)

        return F.kl_div(output, model_prob, reduction='none').view(batch_size, num_pos, -1).sum(2)

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
con.read('./config_unilm.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained('hfl/chinese-roberta-wwm-ext', do_lower_case=True)

print(tokenizer.tokenize('我是中国人[SEP]'))

class MyUniLM(nn.Module):
    def __init__(self, config_path, model_path, eos_token_id, **kargs):
        super().__init__()
        
        from nets.unilm_bert import BertForCausalLM
        from transformers import BertConfig

        self.model_path = model_path
        self.config_path = config_path
        self.eos_token_id = eos_token_id
        
        self.config = BertConfig.from_pretrained(config_path)
        self.config.is_decoder = True
        self.config.eos_token_id = self.eos_token_id
        
        self.transformer = BertForCausalLM.from_pretrained(
                                pretrained_model_name_or_path=model_path,
                                config=self.config)
        
    def forward(self, input_ids, input_mask, segment_ids=None, mode='train', **kargs):
        if mode == "train":
            idxs = torch.cumsum(segment_ids, dim=1)
            attention_mask_3d = (idxs[:, None, :] <= idxs[:, :, None]).to(dtype=torch.float32)
            model_outputs = self.transformer(input_ids, 
                                             attention_mask=attention_mask_3d, 
                                             token_type_ids=segment_ids)
            return model_outputs # return prediction-scores
        elif mode == "generation":
            model_outputs = self.transformer.generate(
                                            input_ids=input_ids, 
                                            attention_mask=input_mask, 
                                            token_type_ids=segment_ids, 
                                            **kargs) # we need to generate output-scors
        elif mode == 'sample':
            model_outputs = self.transformer.sample(
                                            input_ids=input_ids, 
                                            attention_mask=input_mask, 
                                            token_type_ids=segment_ids, 
                                            **kargs) # we need to generate output-scors
        return model_outputs

duie_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'信息抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

duee_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'事件抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

entity_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'实体抽取',
    'sentinel_start_idx':1,
    'add_schema_type':False
}

schema = []
for schema_info in args_path["schema_data"].split(','):
    schema_type, schema_path = schema_info.split(':')
    print(schema_type, schema_path, '===schema-path===')
    if schema_type == 'duie':
        schema.extend(load_ie_schema(schema_path))
    elif schema_type == 'duee':
        schema.extend(load_ee_schema(schema_path))
    elif schema_type == 'entity':
        schema.extend(load_entity_schema(schema_path))
        
total_train_dataset = []
largest_size = 0
for label_index, data_info in enumerate(args_path["train_file"].split(',')):
    data_type, data_path = data_info.split(':')
    print(data_type, data_path, '==data-path==')
    if data_type == 'duie' and 'ASA' in data_path:
        load_fn = load_duie
        task_dict = duie_task_dict
        
        examples = load_fn(data_path)
    
        train_dataset = data_generator_single_schema(load_fn(data_path), tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, label=label_index,
                                                task_dict=task_dict, mode='debug')
        break
        
#     if data_type == 'duee':
#         load_fn = load_duee
#         task_dict = duee_task_dict
#         examples = load_fn(data_path)
    
#         train_dataset = data_generator_single_schema(load_fn(data_path), tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, label=label_index,
#                                                 task_dict=task_dict, mode='debug')
#         break
#     if data_type == 'entity':
#         load_fn = load_entity
#         task_dict = entity_task_dict
#         examples = load_fn(data_path)
    
#         train_dataset = data_generator_single_schema(load_fn(data_path), tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, label=label_index,
#                                                 task_dict=task_dict, mode='debug')
#         break

text = examples[0]['text']
max_len = 256

def search(pattern, sequence):
    """从sequence中寻找子串pattern
    如果找到，返回第一个下标；否则返回-1。
    """
    n = len(pattern)
    for i in range(len(sequence)):
        if sequence[i:i + n] == pattern:
            return i
    return -1

from collections import namedtuple
_DocSpan = namedtuple(  # pylint: disable=invalid-name
        "DocSpan", ["start", "length"])

def slide_window(all_doc_tokens, max_length, doc_stride, offset=32):
    doc_spans = []
    start_offset = 0
    while start_offset < len(all_doc_tokens):
        length = len(all_doc_tokens) - start_offset
        if length > max_length - offset:
            length = max_length - offset
        doc_spans.append(_DocSpan(start=start_offset, length=length))
        if start_offset + length == len(all_doc_tokens):
            break
        start_offset += min(length, doc_stride)
    return doc_spans

def extract_debug(item, task_dict, all_schema_dict, max_len):
    text = item['text']
    
    encoder_instruction_text = tokenizer(task_dict['instruction'], return_offsets_mapping=True, max_length=max_len, truncation=True)
    instruction_input_ids = encoder_instruction_text["input_ids"]
    instruction_token_type_ids = encoder_instruction_text["token_type_ids"] #RoBERTa不需要NSP任务
    instruction_attention_mask = encoder_instruction_text["attention_mask"] #RoBERTa不需要NSP任务

    encoder_text = tokenizer(text, return_offsets_mapping=True, max_length=max_len, truncation=True)
    input_ids = encoder_text["input_ids"]
    token_type_ids = encoder_text["token_type_ids"] #RoBERTa不需要NSP任务
    attention_mask = encoder_text["attention_mask"]

    offset_mapping = encoder_text.offset_mapping
    
    total_target_dict = {}
    for target_dict in item['target_list']:
        target_type = target_dict['type']
        if target_type not in total_target_dict:
            total_target_dict[target_type] = []
        total_target_dict[target_type].append(target_dict['role_list'])

    output_list = []
    for target_type in total_target_dict:
        schema_dict = all_schema_dict[target_type]
        if task_dict['add_schema_type']:
            schema_strings = target_type + task_dict['sep_token']
        else:
            schema_strings = ''
        random.shuffle(schema_dict['role2sentinel'])
        for role in schema_dict['role2sentinel']:
            schema_strings += role + schema_dict['role2sentinel'][role] # role sentinel

        encoder_schema_text = tokenizer(schema_strings, return_offsets_mapping=True, max_length=max_len, truncation=False)
        schema_input_ids = encoder_schema_text["input_ids"]
        schema_token_type_ids = encoder_schema_text["token_type_ids"] #RoBERTa不需要NSP任务
        schema_attention_mask = encoder_schema_text["attention_mask"]

        target_strings = ''
        for role_list in total_target_dict[target_type]:
            for role_dict in role_list:
                argument_start_index = role_dict.get('argument_start_index', -1)
                role_type = role_dict['type'] + role_dict['role']
                argument = role_dict['argument']
                if argument_start_index != -1:
                    start, end = argument_start_index, argument_start_index + len(role_dict['argument']) - 1
                    start_t, end_t = char_span_to_token_span(char2token, (start, end+1))
                    if input_ids[start_t:end_t]:
                        target_strings += argument + schema_dict['role2sentinel'][role_type]
                else:
                    arguemnt_ids = tokenizer.encode(argument, add_special_tokens=False)
                    sh = search(arguemnt_ids, input_ids)
                    if sh != -1:
                        target_strings += argument + schema_dict['role2sentinel'][role_type]

            if target_strings:
                target_strings += task_dict['group_token']

        encoder_target_text = tokenizer(target_strings, return_offsets_mapping=True, max_length=max_len, truncation=False)
        target_input_ids = encoder_target_text["input_ids"]
        target_token_type_ids = encoder_target_text["token_type_ids"] #RoBERTa不需要NSP任务
        target_attention_mask = encoder_target_text["attention_mask"]
        output_list.append((offset_mapping, instruction_input_ids, input_ids, schema_input_ids, target_input_ids))
    return output_list

# def extract(item, task_dict, all_schema_dict, target_type, max_len):
#     text = item['text']
    
#     encoder_instruction_text = tokenizer(task_dict['instruction'], return_offsets_mapping=True, max_length=max_len, truncation=True)
#     instruction_input_ids = encoder_instruction_text["input_ids"]
#     instruction_token_type_ids = encoder_instruction_text["token_type_ids"] #RoBERTa不需要NSP任务
#     instruction_attention_mask = encoder_instruction_text["attention_mask"] #RoBERTa不需要NSP任务

#     encoder_text = tokenizer(text, return_offsets_mapping=True, max_length=max_len, truncation=True)
#     input_ids = encoder_text["input_ids"]
#     token_type_ids = encoder_text["token_type_ids"] #RoBERTa不需要NSP任务
#     attention_mask = encoder_text["attention_mask"]

#     offset_mapping = encoder_text.offset_mapping
#     schema_dict = all_schema_dict[target_type]
#     if task_dict['add_schema_type']:
#         schema_strings = target_type + task_dict['sep_token']
#     else:
#         schema_strings = ''
#     for role in schema_dict['role2sentinel']:
#         schema_strings += role + schema_dict['role2sentinel'][role] # role sentinel
#     encoder_schema_text = tokenizer(schema_strings, return_offsets_mapping=True, max_length=max_len, truncation=False)
#     schema_input_ids = encoder_schema_text["input_ids"]
#     schema_token_type_ids = encoder_schema_text["token_type_ids"] #RoBERTa不需要NSP任务
#     schema_attention_mask = encoder_schema_text["attention_mask"]

#     output_list = []
#     output_list.append((offset_mapping, instruction_input_ids, input_ids, schema_input_ids))
#     return output_list

def extract(item, task_dict, all_schema_dict, target_type, max_len):
    text = item['text']
    
    # generate instruction input-ids
    instruction_text = task_dict['start_token'] + task_dict['instruction'] + task_dict['sep_token']
    encoder_instruction_text = tokenizer(instruction_text, return_offsets_mapping=True, max_length=max_len, truncation=True, add_special_tokens=False)
    instruction_input_ids = encoder_instruction_text["input_ids"]
    instruction_token_type_ids = encoder_instruction_text["token_type_ids"] #RoBERTa不需要NSP任务
    instruction_attention_mask = encoder_instruction_text["attention_mask"] #RoBERTa不需要NSP任务
    
    # generate input-ids
    encoder_text = tokenizer(text, return_offsets_mapping=True, truncation=True, add_special_tokens=False)
    input_ids = encoder_text["input_ids"]
    token_type_ids = encoder_text["token_type_ids"] #RoBERTa不需要NSP任务
    attention_mask = encoder_text["attention_mask"]

    # generate schema
    offset_mapping = encoder_text.offset_mapping
    schema_dict = all_schema_dict[target_type]
    if task_dict['add_schema_type']:
        schema_strings = target_type + task_dict['sep_token']
    else:
        schema_strings = ''
    key_list = list(schema_dict['role2sentinel'])
    # random.shuffle(key_list)
    # for role in schema_dict['role2sentinel']:
    for index, role in enumerate(key_list):
        # schema_strings += role + '[unused{}]'.format(index+1)
        schema_strings += role + schema_dict['role2sentinel'][role] # role sentinel

    schema_strings += task_dict['sep_token']
    
    print(schema_strings, '====')

    encoder_schema_text = tokenizer(schema_strings, return_offsets_mapping=True, max_length=max_len, truncation=False, add_special_tokens=False)
    schema_input_ids = encoder_schema_text["input_ids"]
    schema_token_type_ids = encoder_schema_text["token_type_ids"] #RoBERTa不需要NSP任务
    schema_attention_mask = encoder_schema_text["attention_mask"]
        
    output_list = []
    doc_spans = slide_window(input_ids, max_len, 16, offset=0)
    for doc_span in doc_spans:
        span_start = doc_span.start
        span_end = doc_span.start + doc_span.length

        span_input_ids = input_ids[span_start:span_end] + tokenizer(task_dict['sep_token'], add_special_tokens=False)['input_ids']

        span_type_ids = [0] * len(span_input_ids)
        span_attention_mask = [1] * len(span_input_ids)
        output_list.append((offset_mapping, instruction_input_ids, span_input_ids, schema_input_ids, input_ids))
    return output_list

def extract(item, task_dict, all_schema_dict, target_type, max_len):
    text = item['text']
    
    # generate instruction input-ids
    instruction_text = task_dict['start_token'] + task_dict['instruction'] + task_dict['sep_token']
    encoder_instruction_text = tokenizer(instruction_text, return_offsets_mapping=True, max_length=max_len, truncation=False, add_special_tokens=False)
    instruction_input_ids = encoder_instruction_text["input_ids"]
    instruction_token_type_ids = encoder_instruction_text["token_type_ids"] #RoBERTa不需要NSP任务
    instruction_attention_mask = encoder_instruction_text["attention_mask"] #RoBERTa不需要NSP任务
    
    # generate input-ids
    encoder_text = tokenizer(text, return_offsets_mapping=True, truncation=False, add_special_tokens=False)
    input_ids = encoder_text["input_ids"]
    token_type_ids = encoder_text["token_type_ids"] #RoBERTa不需要NSP任务
    attention_mask = encoder_text["attention_mask"]

    # generate schema
    offset_mapping = encoder_text.offset_mapping
    schema_dict = all_schema_dict[target_type]
    if task_dict['add_schema_type']:
        schema_strings = target_type + task_dict['sep_token']
    else:
        schema_strings = ''
    for role in schema_dict['role2sentinel']:
        schema_strings += role + schema_dict['role2sentinel'][role] # role sentinel

    schema_strings += task_dict['sep_token']

    encoder_schema_text = tokenizer(schema_strings, return_offsets_mapping=True, max_length=max_len, truncation=False, add_special_tokens=False)
    schema_input_ids = encoder_schema_text["input_ids"]
    schema_token_type_ids = encoder_schema_text["token_type_ids"] #RoBERTa不需要NSP任务
    schema_attention_mask = encoder_schema_text["attention_mask"]
        
    output_list = []
    doc_spans = slide_window(input_ids, max_len, 16, offset=0)
    for doc_span in doc_spans:
        span_start = doc_span.start
        span_end = doc_span.start + doc_span.length

        span_input_ids = input_ids[span_start:span_end] + tokenizer(task_dict['sep_token'], add_special_tokens=False)['input_ids']

        span_type_ids = [0] * len(span_input_ids)
        span_attention_mask = [1] * len(span_input_ids)
        output_list.append((offset_mapping, instruction_input_ids, span_input_ids, schema_input_ids, input_ids))
    return output_list

def flat_list(h_list):
    e_list = []

    for item in h_list:
        if isinstance(item, list):
            e_list.extend(flat_list(item))
        else:
            e_list.append(item)
    return e_list

import numpy as np
def sequence_padding(inputs, length=None, value=0, seq_dims=1, mode='post'):
    """Numpy函数，将序列padding到同一长度
    """
    if length is None:
        length = np.max([np.shape(x)[:seq_dims] for x in inputs], axis=0)
    elif not hasattr(length, '__getitem__'):
        length = [length]

    slices = [np.s_[:length[i]] for i in range(seq_dims)]
    slices = tuple(slices) if len(slices) > 1 else slices[0]
    pad_width = [(0, 0) for _ in np.shape(inputs[0])]

    outputs = []
    for x in inputs:
        x = x[slices]
        for i in range(seq_dims):
            if mode == 'post':
                pad_width[i] = (0, length[i] - np.shape(x)[i])
            elif mode == 'pre':
                pad_width[i] = (length[i] - np.shape(x)[i], 0)
            else:
                raise ValueError('"mode" argument must be "post" or "pre".')
        x = np.pad(x, pad_width, 'constant', constant_values=value)
        outputs.append(x)
    return np.array(outputs)

# output_list = extract_debug(examples[0], duie_task_dict, train_dataset.schema_dict, max_len)
# print(output_list)

# (offset_mapping, instruction_input_ids, input_ids, schema_input_ids, target_input_ids) = output_list[0]
# ori_input_ids = input_ids
    
from utils.seq2struct_decoder import single_schema_decoder
decoder = single_schema_decoder(tokenizer, 256, schema, label=0, 
                 task_dict=entity_task_dict, mode='train')

# all_token_ids = instruction_input_ids + input_ids[1:] + schema_input_ids[1:] + target_input_ids[1:]
# query_token_ids = instruction_input_ids + input_ids[1:] + schema_input_ids[1:]

# print(tokenizer.decode(all_token_ids), tokenizer.decode(query_token_ids))

# from collections import namedtuple
# Result = namedtuple('Result', ['sequences'])
# result_dict = Result(sequences=[all_token_ids])

# print(decoder.single_schema_decode(text, offset_mapping, '正向情感', result_dict, query_token_ids, input_ids, mode='unilm'))

output_path = args_path['output_path']

device = torch.device("cuda:0")
net = MyUniLM(config_path=args_path["config_path"], 
              model_path=args_path["model_path"], 
              eos_token_id=tokenizer.sep_token_id)
net.to(device)

# output_path = '/data/albert.xht/unilm/unilm_roberta_base_mixture'
eo = 9
try:
    ckpt = torch.load(os.path.join(output_path, 'unilm_mixture.pth.{}'.format(eo)))
    net.load_state_dict(ckpt)
except:
    ckpt = torch.load(os.path.join(output_path, 'unilm_mixture.pth.{}'.format(eo)))
    new_ckpt = {}
    for key in ckpt:
        name = key.split('.')
        new_ckpt[".".join(name[1:])] = ckpt[key]
    net.load_state_dict(new_ckpt)
net.eval()

item = {"id": "c1800be3a5e634d7ce22e1d72dd36950", "schema": "体育竞赛", "text": "考辛斯伤退喜庆大婚，霍化德借机上位，考辛斯的职业生涯要凉凉"}
item = {"id": "c7488883e8032277113dbb032b69a018", "schema": "人生信息", "text": "杨坚的几个儿子：长子房陵王杨勇次子隋炀帝杨广（604年—618年在位）三子秦王杨俊四子蜀王杨秀五子汉王杨谅"}
item = {"id": "307ea217cb07537e0aa86db85b867594", "schema": "人生信息", "text": "唐高祖武德九年六月初四庚申日(公元626年7月2日)由当时的秦王、唐高祖李渊的次子李世民在唐帝国的首都长安城(今陕西省西安市)大内皇宫的北宫门——玄武门附近发动的一次流血政变,结果李世民杀死了自己的长兄（当时的皇太子李建成）和四弟（当时的齐王李元吉），得立为新任皇太子，并继承皇帝位，是为唐太宗，年号贞观 我们的故事就从这里开始"}
# item = {"id": "4c9a3834263ae03a0aecb5952526679c", "schema": "人生信息", "text": "年轻的霍震霆与朱玲玲的合照无论是出于何种原因原因使一段惊动全港的婚姻走向衰亡，都令人有人遗憾，不过，如今朱玲玲已经在2008年11月27日在新加坡与苦恋八年的罗康瑞注册结婚，这段经历过长跑的爱情，使朱玲玲再度尝到了爱情的甜蜜，在出席慧妍雅集慈善晚会时，朱玲玲甜蜜牵着老公罗康瑞大秀幸福，朱玲玲穿着一袭吊带长裙出席晚会，高贵大方，她与丈夫罗康瑞前后脚到场，脸上洋溢着幸福的笑容，或许爱情会迟到但真的不会缺席"}

# item = {"id": "feb697ebe6a2cbca4628bc4d35a78c67", "schema": "体育竞赛", "text": "17日，北京冬奥会自由式滑雪女子U型场地技巧资格赛中国队选手谷爱凌、张可欣、李方慧成功晋级决赛姑娘们好样的△谷爱凌第1跳获得93.75分，为第一轮最高分△谷爱凌第2跳获得95.5分，为全场最高分△张可欣△李方慧明天上午决赛一起为姑娘们加油！"}
# item = {"id": "2b4dcbec356da97aa30fdab482fdfdcc", "schema": "体育竞赛", "text": "今天上午在北京冬奥会自由式滑雪女子大跳台决赛夺中谷爱凌得金牌！"}
# item = {"id": "23f8115cfbb966f6f52b140cc45e3383", "schema": "金融信息", "text": "市场消息：桥水基金二季度减持特斯拉，减持比例为44%。\n市场消息：桥水基金二季度减持特斯拉，减持比例为44%。\n广告黄金原油外汇指数，一对一跟单合作指导，咨询添加微信: zj66890\n【湖北连发69条高温预警】今天，湖北气象局连发69条高温黄色预警。"}
item = {"id": "37c604c450d57cce8a5c8eb69844ec97", "schema": "金融信息", "text": "华仪电气再次中标国网项目3个标包\n原标题：华仪电气再次中标国网项目3个标包    来源：e公司\n据华仪电气消息，7月2日，华仪电气成套事业部在国家电网有限公司输变电项目2020年第一次35-220千伏设备协议库存招标采购中，一举中得3个标包，中标产品包括高压开关柜KYN61和高压开关柜KYN28-12，合计中标金额约为4819万元。\n（文章来源：e公司）"}

# item = {"id": "ed8fe83ebd6e3b28007c607735dc009c", "schema": "金融信息", "text": "教育部就“高考个别阅卷人涉嫌泄露考生作答等情况”约谈浙江省教育考试院：立即调查，严肃处理\n教育部官网8月21日消息，近日，媒体报道浙江省2020年高考个别阅卷人员涉嫌泄露考生作答情况、擅自使用评卷信息，个别命题教师涉嫌参与社会机构培训等。\n浙江省高考为自主命题，教育部考试中心第一时间约谈浙江省教育考试院，要求立即开展调查，依法依规严肃处理。\n高考评卷和命题工作事关考试公平和广大考生切身利益，教育部高度重视，对相关工作建立了严格的制度规范，明确规定阅卷教师不得擅自将评卷情况、考生作答情况外传等“十六个不得”；明确规定命题教师不得暴露本人身份，不得以命题教师的名义参加有关高考的补习、辅导、讲座、编写复习资料、发表文章等工作纪律。"}

# item = {"id": "09df6856078d469f1105586de607962a", "schema": "金融信息", "text": "皇家彩计划：滴滴美团非法网约车长期存在 被南京多部门约谈\n皇家彩计划：滴滴美团非法网约车长期存在 被南京多部门约谈 江苏广播电视网皇家彩计划\n“工欲善其事，必先利其器”，同样，欲善脱贫之“事”，就要先利脱贫之“器”，选派“精锐部队”尽锐出战，既能彰显与贫穷和困难“势不两立”的决心，更能体。\n现关心弱势群体、体恤。"}

# # item = {"id": "527607bdc0ec8cd667068065c3fad6bd", "schema": "金融信息", "text": "中国电信2019年CN2-DCI网络业务路由器扩容集采：华为、思科中标\n【基金经理PK：董承非、傅鹏博、朱少醒、刘彦春等，谁更值得托付？\n】买基金就是选基金经理，什么样的基金经理值得托付？\n哪些基金经理值得你托付？"}
# item = {"id": "910713a8a173fe3ffe83c59ab36348cf", "schema": "金融信息", "text": "江阴银行上半年业绩稳步增长 超20%股权质押引关注\n江阴银行上半年业绩稳步增长 超20%股权质押引关注 原标题：江阴银行(4.480,0.11,2.52%)上半年业绩稳步增长 超20%股权质押引关注    来源：中国网财经\n中国网财经8月8日讯(记者 曾蔷) 江阴银行于近日披露A股上市银行首份半年度报告。\n报告显示，截至2019年6月末，江阴银行的总资产达到1253.95亿元，较2018年末增加9.18%；各项贷款总额675.12亿元，较年初增长45.26亿元，增幅7.19%；各项存款总额880.75亿元，较年初增长33.16亿元，增幅3.91%。"}

# item = {"id": "fadba4de0a0752c2eab1be3e9592ec99", "schema": "金融信息", "text": "蓝思科技（300433）4月9日晚间披露的2019年第一季度业绩预告显示，公司预计今年一季度实现归属净利润为-7697.78万元至-1.1亿元，同比由盈转亏。"}
# item = {"id": "5531d7e005dcb989965233b8f2f4a3c7", "schema": "金融信息", "text": "通威股份控股股东解除质押及再质押4000万股\n原标题：通威股份(14.270,-0.02,-0.14%)控股股东解除质押及再质押4000万股    来源：格隆汇\n格隆汇9月19日丨通威股份(600438.SH)公布，公司控股股东通威集团于2019年9月18日将质押给中信银行(5.720,0.01,0.18%)股份有限公司成都分行的4000万股无限售条件流通股解除质押，同时将4000万股无限售条件流通股继续质押给中信银行股份有限公司成都分行。\n上述事宜已在中国证券登记结算有限责任公司办理完相关手续。"}

# item = {"id": "90586431beb7b1a49e30bd7ae522ebbf", "schema": "影视情感", "text": "A:你喜欢看电影吗？B:喜欢。A:那你有看过今年上映的一个电影斗鱼吗？据说当时口碑很差。B:嗯，对。A:斗鱼里有个人他出生在1952年9月16日。你知道是谁吗？B:谁呀？A:米基·洛克，他身高有180cm呢。B:是吗？我去关注一下。"}
# item = {"id": "4d8c3aab4f29acd1ce035bd577151bf1", "schema": "影视情感", "text": "A:喜欢看恐怖片吗？B:当然，我特别喜欢恐怖类型的电影。A:那你一定看过香港的恐怖片，鬼巴士。B:恩，看过。A:那你肯定知道主演了，口碑不错的艺人。B:一时想不起来叫什么了。A:任达华啊，发型超酷,满有个性的。B:对对，特别帅。"}

# item = {"id": "556986e9226f9cb23eb8d760ffee6563", "schema": "影视情感", "text": "A:你有喜欢的明星吗？B:有啊，我比较喜欢汉族的明星。A:麦家琪是汉族的，她的血型是AB型，而且他出生于1975年8月1日B:好棒呀，我也是AB型的。A:是吗，她是中国香港的一个很有味道的女人呢，值得关注哦。B:哦，那她有什么值得一看的作品吗？A:有的，就是Kei Mok导演的毁尸灭迹，总体一般，但还是可以无聊时去看看的呢。B:呵呵，听这个名字挺恐怖的呢。"}

# item = {"id": "771af148f2ac8571da502008f7701ccf", "schema": "影视情感", "text": "A:你最近看过什么电影啊？B:最近喜欢看漫威的电影。A:给你推荐一部吧！电影名字叫一生一世，也挺好看的。B:应该不错，有时间去看一下。A:还有一部电影口碑很差，但我感觉还不错。B:什么电影啊？A:度过盛夏，是一部剧情片，主演是夏维尔·毕沃斯。B:抽空我看看。"}
# item = {"id": "440418408121adbf6470b010b458e549", "schema": "影视情感", "text": "A:喜欢林志颖吗？B:喜欢，不老男神。A:给你推荐一部他的电影，名字叫学校霸王。B:我听说过这个电影，口碑较差。A:不过这部电影的主演很牛逼的，美国权威评选全球25位最性感男士啊。B:主演是谁呀，这么厉害。A:金城武，低调的华丽，听说过没。B:听过。"}
# item = {"id": "a3da610eb93492860fd846b1c37ba211", "schema": "影视情感", "text": "A:你喜欢动漫电影吗？B:喜欢啊，你有什么好的推荐吗？A:电影《天线宝宝来了》非常搞笑，推荐你看下。B:好的，有时间我会去看下。A:有部家庭类型电影叫祖父大战，我个人很喜欢看呢！B:这个名字我都没听过。A:是今年上映的美国影片，虽然口碑不是很好，我还是建议你去欣赏一下。B:算了吧，我不是很感兴趣。"}

# item = {"id": "df36443d068b9ecb25320fe43d376610", "schema": "影视情感", "text": "A:明哥，你这么容易爱人，你天生不会用眼睛爱人，我感觉这句话好像是在说我。B:你在自我安慰吗？A:哈哈，这句话是评论黄耀明的。B:哈哈，你这么一说我也觉得像他。A:邱刚健导演的一部电影就是他主演的。B:哪部电影啊？还真不知道他俩合作过呢！A:阿婴这部电影，评论说，再不挑战，简直吓死过去。B:看来挺刺激啊！"}

# item = {"id": "2b8316e5cbee692a1bfbb671e50b1fa8", "schema": "影视情感", "text": "A:恋爱的感觉真美好。B:我也是这样认为的。A:恋爱回旋这部电影，你一定要去看一下。B:看过了，石川淳一导演的作品。A:石川淳一还和你一样祖籍都是日本山梨县的哦！B:是的，他在我们那里挺有名气的。A:并且网友都说他是，日剧里难得的忧伤清纯的男孩子。B:我会一直支持他的。"}
# item = {"id": "95e47b44edd00130e2112653caa344fc", "schema": "影视情感", "text": "A:你之前说想找电影来看，看什么电影你想好了吗？B:没有啊，不知道看什么好。A:那可以看看折翼天使，是一部现实、平淡且让人感动的影片B:好，可以。A:一部口碑不错的电影推荐给你吧，评论说，还是会那句，对所有跟物理相关的，我都无比picky。B:那你还不赶紧告诉我电影的名字！A:这部电影叫星际穿越，拍摄这部电影时，由于诺兰讨厌蓝幕的个性，剧本真的种植了500英亩的玉米地。B:那这部电影一定非常精彩吧？"}

# item = {"id": "ed13cdcd87ecec552c4755bfac3d2443", "schema": "影视情感", "text": "A: Zurab Antelava主演的剧情电影还真不错。B:你说的是哪一部？A:西巴拉村庄，看过了吗？B:这个已经看过了，很不错的电影。A:同样是出自格鲁吉亚，另一部影片估计只能望其项背喽。B:啊，你说的是哪部？A:我说的是这部名叫Citizen Saint的电影，还没有上映呢，口碑却很差。B:那估计不怎么好看，我得绕着点。"}


# item = {"id": "ce03564242c35a3bb755d489b2890dc0", "schema": "灾害意外", "text": "6月18日07:34时，长宁县再次发生5.3级余震，成渝高铁、渝贵铁路、成贵铁路、沪蓉铁路、沪昆高铁西段沿线及部分车站均有不同程度震感。"}

# item = {"id": "44a8ac719ebea5168fa58931aaa480a2", "schema": "灾害意外", "text": "据瓦特视频消息：11月1日下午2时许，二广高速1735公里处荆州方向一辆快递半挂车因追尾前车引发自燃。"}


item = {'text':"""
A:潮汕人给你的感觉是什么样子的？B:真的印象不好。 (不是针对所有潮汕人，也不是地域黑。
"""}

item = {'text':"""
A:河南人为什么被称作中国的吉普赛人？B:看了那么多黑河南人的文字后基本麻木，地域歧视这个东西很难一两代人改变。
"""}

item = {
'text':"""
A:说起河南人，你的第一印象是什么？B:我大学刚毕业，合租就碰到了河南人，一直忍了很久，今天实在忍不了了！
"""
}

item = {
"text":"""
A:中国被地域歧视黑的最严重的地方是哪里？B:我们安徽人被黑的也不少啊，哭哭。
"""
}

item = {
'text':"""
A:为什么我国部分理科生会看不起文科生？B:先说结论：大部分理科生鄙视的是水平不够的文科生，同样我们鄙视没文化的理科生。
"""
}

item = {
'text':"""
A:为什么有些女生会反感「贤惠」这个词？B:因为一些人认为”贤惠“是”服从丈夫指挥“的代行词。
"""
}

item1 = {"id": "e8d5d81c21165d512d62d5bcd07d8b87", "schema": "影视情感", 
 "text": "A:你喜欢看喜剧吗？B:喜欢的A:有部电影叫Tyler Perry's a Madea Family Funeral，你可以看看B:前阵子刚看过A: Tyler Perry's a Madea Family Funeral这部美国大片的导演是泰勒·派瑞，一位黑人导演。B:这个我倒不怎么关心，我只是喜欢看剧。A:他是一位处女座的男人，所以我觉得他在拍这部戏的时候，一定花了很多精力在这上面。B:嗯，我也同意。我觉得网上的评论比较极端，其实这部剧挺好看的。"}

item = {"id": "de2641539a21fc0b899d53be55ca6119", "schema": "影视情感", "text": "A:有部电影被提名2013年青少年选择奖最佳剧情电影，你关注过吗？B:不知道诶，适合青少年看的吗A:是托比·马奎尔演的《了不起的盖茨比》挺不错的。B:我看过啊，挺好看的A:还有一部5年前上映的电影，也很不错。B:什么电影？A:向伟大的作曲家卡尔波特致敬，一部美国片，可以在腾讯上看蓝光版。B:那很不错，我一定要去看。"}


item = {"id": "e8d5d81c21165d512d62d5bcd07d8b87", "schema": "影视情感", "text": "你喜欢看喜剧吗？B:喜欢的A:有部电影叫Tyler Perry's a Madea Family Funeral，你可以看看B:前阵子刚看过. Tyler Perry's a Madea Family Funeral这部美国大片的导演是泰勒·派瑞，一位黑人导演。这个我倒不怎么关心，我只是喜欢看剧。A:他是一位处女座的男人，所以我觉得他在拍这部戏的时候，一定花了很多精力在这上面。B:嗯，我也同意。我觉得网上的评论比较极端，其实这部剧挺好看的。"}

target_type = '正向情感'
task_dict = duie_task_dict
all_schema_dict = train_dataset.schema_dict
item['text'] = item['text']
text = item['text']

output_list1 = extract(item1, task_dict, all_schema_dict, target_type, max_len)
(offset_mapping1, instruction_input_ids1, input_ids1, schema_input_ids1, ori_input_ids1) = output_list1[0]

query_token_ids1 = instruction_input_ids1 + input_ids1 + schema_input_ids1

output_list = extract(item, task_dict, all_schema_dict, target_type, max_len)
(offset_mapping, instruction_input_ids, input_ids, schema_input_ids, ori_input_ids) = output_list[0]

query_token_ids = instruction_input_ids + input_ids + schema_input_ids

print(tokenizer.decode(query_token_ids))

candies_all = flat_list([[(i, j) for j in range(i, min(20+i, len(input_ids)))] for i in range(0, len(input_ids))])
all_candidies = [input_ids[i:j+1] for (i,j) in candies_all]

sentinel_id_sequences = [tokenizer('[unused{}]'.format(i), add_special_tokens=False)['input_ids'] for i in range(1,100)]
sentinel_id_sequences += [tokenizer(item, add_special_tokens=False)['input_ids'] for item in ['<S>', '<T>', '[SEP]']]

trie_api = constrained_decoder.Trie(all_candidies)
append_trie = constrained_decoder.Trie(sentinel_id_sequences)
trie_api.append(append_trie, 0)

token_ids = [query_token_ids1, query_token_ids]
mask_ids = [[1]*len(query_token_ids1), [1]*len(query_token_ids)]
token_type_ids = [[0]*len(query_token_ids1), [0]*len(query_token_ids)]

token_ids = torch.tensor(sequence_padding(token_ids)).to(device)
mask_ids = torch.tensor(sequence_padding(mask_ids)).to(device)
token_type_ids = torch.tensor(sequence_padding(token_type_ids)).to(device)
    
batch_token_ids = torch.tensor(query_token_ids).long().unsqueeze(0).to(device)
batch_mask_ids = torch.tensor([1] * len(query_token_ids)).long().unsqueeze(0).to(device)
batch_token_type_ids = torch.tensor([0] * len(query_token_ids)).long().unsqueeze(0).to(device)

def prefix_allowed_tokens_fn(batch_id, sent): 
    return trie_api.get(sent)

from nets.constrained_decoder import get_end_to_end_prefix_allowed_tokens_fn_hf
prefix_allowed_tokens_fn = get_end_to_end_prefix_allowed_tokens_fn_hf(input_ids, task_dict, tokenizer)
print(prefix_allowed_tokens_fn)

model_outputs = net(input_ids=token_ids, input_mask=mask_ids, segment_ids=token_type_ids, mode='generation',
                   output_scores=True, do_sample=False, max_length=1024, num_beams=2, return_dict_in_generate=True,
                    prefix_allowed_tokens_fn=prefix_allowed_tokens_fn,
                   )

result = model_outputs.sequences.cpu().numpy()
for resp in result:
    print(tokenizer.decode(resp), '==unilm-decode-all==', output_path)
# print(decoder.single_schema_decode(text, offset_mapping, target_type, model_outputs, query_token_ids, ori_input_ids, mode='unilm'))

# seq = "[CLS] 信 息 抽 取 [SEP] 王 金 华 ： 中 国 煤 炭 科 工 集 团 有 限 公 司 法 定 代 表 人 、 董 事 长 、 党 委 书 记 ， 天 地 科 技 股 份 有 限 公 司 董 事 长 [SEP] 董 事 长 [SEP] subject - 组 织 机 构 [unused1] object - 人 物 [unused2] [SEP] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [SEP]".split()
# seq = "[CLS] 信 息 抽 取 [SEP] http : / / hb. qq. com / a / 20100316 / 001377. htm 中 国 新 任 驻 美 国 大 使 张 业 遂 和 夫 人 陈 乃 清 14 日 抵 达 美 国 首 都 华 盛 顿 履 新 ， 成 为 第 九 任 中 国 驻 美 大 使 [SEP] 首 都 [SEP] subject - 国 家 [unused1] object - 城 市 [unused2] [SEP] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [SEP]".split()
# seq = "[CLS] 事 件 抽 取 [SEP] 盛 达 矿 业 8 月 5 日 盘 中 涨 停 [SEP] 涨 停 [SEP] 触 发 词 [unused1] 涨 停 股 票 [unused2] 时 间 [unused3] [SEP]".split()
# seq = '[CLS] 事 件 抽 取 [SEP] 2019 年 10 月 4 日 ， 当 地 时 间 7 点 10 分 ， 乌 克 兰 航 空 联 盟 （ ukraine air alliance ） 的 一 架 安 - 12bk （ 4050 号 航 班 ） 货 机 在 乌 克 兰 利 沃 夫 - 丹 尼 洛 · 哈 利 特 斯 基 机 场 进 近 时 失 联 。 7 点 46 分 ， 救 援 人 员 在 距 离 机 场 跑 道 1. 5 公 里 处 发 现 失 事 货 机 。 救 援 人 员 解 救 出 3 名 幸 存 者 ， 5 人 不 幸  罹 难 。 这 架 编 号 u [SEP] 坠 机 [SEP] 触 发 词 [unused1] 地 点 [unused2] 死 亡 人 数 [unused3] 时 间 [unused4] 受 伤 人 数 [unused5] [SEP]'.split()
# seq = '[CLS] 事 件 抽 取 [SEP] 江 苏 中 天 科 技 股 份 有 限 公 司 关 于 中 标 高 压 直 流 海 底 电 缆 项 目 的 公 告 原 标 题 ： 江 苏 中 天 科 技 ( 8. 950, 0. 09, 1. 02 % ) 股 份 有 限 公 司 关 于 中 标 高 压 直 流 海 底 电 缆 项 目 的 公 告 本 公 司 董 事 会 及 全 体 董 事 保 证 本 公 告 内 容 不 存 在 任 何 虚 假 记 载 、 误 导 性 陈 述 或 者 重 大 遗 漏 ， 并 对 其 内 容 的 真 实 性 、 准 确 [SEP] 中 标 [SEP] 触 发 词 [unused1] 中 标 公 司 [unused2] 中 标 日 期 [unused3] 中 标 标 的 [unused4] 中 标 金 额 [unused5] 招 标 方 [unused6] 披 露 日 期 [unused7] [SEP]'.split()
# seq = ' [CLS] 实 体 抽 取 [SEP] 双 打 是 印 尼 队 的 强 项 ， 为 在 单 打 上 找 突 破 口 ， 故 割 爱 了 第 三 双 打 关 友 明 和 安 托 尼 奥 斯 ， 让 奥 运 会 金 牌 组 合 迈 纳 基 ／ 苏 巴 吉 亚 、 世 界 冠 军 陈 甲 亮 ／ 西 吉 特 和 替 补  吴 俊 明 确 保 双 打 两 分 。 [SEP] 组 织 机 构 [unused1] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [SEP]'.split()

# seq = '[CLS] 信 息 抽 取 [SEP] 北 京 华 都 集 团 有 限 责 任 公 司 （ 以 下 简 称 华 都 集 团 ） ， 前 身 为 北 京 市 畜 牧 局 · [SEP] 简 称 [SEP] subject - 组 织 机 构 [unused1] object - 组 织 机 构 [unused2] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [SEP]'.split()

# seq = '[CLS] 信 息 抽 取 [SEP] 明 牌 珠 宝 与 国 际 铂 金 协 会 ( pgi ) [UNK] [UNK] 世 界 著 名 铂 金 矿 业 公 司 于 1975 年 赞 助 成 立 的 国 际 非 营 利 铂 金 推 广 机 构 [UNK] [UNK] 每 年 在 重 点 市 场 展 开 [UNK] 一 对 一 [UNK] 的 合 作 ， 深 入 推 广 传 播 铂 金 文 化 [SEP] 简 称 [SEP] subject - 组 织 机 构 [unused1] object - 组 织 机 构 [unused2] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [PAD] [SEP]'

# seq_ids = tokenizer.convert_tokens_to_ids(tokenizer.tokenize(seq))
# seq_mask = []
# for idx in seq_ids:
#     if idx != 0:
#         seq_mask.append(1)
#     else:
#         seq_mask.append(0)

# batch_token_ids = torch.tensor(seq_ids).long().unsqueeze(0).to(device)
# batch_mask_ids = torch.tensor(seq_mask).long().unsqueeze(0).to(device)
# batch_token_type_ids = torch.tensor([0] * len(seq_ids)).long().unsqueeze(0).to(device)


# model_outputs = net(input_ids=batch_token_ids, input_mask=batch_mask_ids, segment_ids=batch_token_type_ids, mode='sample',
#                    output_scores=True, do_sample=True, max_length=512, num_beams=1, return_dict_in_generate=True,
#                     top_k=50,
#                     # prefix_allowed_tokens_fn=prefix_allowed_tokens_fn,
#                    )
# print(tokenizer.batch_decode(model_outputs.sequences.cpu().numpy()), '==unilm-decode==')