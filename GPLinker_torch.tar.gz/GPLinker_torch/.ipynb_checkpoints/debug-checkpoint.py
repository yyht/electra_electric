# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys
import numpy as np
import torch.nn as nn
from transformers import BertTokenizerFast
from utils.seq2struct_dataloader import (data_generator_single_schema, data_generator_single_schema_str,
                                         load_ie_schema, load_ee_schema, load_entity_schema, 
                                         load_entity, load_duie, load_duee,
                                        MultiTaskDataset, MultiTaskBatchSampler)
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
from multidataset_balanced_sampler import BalancedBatchSchedulerSampler
import logging
import torch
import io
import torch.nn.functional as F
import random
import numpy as np
import time
import math
import datetime
import torch.nn as nn
import logging
from torch.nn.modules.loss import _Loss
from tqdm import tqdm
from torch.utils.data.dataset import ConcatDataset

con = configparser.ConfigParser()
con.read('./config_unilm.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained('hfl/chinese-roberta-wwm-ext', do_lower_case=True)

print(tokenizer.tokenize('我是中国人[SEP]'))

duie_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'信息抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

duee_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'事件抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

entity_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'实体抽取',
    'sentinel_start_idx':1,
    'add_schema_type':False
}

schema = []
for schema_info in args_path["schema_data"].split(','):
    schema_type, schema_path = schema_info.split(':')
    print(schema_type, schema_path, '===schema-path===')
    if schema_type == 'duie':
        schema.extend(load_ie_schema(schema_path))
    elif schema_type == 'duee':
        schema.extend(load_ee_schema(schema_path))
    elif schema_type == 'entity':
        schema.extend(load_entity_schema(schema_path))
        
largest_size = 0
import re
dupe_factor = 2
add_role_shuffle = True
if add_role_shuffle:
    dupe_factor = 2
    
for label_index, data_info in enumerate(args_path["train_file"].split(',')):
    data_type, data_path = data_info.split(':')
    if 'DUEE' not in data_path:
        continue
    print(data_type, data_path, '==data-path==')
    if data_type == 'duie':
        load_fn = load_duie
        task_dict = duie_task_dict
        dupe_factor = 2
    elif data_type == 'duee':
        load_fn = load_duee
        task_dict = duee_task_dict
        dupe_factor = 2
    elif data_type == 'entity':
        load_fn = load_entity
        task_dict = entity_task_dict
        dupe_factor = 1

    data_list = load_fn(data_path)

    if add_role_shuffle:
        data_list *= dupe_factor
    else:
        if len(data_list) <= 10000:
            data_list *= 3
    for data in data_list:
        if data['text'] == '英国一家五口在西班牙用假钞被捕':
            train_dataset = data_generator_single_schema([data], tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, label=label_index,
                                                task_dict=task_dict, mode='train', add_role_shuffle=True)

    