# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys
import numpy as np
import torch.nn as nn
from nets.gpNet import RawGlobalPointer, sparse_multilabel_categorical_crossentropy, BiaffineFlatten, multilabel_categorical_crossentropy
from transformers import BertTokenizerFast, BertModel
from utils.dataloader import data_generator_direct_rel, load_name
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
import logging
from tqdm import tqdm

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
con.read('./config_asa_roformer_directrel_neg_sampling.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained(args_path["model_path"], do_lower_case=True)
from roformer import RoFormerModel
from roformer import RoFormerModel, RoFormerConfig
config = RoFormerConfig.from_pretrained(args_path["model_path"])

print(config, '=====')

with open(args_path["schema_data"], 'r', encoding='utf-8') as f:
    schema = {}
    for idx, item in enumerate(f):
        item = json.loads(item.rstrip())
        for key in item['object_type']:
            schema[item["subject_type"]+"_"+item["predicate"]+"_"+item['object_type'][key]] = idx
id2schema = {}
for k,v in schema.items(): id2schema[v]=k

print(schema)
device = torch.device("cuda:0")

def search_all(pattern, sequence):
    all_index = []
    n = len(pattern)
    for i in range(len(sequence)):
        if sequence[i:i + n] == pattern:
            all_index.append(i)
    return all_index

def gather_indexes(sequence_tensor, positions):
    """Gathers the vectors at the specific positions over a minibatch."""
    sequence_shape = sequence_tensor.shape
    batch_size = sequence_shape[0]
    seq_length = sequence_shape[1]
    width = sequence_shape[2]
    
    device = sequence_tensor.device

    flat_offsets = torch.reshape(
      torch.arange(0, batch_size) * seq_length, [-1, 1]).to(device)

    flat_positions = torch.reshape(positions + flat_offsets, [-1])
    flat_sequence_tensor = torch.reshape(sequence_tensor,
                                    [batch_size * seq_length, width])
    output_tensor = flat_sequence_tensor.index_select(0, flat_positions)
    output_tensor = torch.reshape(output_tensor, [batch_size, -1, width])
    return output_tensor

class DetectionStage(nn.Module):
    def __init__(self):
        super(DetectionStage, self).__init__()
        from roformer import RoFormerModel
        self.encoder = RoFormerModel.from_pretrained(args_path["model_path"]).to(device)
        self.mention_detect = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=1, inner_dim=128, RoPE=True).to(device)#实体关系抽取任务默认不提取实体类型
        
    def get_extra(self):
        return [self.mention_detect]
    
    def forward(self, batch_token_ids, batch_mask_ids, batch_token_type_ids):
        outputs = self.encoder(batch_token_ids, batch_mask_ids, batch_token_type_ids)
        mention_outputs = self.mention_detect(outputs, batch_mask_ids)
        return mention_outputs
    
class LinkStage(nn.Module):
    def __init__(self):
        super(LinkStage, self).__init__()
        from roformer import RoFormerModel
        self.encoder = RoFormerModel.from_pretrained(args_path["model_path"]).to(device)
        self.head_linear_project = nn.Linear(config.hidden_size, 1024, bias=True)
        self.tail_linear_project = nn.Linear(config.hidden_size, 1024, bias=True)
        self.link_detect = BiaffineFlatten(in_size=1024, out_size=len(schema), bias_x=True, bias_y=True).to(device)#实体关系抽取任务默认不提取实体类型

    def get_extra(self):
        return [self.link_detect, self.head_linear_project, self.tail_linear_project]
    
    def forward(self, batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_head_pos, batch_tail_pos, batch_label_mask=None):
        outputs = self.encoder(batch_token_ids, batch_mask_ids, batch_token_type_ids)
        
        batch_head_start_pos = batch_head_pos[:, :, 0] # [batch, pos]
        batch_head_end_pos = batch_head_pos[:, :, 1] # [batch, pos]
        
        batch_tail_start_pos = batch_tail_pos[:, :, 0] # [batch, pos]
        batch_tail_end_pos = batch_tail_pos[:, :, 1] # [batch, pos]
        
        batch_head_start_feat = gather_indexes(outputs[0], batch_head_start_pos) # batch*pos, dim
        batch_head_end_feat = gather_indexes(outputs[0], batch_head_end_pos)
        
        batch_tail_start_feat = gather_indexes(outputs[0], batch_tail_start_pos)
        batch_tail_end_feat = gather_indexes(outputs[0], batch_tail_end_pos)
                
        batch_head_feat = (batch_head_start_feat+batch_head_end_feat) / 2.0 # [batch, pos, dim]
        batch_head_feat = self.head_linear_project(batch_head_feat)
        
        batch_tail_feat = (batch_tail_start_feat+batch_tail_end_feat) / 2.0 # [batch, pos, dim]
        batch_tail_feat = self.tail_linear_project(batch_tail_feat)
        
        logits = self.link_detect(batch_head_feat, batch_tail_feat) # [batch, pos, relation_num]
        # batch_label_mask []batch_size, pos
                                    
        if batch_label_mask is not None:  # huggingface's attention_mask
            attn_mask = 1.0 - batch_label_mask[:, :, None] # [batch, pos, 1]
            logits = logits - attn_mask * 1e12                      
                                    
        return logits

def set_optimizer(model, train_steps=None):
    param_optimizer = list(model.named_parameters())
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=2e-5,
                         warmup=0.01,
                         t_total=train_steps)
    return optimizer

def set_group_optimizer(model_list, train_steps=None):
    param_optimizer = []
    for model in model_list:
        param_optimizer.extend(list(model.named_parameters()))
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=2e-5,
                         warmup=0.01,
                         t_total=train_steps)
    return optimizer

output_path = args_path['output_path']
import time, os
local_time_ticket = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime(time.time()))
logger.addHandler(logging.FileHandler(os.path.join(output_path, "train_{}.log".format(local_time_ticket)), 'w'))

def extract_entity(net_detection, text, threshold=0):
    """抽取输入text所包含的三元组
    """
    token2char_span_mapping = tokenizer(text, return_offsets_mapping=True, max_length=256)["offset_mapping"]
    new_span, entities = [], []
    for i in token2char_span_mapping:
        if i[0] == i[1]:
            new_span.append([])
        else:
            if i[0] + 1 == i[1]:
                new_span.append([i[0]])
            else:
                new_span.append([i[0], i[-1] - 1])
    
    encoder_txt = tokenizer.encode_plus(text, max_length=256)
    input_ids = torch.tensor(encoder_txt["input_ids"]).long().unsqueeze(0).to(device)
    token_type_ids = torch.tensor(encoder_txt["token_type_ids"]).unsqueeze(0).to(device)
    attention_mask = torch.tensor(encoder_txt["attention_mask"]).unsqueeze(0).to(device)
    
    scores = net_detection(input_ids, attention_mask, token_type_ids)
    outputs = scores[0].data.cpu().numpy() # [1, 1, seq, seq]
    entities = set()
    outputs[:, [0, -1]] -= np.inf
    outputs[:, :, [0, -1]] -= np.inf
    for l, h, t in zip(*np.where(outputs > 0)):
        entities.add(text[new_span[h][0]:new_span[t][-1] + 1])
    return list(entities)

def extract_spoes(net_detection, net_linker, text, gold_entities=[], threshold=0):
    
    if gold_entities:
        entities = gold_entities
    else:
        if net_detection:
            entities = extract_entity(net_detection, text, threshold=0)
        else:
            entities = []
    
    token2char_span_mapping = tokenizer(text, return_offsets_mapping=True, max_length=256)["offset_mapping"]
    new_span = []
    for i in token2char_span_mapping:
        if i[0] == i[1]:
            new_span.append([])
        else:
            if i[0] + 1 == i[1]:
                new_span.append([i[0]])
            else:
                new_span.append([i[0], i[-1] - 1])
    
    encoder_text = tokenizer.encode_plus(text, max_length=256)
    input_ids = encoder_text["input_ids"]
    spoes = set()
    spoes_rel = {}
    pos2entity = {}
    all_entity = set()
    for entity in entities:
        if entity:
            entity_ids = tokenizer.encode(entity, add_special_tokens=False)
            entity_sh_list = search_all(entity_ids, input_ids)
            if entity_sh_list:
                for entity_sh in entity_sh_list:
                    all_entity.add((entity_sh, entity_sh+len(entity_ids)-1))
                    pos2entity[(entity_sh, entity_sh+len(entity_ids)-1)] = entity
                            
    import itertools
    entity_pair = list(itertools.permutations(list(all_entity), 2))
    entity_pair_set = set()
    for pair in entity_pair:
        if pair[0] == pair[1]:
            continue
        entity_pair_set.add(pair[0]+pair[1])
        
    head_pos = []
    tail_pos = []

    for sh, st, oh, ot in entity_pair_set:
        head_pos.append((sh, st))
        tail_pos.append((oh, ot))
    
    spoes = set()
    if head_pos:
        label_mask = [1]*len(head_pos)

        input_ids_th = torch.tensor(encoder_text["input_ids"]).long().unsqueeze(0).to(device)    # [1, seq_len]
        token_type_ids_th = torch.tensor(encoder_text["token_type_ids"]).unsqueeze(0).to(device) # [1, seq_len]
        attention_mask_th = torch.tensor(encoder_text["attention_mask"]).unsqueeze(0).to(device) # [1, seq_len]

        head_pos_th = torch.tensor(head_pos).long().unsqueeze(0).to(device) # [1, num_head, 2]
        tail_pos_th = torch.tensor(tail_pos).long().unsqueeze(0).to(device) # [1, num_head, 2]

        scores = net_linker(input_ids_th, attention_mask_th, token_type_ids_th, head_pos_th, tail_pos_th)
        outputs = scores[0].data.cpu().numpy() # [num_head, num_classes]

        head_tail_index = np.argwhere(outputs > threshold)

        for link_pair in head_tail_index:
            spo_head_pos = head_pos[link_pair[0]]
            spo_tail_pos = tail_pos[link_pair[0]]
            head_tail_cls = link_pair[1]
            [subject_type, predicate, object_type] = id2schema[head_tail_cls].split('_')
            head_entity = pos2entity[tuple(spo_head_pos)]
            tail_entity = pos2entity[tuple(spo_tail_pos)]

            spoes.add((
                    head_entity, predicate, tail_entity, subject_type, object_type
                        ))
    return spoes

class SPO(tuple):
    """用来存三元组的类
    表现跟tuple基本一致，只是重写了 __hash__ 和 __eq__ 方法，
    使得在判断两个三元组是否等价时容错性更好。
    """
    def __init__(self, spo):
        self.spox = (
            tuple(tokenizer.tokenize(spo[0])),
            spo[1],
            tuple(tokenizer.tokenize(spo[2])),
            spo[-1]
        )

    def __hash__(self):
        return self.spox.__hash__()

    def __eq__(self, spo):
        return self.spox == spo.spox
    
def evaluate_detection(net_detection, data, eo):
    import os
    X, Y, Z = 1e-10, 1e-10, 1e-10
    dev_result_path = os.path.join(output_path, 'spo_entity.pth.{}.dev'.format(eo))
    f = open(dev_result_path, 'w', encoding='utf-8')
    pbar = tqdm()
    for d in data:
        T = set(extract_entity(net_detection, d['text'], threshold=0))
        R = set()
        for spo in d['spo_list']: # (spo["subject"], spo["predicate"], spo["object"][key], spo["subject_type"], spo["object_type"][key])
            R.add(spo[0])
            R.add(spo[2])
        X += len(R & T)
        Y += len(R)
        Z += len(T)
        f1, precision, recall = 2 * X / (Y + Z), X / Y, X / Z
        pbar.update()
        pbar.set_description(
            'f1: %.5f, precision: %.5f, recall: %.5f' % (f1, precision, recall)
        )
        s = json.dumps({
            'text': d['text'],
            'spo_list': list(T),
            'spo_list_pred': list(R),
            'new': list(R - T),
            'lack': list(T - R),
        },
                       ensure_ascii=False,
                       indent=4)
        f.write(s + '\n')
    pbar.close()
    f.close()
    return f1, precision, recall

def evaluate_linker(net_detection, net_linker, data, eo, use_gold_entities=False):
    """评估函数，计算f1、precision、recall
    """
    import os
    X, Y, Z = 1e-10, 1e-10, 1e-10
    dev_result_path = os.path.join(output_path, 'spo_linker.pth.{}.dev'.format(eo))
    f = open(dev_result_path, 'w', encoding='utf-8')
    pbar = tqdm()
    for d in data:
        if use_gold_entities:
            gold_entities = set()
            for spo in d['spo_list']: # (spo["subject"], spo["predicate"], spo["object"][key], spo["subject_type"], spo["object_type"][key])
                gold_entities.add(spo[0])
                gold_entities.add(spo[2])
            gold_entities = list(gold_entities)
        else:
            gold_entities = []
                  
        R = set([SPO(spo) for spo in extract_spoes(net_detection, net_linker, d['text'], gold_entities)])
        T = set([SPO(spo) for spo in d['spo_list']])
        X += len(R & T)
        Y += len(R)
        Z += len(T)
        f1, precision, recall = 2 * X / (Y + Z), X / Y, X / Z
        pbar.update()
        pbar.set_description(
            'f1: %.5f, precision: %.5f, recall: %.5f' % (f1, precision, recall)
        )
        s = json.dumps({
            'text': d['text'],
            'spo_list': list(T),
            'spo_list_pred': list(R),
            'new': list(R - T),
            'lack': list(T - R),
        },
                       ensure_ascii=False,
                       indent=4)
        f.write(s + '\n')
    pbar.close()
    f.close()
    return f1, precision, recall

add_neg_flag = True

def train_and_evaluate_detection():

    net = DetectionStage()
    net_extra = net.get_extra()
    net = net.to(device)
    
    train_data = data_generator_direct_rel(load_name(args_path["train_file"]), tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, add_neg=add_neg_flag)
    train_loader = DataLoader(train_data , batch_size=con.getint("para", "batch_size"), shuffle=True, collate_fn=train_data.collate)
    dev_data = load_name(args_path["val_file"])
    
    optimizer = set_optimizer(net, train_steps= (int(len(train_data) / con.getint("para", "batch_size")) + 1) * con.getint("para", "epochs"))
    linear_optimizer = set_group_optimizer(net_extra, train_steps= (int(len(train_data) / con.getint("para", "batch_size")) + 1) * con.getint("para", "linear_epochs"))
    
    total_loss, total_f1 = 0., 0.
    for eo in range(con.getint("para", "linear_epochs")):
        total_loss = 0
        n_steps = 0
        for idx, batch in enumerate(train_loader):
            [text, batch_token_ids, batch_mask_ids, batch_token_type_ids, 
             batch_entity_labels, batch_head_pos, batch_tail_pos, batch_head_tail_link, batch_label_mask] = batch
        
            batch_token_ids = batch_token_ids.to(device)
            batch_mask_ids = batch_mask_ids.to(device)
            batch_token_type_ids = batch_token_type_ids.to(device)
            batch_entity_labels = batch_entity_labels.to(device)
            
            logits = net(batch_token_ids, batch_mask_ids, batch_token_type_ids)

            loss = sparse_multilabel_categorical_crossentropy(y_true=batch_entity_labels, y_pred=logits, mask_zero=True)
            linear_optimizer.zero_grad()
            loss.backward()
            linear_optimizer.step()
            total_loss += loss.item()
            n_steps += 1
            if np.mod(idx, 1000) == 0:
                logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)

    total_loss, total_f1 = 0., 0.
    for eo in range(con.getint("para", "epochs")):
        total_loss = 0
        n_steps = 0
        for idx, batch in enumerate(train_loader):
            [text, batch_token_ids, batch_mask_ids, batch_token_type_ids, 
             batch_entity_labels, batch_head_pos, batch_tail_pos, batch_head_tail_link, batch_label_mask] = batch
        
            batch_token_ids = batch_token_ids.to(device)
            batch_mask_ids = batch_mask_ids.to(device)
            batch_token_type_ids = batch_token_type_ids.to(device)
            batch_entity_labels = batch_entity_labels.to(device)
            
            logits = net(batch_token_ids, batch_mask_ids, batch_token_type_ids)

            loss = sparse_multilabel_categorical_crossentropy(y_true=batch_entity_labels, y_pred=logits, mask_zero=True)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
            n_steps += 1
            if np.mod(idx, 1000) == 0:
                logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)
        import os
        torch.save(net.state_dict(), os.path.join(output_path, 'spo_detection.pth.{}'.format(eo)))

        f1, precision, recall = evaluate_detection(net, dev_data, eo)
        logger.info("f1=%.5f, precision=%.5f, recall=%.5f", f1, precision, recall)

def train_and_evaluate_link():
    
    import os
    
    net = LinkStage()
    net_extra = net.get_extra()
    net = net.to(device)
    
    train_data = data_generator_direct_rel(load_name(args_path["train_file"]), tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, add_neg=add_neg_flag)
    dev_data = load_name(args_path["val_file"])

    optimizer = set_optimizer(net, train_steps= (int(len(train_data) / con.getint("para", "batch_size")) + 1) * con.getint("para", "epochs"))
    linear_optimizer = set_group_optimizer(net_extra, train_steps= (int(len(train_data) / con.getint("para", "batch_size")) + 1) * con.getint("para", "linear_epochs"))
    train_loader = DataLoader(train_data , batch_size=con.getint("para", "batch_size"), shuffle=True, collate_fn=train_data.collate)
    
    total_loss, total_f1 = 0., 0.
    for eo in range(con.getint("para", "linear_epochs")):
        total_loss = 0
        n_steps = 0
        for idx, batch in enumerate(train_loader):
            [text, batch_token_ids, batch_mask_ids, batch_token_type_ids, 
             batch_entity_labels, batch_head_pos, batch_tail_pos, batch_head_tail_link, batch_label_mask] = batch
        
            batch_token_ids = batch_token_ids.to(device)
            batch_mask_ids = batch_mask_ids.to(device)
            batch_token_type_ids = batch_token_type_ids.to(device)
            batch_head_pos = batch_head_pos.to(device)
            batch_tail_pos = batch_tail_pos.to(device)
            batch_head_tail_link = batch_head_tail_link.to(device)
            batch_label_mask = batch_label_mask.to(device) # [batch, pos]
            
            logits = net(batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_head_pos, batch_tail_pos, batch_label_mask) # [batch_size, pos, pos, num_classes]
            loss = multilabel_categorical_crossentropy(y_true=batch_head_tail_link, y_pred=logits, threshold=0.0)
            loss = torch.mean(loss)
            
            linear_optimizer.zero_grad()
            loss.backward()
            linear_optimizer.step()
            total_loss += loss.item()
            n_steps += 1
            if np.mod(idx, 1000) == 0:
                logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)

    total_loss, total_f1 = 0., 0.
    for eo in range(con.getint("para", "epochs")):
        total_loss = 0
        n_steps = 0
        for idx, batch in enumerate(train_loader):
            [text, batch_token_ids, batch_mask_ids, batch_token_type_ids, 
             batch_entity_labels, batch_head_pos, batch_tail_pos, batch_head_tail_link, batch_label_mask] = batch
        
            batch_token_ids = batch_token_ids.to(device)
            batch_mask_ids = batch_mask_ids.to(device)
            batch_token_type_ids = batch_token_type_ids.to(device)
            batch_head_pos = batch_head_pos.to(device)
            batch_tail_pos = batch_tail_pos.to(device)
            batch_head_tail_link = batch_head_tail_link.to(device)
            batch_label_mask = batch_label_mask.to(device) # [batch, pos]
            
            logits = net(batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_head_pos, batch_tail_pos, batch_label_mask) # [batch_size, pos, pos, num_classes]
            loss = multilabel_categorical_crossentropy(y_true=batch_head_tail_link, y_pred=logits, threshold=0.0)
            loss = torch.mean(loss)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
            n_steps += 1
            if np.mod(idx, 1000) == 0:
                logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)
        import os
        torch.save(net.state_dict(), os.path.join(output_path, 'spo_linker.pth.{}'.format(eo)))

        f1, precision, recall = evaluate_linker(None, net, dev_data, eo, use_gold_entities=True)
        logger.info("f1=%.5f, precision=%.5f, recall=%.5f", f1, precision, recall)

train_and_evaluate_detection()
train_and_evaluate_link()
    
    
    



