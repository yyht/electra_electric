# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys
import numpy as np
import torch.nn as nn
from nets.gpNet import RawGlobalPointer, sparse_multilabel_categorical_crossentropy, EfficientGlobalPointer
from transformers import BertTokenizerFast, BertModel
from utils.dataloader_duee import data_generator, load_name
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
import logging
from itertools import groupby
from tqdm import tqdm
from multidataset_balanced_sampler import BalancedBatchSchedulerSampler
from torch.utils.data.dataset import ConcatDataset

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
con.read('./config_duee_duee_fin_roformer.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained(args_path["model_path"], do_lower_case=True)
from roformer import RoFormerModel
encoder = RoFormerModel.from_pretrained(args_path["model_path"])

from roformer import RoFormerModel, RoFormerConfig
config = RoFormerConfig.from_pretrained(args_path["model_path"])

schema = {}
enum_roles, enum_items = [], {}
idx = 0
for schema_path in args_path["schema_data"].split(','):
    with open(schema_path, 'r', encoding='utf-8') as f:
        """
        {"event_type": "财经/交易-出售/收购", "role_list": [{"role": "时间"}, {"role": "出售方"}, {"role": "交易物"}, {"role": "出售价格"}, {"role": "收购方"}], "id": "804336473abe8b8124d00876a5387151", "class": "财经/交易"}
        """
        for _, item in enumerate(f):
            item = json.loads(item.rstrip())
            t = item['event_type']
            schema[(t, u'触发词')] = idx
            idx += 1
            for s in item['role_list']:
                if 'enum_items' in s:
                    enum_roles.append((t, s['role']))
                    for r in s['enum_items']:
                        schema[(t, r)] = idx
                        idx += 1
                        enum_items[(t, r)] = (t, s['role'])
                else:
                    schema[(t, s['role'])] = idx
                    idx += 1

print(len(schema))
print(schema)

id2schema = {}
for k,v in schema.items(): id2schema[v]=k

total_train_dataset = []
largest_size = 0
for label_index, train_file in enumerate(args_path["train_file"].split(',')):
    train_dataset = data_generator(load_name(train_file), tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, label=label_index)
    total_train_dataset.append(train_dataset)
    if len(train_dataset) > largest_size:
        largest_size = len(train_dataset)
    collate_fn = train_dataset.collate
    
print(largest_size, len(total_train_dataset), '====')
    
import random
train_data = ConcatDataset(total_train_dataset)

dev_data = {}
for dev_file in args_path["val_file"].split(','):
    key = dev_file.split('/')[-2]
    print('===dev key===', key)
    dev_data[key] = load_name(dev_file)

train_loader = DataLoader(train_data , batch_size=con.getint("para", "batch_size"), collate_fn=collate_fn,
                         sampler=BalancedBatchSchedulerSampler(dataset=train_data,
                                    batch_size=con.getint("para", "batch_size"),
                                    mix_batch=True))

device = torch.device("cuda:0")
mention_detect = EfficientGlobalPointer(hidden_size=config.hidden_size, heads=len(schema), head_size=128, RoPE=True).to(device)#实体关系抽取任务默认不提取实体类型
s_o_head = EfficientGlobalPointer(hidden_size=config.hidden_size, heads=1, head_size=128, RoPE=False).to(device)
s_o_tail = EfficientGlobalPointer(hidden_size=config.hidden_size, heads=1, head_size=128, RoPE=False).to(device)

class ERENet(nn.Module):
    def __init__(self, encoder, a, b, c):
        super(ERENet, self).__init__()
        self.mention_detect = a
        self.s_o_head = b
        self.s_o_tail = c
        self.encoder = encoder

    def forward(self, batch_token_ids, batch_mask_ids, batch_token_type_ids):
        outputs = self.encoder(batch_token_ids, batch_mask_ids, batch_token_type_ids)

        mention_outputs = self.mention_detect(outputs, batch_mask_ids)
        so_head_outputs = self.s_o_head(outputs, batch_mask_ids)
        so_tail_outputs = self.s_o_tail(outputs, batch_mask_ids)
        return mention_outputs, so_head_outputs, so_tail_outputs

net = ERENet(encoder, mention_detect, s_o_head, s_o_tail).to(device)

def set_optimizer(model, train_steps=None):
    param_optimizer = list(model.named_parameters())
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=2e-5,
                         warmup=0.01,
                         t_total=train_steps)
    return optimizer

def set_group_optimizer(model_list, train_steps=None):
    param_optimizer = []
    for model in model_list:
        param_optimizer.extend(list(model.named_parameters()))
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=2e-5,
                         warmup=0.01,
                         t_total=train_steps)
    return optimizer

optimizer = set_optimizer(net, train_steps= (int(len(total_train_dataset) * largest_size / con.getint("para", "batch_size")) + 1) * con.getint("para", "epochs"))
linear_optimizer = set_group_optimizer([s_o_head, s_o_tail], train_steps= (int(len(total_train_dataset) * largest_size / con.getint("para", "batch_size")) + 1) * 5)


print(len(train_loader), "===batch-num===")

output_path = args_path['output_path']
import time, os
local_time_ticket = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime(time.time()))
logger.addHandler(logging.FileHandler(os.path.join(output_path, "train_{}.log".format(local_time_ticket)), 'w'))

class DedupList(list):
    """定义去重的list
    """
    def append(self, x):
        if x not in self:
            super(DedupList, self).append(x)

def neighbors(host, argus, links):
    """构建邻集（host节点与其所有邻居的集合）
    """
    results = [host]
    for argu in argus:
        if host[2:] + argu[2:] in links:
            results.append(argu)
    return list(sorted(results))


def clique_search(argus, links):
    """搜索每个节点所属的完全子图作为独立事件
    搜索思路：找出不相邻的节点，然后分别构建它们的邻集，递归处理。
    """
    Argus = DedupList()
    for i1, (_, _, h1, t1) in enumerate(argus):
        for i2, (_, _, h2, t2) in enumerate(argus):
            if i2 > i1:
                if (h1, t1, h2, t2) not in links:
                    Argus.append(neighbors(argus[i1], argus, links))
                    Argus.append(neighbors(argus[i2], argus, links))
    if Argus:
        results = DedupList()
        for A in Argus:
            for a in clique_search(A, links):
                results.append(a)
        return results
    else:
        return [list(sorted(argus))]

def extract_events(text, threshold=0, trigger=True):
    """抽取输入text所包含的所有事件
    """
    token2char_span_mapping = tokenizer(text, return_offsets_mapping=True, max_length=256)["offset_mapping"]
    new_span, entities = [], []
    for i in token2char_span_mapping:
        if i[0] == i[1]:
            new_span.append([])
        else:
            if i[0] + 1 == i[1]:
                new_span.append([i[0]])
            else:
                new_span.append([i[0], i[-1] - 1])
    
    encoder_txt = tokenizer.encode_plus(text, max_length=256)
    input_ids = torch.tensor(encoder_txt["input_ids"]).long().unsqueeze(0).to(device)
    token_type_ids = torch.tensor(encoder_txt["token_type_ids"]).unsqueeze(0).to(device)
    attention_mask = torch.tensor(encoder_txt["attention_mask"]).unsqueeze(0).to(device)
    scores = net(input_ids, attention_mask, token_type_ids)
    
    outputs = [o[0].data.cpu().numpy() for o in scores]
    # 抽取论元
    argus = set()
    outputs[0][:, [0, -1]] -= np.inf
    outputs[0][:, :, [0, -1]] -= np.inf
    for l, h, t in zip(*np.where(outputs[0] > threshold)):
        argus.add(id2schema[l] + (h, t))
    # 构建链接
    links = set()
    for i1, (_, _, h1, t1) in enumerate(argus):
        for i2, (_, _, h2, t2) in enumerate(argus):
            if i2 > i1:
                if outputs[1][0, min(h1, h2), max(h1, h2)] > threshold:
                    if outputs[2][0, min(t1, t2), max(t1, t2)] > threshold:
                        links.add((h1, t1, h2, t2))
                        links.add((h2, t2, h1, t1))
    # 析出事件
    events = []
    for _, sub_argus in groupby(sorted(argus), key=lambda s: s[0]):
        for event in clique_search(list(sub_argus), links):
            events.append([])
            for argu in event:
                start, end = new_span[argu[2]][0], new_span[argu[3]][-1] + 1
                events[-1].append(argu[:2] + (text[start:end], start))
            if trigger and all([argu[1] != u'触发词' for argu in event]):
                events.pop()
    return events

def evaluate(data, threshold=0):
    """评估函数，计算f1、precision、recall
    """
    ex, ey, ez = 1e-10, 1e-10, 1e-10  # 事件级别
    ax, ay, az = 1e-10, 1e-10, 1e-10  # 论元级别
    for d in tqdm(data, ncols=0):
        pred_events = extract_events(d['text'], threshold, False)
        # 事件级别
        R, T = DedupList(), DedupList()
        for event in pred_events:
            if any([argu[1] == u'触发词' for argu in event]):
                R.append(list(sorted(event)))
        for event in d['events']:
            T.append(list(sorted(event)))
        for event in R:
            if event in T:
                ex += 1
        ey += len(R)
        ez += len(T)
        # 论元级别
        R, T = DedupList(), DedupList()
        for event in pred_events:
            for argu in event:
                if argu[1] != u'触发词':
                    R.append(argu)
        for event in d['events']:
            for argu in event:
                if argu[1] != u'触发词':
                    T.append(argu)
        for argu in R:
            if argu in T:
                ax += 1
        ay += len(R)
        az += len(T)
    e_f1, e_pr, e_rc = 2 * ex / (ey + ez), ex / ey, ex / ez
    a_f1, a_pr, a_rc = 2 * ax / (ay + az), ax / ay, ax / az
    result = {
        'event_type_f1':e_f1,
        "event_type_pr":e_pr,
        "event_type_rc":e_rc,
        "event_type_argument_f1": a_f1,
        "event_type_argument_pr": a_pr,
        "event_type_argument_rc": a_rc
    }
    return result

total_loss, total_f1 = 0., 0.
for eo in range(5):
    total_loss = 0
    n_steps = 0
    for idx, batch in enumerate(train_loader):
        text, batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_entity_labels, batch_head_labels, batch_tail_labels = batch
        batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_entity_labels, batch_head_labels, batch_tail_labels = \
            batch_token_ids.to(device), batch_mask_ids.to(device), batch_token_type_ids.to(device), batch_entity_labels.to(device), batch_head_labels.to(device), batch_tail_labels.to(device)
        logits1, logits2, logits3 = net(batch_token_ids, batch_mask_ids, batch_token_type_ids)
                
        loss1 = sparse_multilabel_categorical_crossentropy(y_true=batch_entity_labels, y_pred=logits1, mask_zero=True)
        loss2 = sparse_multilabel_categorical_crossentropy(y_true=batch_head_labels, y_pred=logits2, mask_zero=True)
        loss3 = sparse_multilabel_categorical_crossentropy(y_true=batch_tail_labels, y_pred=logits3, mask_zero=True)
        loss = sum([loss1, loss2, loss3]) / 3
        linear_optimizer.zero_grad()
        loss.backward()
        linear_optimizer.step()
        total_loss += loss.item()
        n_steps += 1
        if np.mod(idx, 1000) == 0:
            logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)

total_loss, total_f1 = 0., 0.
for eo in range(con.getint("para", "epochs")):
    total_loss = 0
    n_steps = 0
    for idx, batch in enumerate(train_loader):
        text, batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_argu_labels, batch_head_labels, batch_tail_labels = batch
        batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_argu_labels, batch_head_labels, batch_tail_labels = \
            batch_token_ids.to(device), batch_mask_ids.to(device), batch_token_type_ids.to(device), batch_argu_labels.to(device), batch_head_labels.to(device), batch_tail_labels.to(device)
        logits1, logits2, logits3 = net(batch_token_ids, batch_mask_ids, batch_token_type_ids)
                
        loss1 = sparse_multilabel_categorical_crossentropy(y_true=batch_argu_labels, y_pred=logits1, mask_zero=True)
        loss2 = sparse_multilabel_categorical_crossentropy(y_true=batch_head_labels, y_pred=logits2, mask_zero=True)
        loss3 = sparse_multilabel_categorical_crossentropy(y_true=batch_tail_labels, y_pred=logits3, mask_zero=True)
        loss = sum([loss1, loss2, loss3]) / 3
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        n_steps += 1
        if np.mod(idx, 1000) == 0:
            logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)

    import os
    logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)
    torch.save(net.state_dict(), os.path.join(output_path, 'event.pth.{}'.format(eo)))
    
    for key in dev_data:
        result = evaluate(dev_data[key], 0.0)
        logger.info(" epoch=%d, loss=%.5f, dataset=%s ", eo, loss, key)
        logger.info("result=%s, dataset=%s", json.dumps(result), key)
    