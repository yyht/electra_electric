# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys
import numpy as np
import torch.nn as nn
from nets.gpNet import RawGlobalPointer, sparse_multilabel_categorical_crossentropy, EfficientGlobalPointer
from transformers import BertTokenizerFast, BertModel
from utils.seq2struct_dataloader import (data_generator_single_schema, data_generator_schema_cls,
                                         load_ie_schema, load_ee_schema, load_entity_schema, 
                                         load_entity, load_duie, load_duee,
                                        MultiTaskDataset, MultiTaskBatchSampler)
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
import logging
from nets.sngp import SNGP
import torch.nn.functional as F
from nets import utils as net_utils
from tqdm import tqdm
from torch.utils.data.dataset import ConcatDataset

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)


logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
con.read('./config_unilm_schema_cls.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained(args_path["model_path"], do_lower_case=True)

duie_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentienl_token':'[unused{}]',
    'instruction':'信息抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

duee_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentienl_token':'[unused{}]',
    'instruction':'事件抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

schema = []
for schema_info in args_path["schema_data"].split(','):
    schema_type, schema_path = schema_info.split(':')
    print(schema_type, schema_path, '===schema-path===')
    if schema_type == 'duie':
        schema.extend(load_ie_schema(schema_path))
    elif schema_type == 'duee':
        schema.extend(load_ee_schema(schema_path))
        
schema2id = {}
id2schema = {}
schema_idx = 0
for schema_dict in schema:
    if schema_dict['type'] not in schema2id:
        schema2id[schema_dict['type']] = schema_idx
        id2schema[schema_idx] = schema_dict['type']
        schema_idx += 1
        
print(id2schema)
device = torch.device("cuda:0")
                        
class SNGPStage(nn.Module):
    def __init__(self):
        super(SNGPStage, self).__init__()
        from roformer import RoFormerModel, RoFormerConfig
        self.config = RoFormerConfig.from_pretrained(args_path["model_path"])
        self.encoder = RoFormerModel.from_pretrained(args_path["model_path"])
        self.sngp_layer = SNGP(
                 backbone=self.encoder,
                 hidden_size=self.config.hidden_size,
                 gp_kernel_scale=1.0,
                 num_inducing=1024,
                 gp_output_bias=0.,
                 layer_norm_eps=1e-12,
                 n_power_iterations=1,
                 spec_norm_bound=0.95,
                 scale_random_features=True,
                 normalize_input=True,
                 gp_cov_momentum=0.999,
                 gp_cov_ridge_penalty=1e-3,
                 epochs=10,
                 num_classes=len(schema2id),
                 device=device).to(device)
        
    def reset_cov(self):
        self.sngp_layer.reset_cov()

    def forward(self, batch_token_ids, batch_mask_ids, batch_token_type_ids, return_gp_cov=False, update_cov=False, forward_mode='training'):
        logits = self.sngp_layer(input_ids=batch_token_ids, token_type_ids=batch_token_type_ids,
                attention_mask = batch_mask_ids, return_gp_cov=return_gp_cov,
                update_cov=update_cov, forward_mode=forward_mode, mean_field_factor=0.1)
        return logits

def set_optimizer(model, train_steps=None):
    param_optimizer = list(model.named_parameters())
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=2e-5,
                         warmup=0.01,
                         t_total=train_steps)
    return optimizer

def set_group_optimizer(model_list, train_steps=None):
    param_optimizer = []
    for model in model_list:
        param_optimizer.extend(list(model.named_parameters()))
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=2e-5,
                         warmup=0.01,
                         t_total=train_steps)
    return optimizer

output_path = args_path['output_path']
import time, os
local_time_ticket = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime(time.time()))
logger.addHandler(logging.FileHandler(os.path.join(output_path, "train_{}.log".format(local_time_ticket)), 'w'))

def schema_type_cls(net, text, threshold=0.5):
    """抽取输入text所包含的类型
    """
    token2char_span_mapping = tokenizer(text, return_offsets_mapping=True, max_length=256)["offset_mapping"]
    encoder_txt = tokenizer.encode_plus(text, max_length=256)
    input_ids = torch.tensor(encoder_txt["input_ids"]).long().unsqueeze(0).to(device)
    token_type_ids = torch.tensor(encoder_txt["token_type_ids"]).unsqueeze(0).to(device)
    attention_mask = torch.tensor(encoder_txt["attention_mask"]).unsqueeze(0).to(device)
    
    scores = net(input_ids, attention_mask, token_type_ids, 
                 return_gp_cov = True, update_cov=False,
                forward_mode = "inference")
    
    scores = torch.nn.Sigmoid()(scores)[0].data.cpu().numpy()
    
    schema_types = set()
    for index, score in enumerate(scores):
        if score > threshold:
            schema_types.add(id2schema[index])
    return list(schema_types)

output_path = args_path['output_path']

net_sngp = SNGPStage()
net_sngp = net_sngp.to(device)

eo = 9
try:
    ckpt = torch.load(os.path.join(output_path, 'spo_cls.pth.{}'.format(eo)))
    net_sngp.load_state_dict(ckpt)
except:
    ckpt = torch.load(os.path.join(output_path, 'spo_cls.pth.{}'.format(eo)))
    new_ckpt = {}
    for key in ckpt:
        name = key.split('.')
        new_ckpt[".".join(name[1:])] = ckpt[key]
    net_sngp.load_state_dict(new_ckpt)

# cls_model_path = os.path.join(args_path['output_path'], 'spo_cls.pth.{}'.format(4))
# net_sngp.load_state_dict(torch.load(cls_model_path))
net_sngp.eval()

with open('/data/albert.xht/unified_generation/duuie_test_a-1.json.result.quake.schema_cls.0.4', 'w') as fwobj: 
    with open('/data/albert.xht/unified_generation/duuie_test_a-1.json', 'r') as frobj:
        for line in frobj:
            content = json.loads(line.strip())
            content['schema_type'] = []
            schema_types = schema_type_cls(net_sngp, content['text'], threshold=0.4)
            if content['schema'] in ['金融信息']:
                for schema_type in schema_types:
                    if schema_type in ['中标', '亏损', '企业收购', '企业破产', '企业融资', '公司上市', '股东减持', '股东增持', '股份回购', 
                                           '被约谈', '解除质押', '质押', '高管变动']:
                        content['schema_type'].append(schema_type)
            elif content['schema'] in ['影视情感']:
                for schema_type in schema_types:
                    if schema_type in ['正向情感', '负向情感', '中性情感']:
                        content['schema_type'].append(schema_type)
            elif  content['schema'] in ['人生信息']:
                for schema_type in schema_types:
                    if schema_type in ['丈夫', '妻子', '母亲', '父亲', '国籍', '祖籍', '毕业院校']:
                        content['schema_type'].append(schema_type)
            elif  content['schema'] in ['机构信息']:
                for schema_type in schema_types:
                    if schema_type in ['注册资本', '创始人', '董事长', '总部地点', '代言人', '成立日期', '占地面积', '简称']:
                        content['schema_type'].append(schema_type)
            elif content['schema'] in ['体育竞赛']:
                for schema_type in schema_types:
                    if schema_type in ['夺冠', '晋级', '禁赛', '胜负', '退赛', '退役']:
                        content['schema_type'].append(schema_type)
            elif content['schema'] in ['灾害意外']: 
                for schema_type in schema_types:
                    if schema_type in ['爆炸', '车祸', '地震', '洪灾', '起火', '坠机', '坍/垮塌', '袭击', '坠机']:
                        content['schema_type'].append(schema_type)
            
            fwobj.write(json.dumps(content, ensure_ascii=False)+'\n')