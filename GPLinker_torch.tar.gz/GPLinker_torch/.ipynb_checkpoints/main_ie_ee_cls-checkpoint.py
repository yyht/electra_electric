# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys
import numpy as np
import torch.nn as nn
from nets.gpNet import RawGlobalPointer, sparse_multilabel_categorical_crossentropy, EfficientGlobalPointer
from transformers import BertTokenizerFast, BertModel
from utils.seq2struct_dataloader import (data_generator_single_schema, data_generator_schema_cls,
                                         load_ie_schema, load_ee_schema, load_entity_schema, 
                                         load_entity, load_duie, load_duee,
                                        MultiTaskDataset, MultiTaskBatchSampler)
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
import logging
from nets.sngp import SNGP
import torch.nn.functional as F
from nets import utils as net_utils
from tqdm import tqdm
from torch.utils.data.dataset import ConcatDataset

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)


logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
# con.read('./config_unilm_schema_cls.ini', encoding='utf8')
con.read('./config_unilm_schema_cls_large.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained(args_path["model_path"], do_lower_case=True)

duie_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'信息抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

duee_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'事件抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

schema = []
for schema_info in args_path["schema_data"].split(','):
    schema_type, schema_path = schema_info.split(':')
    print(schema_type, schema_path, '===schema-path===')
    if schema_type == 'duie':
        schema.extend(load_ie_schema(schema_path))
    elif schema_type == 'duee':
        schema.extend(load_ee_schema(schema_path))
        
schema2id = {}
id2schema = {}
schema_idx = 0
for schema_dict in schema:
    if schema_dict['type'] not in schema2id:
        schema2id[schema_dict['type']] = schema_idx
        id2schema[schema_idx] = schema_dict['type']
        schema_idx += 1
        
print(id2schema)
device = torch.device("cuda:0")
                        
class SNGPStage(nn.Module):
    def __init__(self):
        super(SNGPStage, self).__init__()
        from roformer import RoFormerModel, RoFormerConfig
        self.config = RoFormerConfig.from_pretrained(args_path["model_path"])
        self.encoder = RoFormerModel.from_pretrained(args_path["model_path"])
        self.sngp_layer = SNGP(
                 backbone=self.encoder,
                 hidden_size=self.config.hidden_size,
                 gp_kernel_scale=1.0,
                 num_inducing=1024,
                 gp_output_bias=0.,
                 layer_norm_eps=1e-12,
                 n_power_iterations=1,
                 spec_norm_bound=0.95,
                 scale_random_features=True,
                 normalize_input=True,
                 gp_cov_momentum=0.999,
                 gp_cov_ridge_penalty=1e-3,
                 epochs=10,
                 num_classes=len(schema2id),
                 device=device).to(device)
        
    def reset_cov(self):
        self.sngp_layer.reset_cov()

    def forward(self, batch_token_ids, batch_mask_ids, batch_token_type_ids, return_gp_cov=False, update_cov=False, forward_mode='training'):
        logits = self.sngp_layer(input_ids=batch_token_ids, token_type_ids=batch_token_type_ids,
                attention_mask = batch_mask_ids, return_gp_cov=return_gp_cov,
                update_cov=update_cov, forward_mode=forward_mode, mean_field_factor=0.1)
        return logits

def set_optimizer(model, train_steps=None):
    param_optimizer = list(model.named_parameters())
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=2e-5,
                         warmup=0.01,
                         t_total=train_steps)
    return optimizer

def set_group_optimizer(model_list, train_steps=None):
    param_optimizer = []
    for model in model_list:
        param_optimizer.extend(list(model.named_parameters()))
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=2e-5,
                         warmup=0.01,
                         t_total=train_steps)
    return optimizer

output_path = args_path['output_path']
import time, os
local_time_ticket = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime(time.time()))
logger.addHandler(logging.FileHandler(os.path.join(output_path, "train_{}.log".format(local_time_ticket)), 'w'))

def schema_type_cls(net, text, threshold=0.5):
    """抽取输入text所包含的类型
    """
    token2char_span_mapping = tokenizer(text, return_offsets_mapping=True, max_length=256)["offset_mapping"]
    encoder_txt = tokenizer.encode_plus(text, max_length=256)
    input_ids = torch.tensor(encoder_txt["input_ids"]).long().unsqueeze(0).to(device)
    token_type_ids = torch.tensor(encoder_txt["token_type_ids"]).unsqueeze(0).to(device)
    attention_mask = torch.tensor(encoder_txt["attention_mask"]).unsqueeze(0).to(device)
    
    scores = net(input_ids, attention_mask, token_type_ids, 
                 return_gp_cov = True, update_cov=False,
                forward_mode = "inference")
    
    scores = torch.nn.Sigmoid()(scores)[0].data.cpu().numpy()
    
    schema_types = set()
    for index, score in enumerate(scores):
        if score > threshold:
            schema_types.add(id2schema[index])
    return list(schema_types)

def evaluate_schema(data, eo, net_sngp):
    import os
    X, Y, Z = 1e-10, 1e-10, 1e-10
    dev_result_path = os.path.join(output_path, 'schema_cls.pth.{}.dev'.format(eo))
    f = open(dev_result_path, 'w', encoding='utf-8')
    pbar = tqdm()
    for index, d in enumerate(data):
        R = set(schema_type_cls(net_sngp, d['text']))
        T = set([target_dict['type'] for target_dict in d['target_list']])
        
        X += len(R & T)
        Y += len(R)
        Z += len(T)
        f1, precision, recall = 2 * X / (Y + Z), X / Y, X / Z
        pbar.update()
        pbar.set_description(
            'f1: %.5f, precision: %.5f, recall: %.5f' % (f1, precision, recall)
        )
        s = json.dumps({
            'text': d['text'],
            'spo_list': list(T),
            'spo_list_pred': list(R),
            'new': list(R - T),
            'lack': list(T - R),
        },
                       ensure_ascii=False,
                       indent=4)
        f.write(s + '\n')
    pbar.close()
    f.close()
    return f1, precision, recall

def train_and_evaluate_cls():
    
    import os
    
    net = SNGPStage()
    net = net.to(device)
    
    total_train_dataset = []
    for label_index, data_info in enumerate(args_path["train_file"].split(',')):
        data_type, data_path = data_info.split(':')
        print(data_type, data_path, '==data-path==')
        if data_type == 'duie':
            load_fn = load_duie
            task_dict = duie_task_dict
        elif data_type == 'duee':
            load_fn = load_duee
            task_dict = duee_task_dict

        data_list = load_fn(data_path)
        if len(data_list) <= 10000:
            data_list *= (int(10000/(len(data_list)))+2)

        train_dataset = data_generator_schema_cls(data_list, tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, label=label_index,
                                                    task_dict=task_dict, mode='train')
    
        print(len(train_dataset), '==size of train_dataset==')
        total_train_dataset.append(train_dataset)
        collate_fn = train_dataset.collate
        
    train_data = ConcatDataset(total_train_dataset)
    
    dev_data = {}
    for data_info in args_path["val_file"].split(','):
        data_type, data_path = data_info.split(':')
        print(data_type, data_path, '==data-path==')
        if data_type == 'duie':
            load_fn = load_duie
            task_dict = duie_task_dict
        elif data_type == 'duee':
            load_fn = load_duee
            task_dict = duee_task_dict
        
        key = data_path.split('/')[-2]
        print('===dev key===', key)
        dev_data[key] = load_fn(data_path)
    
    optimizer = set_optimizer(net, train_steps= (int(len(train_data) / con.getint("para", "batch_size")) + 1) * con.getint("para", "epochs"))

    train_loader = DataLoader(train_data , batch_size=con.getint("para", "batch_size"), shuffle=True, collate_fn=collate_fn)

    total_loss, total_f1 = 0., 0.
    best_f1 = 0.0
    best_epoch = 0.0
    for eo in range(con.getint("para", "epochs")):
        total_loss = 0
        n_steps = 0
        
        net.train()
        
        for idx, batch in enumerate(train_loader):
            batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_labels = batch
            batch_labels = batch_labels.float()
                                    
            batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_labels = \
                batch_token_ids.to(device), batch_mask_ids.to(device), batch_token_type_ids.to(device), batch_labels.to(device)
            logits = net(batch_token_ids, batch_mask_ids, batch_token_type_ids, return_gp_cov=False, update_cov=True, forward_mode='training')
            
            loss = torch.nn.BCEWithLogitsLoss()(logits, batch_labels)
            loss = torch.mean(loss)
            
            net.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
            n_steps += 1
            if np.mod(idx, 1000) == 0:
                logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)
        import os
        torch.save(net.state_dict(), os.path.join(output_path, 'spo_cls.pth.{}'.format(eo)))
        net.eval()
        for key in dev_data:
            f1, precision, recall = evaluate_schema(dev_data[key], '{}_{}'.format(key, eo), net)
            logger.info("epoch=%d, f1=%.5f, precision=%.5f, recall=%.5f, dataset=%s", eo, f1, precision, recall, key)
    
        net.reset_cov()

train_and_evaluate_cls()