# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys
import numpy as np
import torch.nn as nn
from nets.gpNet import RawGlobalPointer, sparse_multilabel_categorical_crossentropy, EfficientGlobalPointer
from transformers import BertTokenizerFast, BertModel
from utils.dataloader_duee import data_generator_cls_then_detection, load_name
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
import logging
from itertools import groupby
from tqdm import tqdm
from nets.sngp import SNGP

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
con.read('./config_duee_roformer_two_stage_large_raw.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained(args_path["model_path"], do_lower_case=True)
from roformer import RoFormerModel
encoder = RoFormerModel.from_pretrained(args_path["model_path"])

from roformer import RoFormerModel, RoFormerConfig
config = RoFormerConfig.from_pretrained(args_path["model_path"])

seg_token = '[SEP]'
apply_universal_schema = True
device = torch.device("cuda:0")
print(config)

with open(args_path["schema_data"], 'r', encoding='utf-8') as f:
    """
    {"event_type": "财经/交易-出售/收购", "role_list": [{"role": "时间"}, {"role": "出售方"}, {"role": "交易物"}, {"role": "出售价格"}, {"role": "收购方"}], "id": "804336473abe8b8124d00876a5387151", "class": "财经/交易"}
    """
    schema = {}
    schema2universal = {}
    universal2schema = {}
    unisersal_schema = {}
    et_schema = {}
    idx = 0
    universal_idx = 0
    et_idx = 0
    for _, item in enumerate(f):
        item = json.loads(item.rstrip())
        t = item['event_type']
        if t not in et_schema:
            et_schema[t] = et_idx
            et_idx += 1
        
        for r in [u'触发词']:
            if (t,r) not in schema:
                schema[(t,r)] = idx
                idx += 1
                schema2universal[(t,r)] = r # et in-dependent
                universal2schema[(t,r)] = (t,r)
                if r not in unisersal_schema:
                    unisersal_schema[r] = universal_idx
                    universal_idx += 1
        for s in item['role_list']:
            if (t, s['role']) not in schema:
                schema[(t, s['role'])] = idx
                idx += 1
                schema2universal[(t, s['role'])] = s['standard_role'] # et in-dependent
            if s['standard_role'] not in unisersal_schema:
                unisersal_schema[s['standard_role']] = universal_idx
                universal_idx += 1
            if (t, s['standard_role']) not in universal2schema:
                universal2schema[(t, s['standard_role'])] = (t, s['role'])
                
print(len(schema), '==original schema==')
print(len(schema2universal), '==schema2universal==')
print(len(universal2schema), '==universal2schema==')
print(len(unisersal_schema), '==unisersal_schema==', unisersal_schema)
print(len(et_schema), '==et_schema==')

id2schema = {}
for k,v in schema.items(): id2schema[v]=k
id2universal_schema = {}
for k,v in unisersal_schema.items(): id2universal_schema[v]=k
id2et_schema = {}
for k,v in et_schema.items(): id2et_schema[v]=k

class DetectionStage(nn.Module):
    def __init__(self, apply_universal_schema=False):
        super(DetectionStage, self).__init__()
        from roformer import RoFormerModel
        self.encoder = RoFormerModel.from_pretrained(args_path["model_path"])
        if apply_universal_schema:
            self.mention_detect = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=len(unisersal_schema), inner_dim=128, RoPE=True).to(device)#实体关系抽取任务默认不提取实体类型
        else:
            self.mention_detect = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=len(schema), inner_dim=128, RoPE=True).to(device)#实体关系抽取任务默认不提取实体类型
    
        self.s_o_head = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=1, inner_dim=128, RoPE=False).to(device)#实体关系抽取任务默认不提取实体类型
        self.s_o_tail = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=1, inner_dim=128, RoPE=False).to(device)#实体关系抽取任务默认不提取实体类型
        
    def get_extra(self):
        return [self.mention_detect]

    def forward(self, batch_token_ids, batch_mask_ids, batch_token_type_ids):
        outputs = self.encoder(batch_token_ids, batch_mask_ids, batch_token_type_ids)
        mention_outputs = self.mention_detect(outputs, batch_mask_ids)
        so_head_outputs = self.s_o_head(outputs, batch_mask_ids)
        so_tail_outputs = self.s_o_tail(outputs, batch_mask_ids)
        return mention_outputs, so_head_outputs, so_tail_outputs

class SNGPStage(nn.Module):
    def __init__(self):
        super(SNGPStage, self).__init__()
        from roformer import RoFormerModel
        self.encoder = RoFormerModel.from_pretrained(args_path["model_path"])
        self.sngp_layer = SNGP(
                 backbone=self.encoder,
                 hidden_size=config.hidden_size,
                 gp_kernel_scale=1.0,
                 num_inducing=1024,
                 gp_output_bias=0.,
                 layer_norm_eps=1e-12,
                 n_power_iterations=1,
                 spec_norm_bound=0.95,
                 scale_random_features=True,
                 normalize_input=True,
                 gp_cov_momentum=0.999,
                 gp_cov_ridge_penalty=1e-3,
                 epochs=40,
                 num_classes=len(et_schema),
                 device=device).to(device)
        
    def reset_cov(self):
        self.sngp_layer.reset_cov()

    def forward(self, batch_token_ids, batch_mask_ids, batch_token_type_ids, return_gp_cov=False, update_cov=False, forward_mode='training'):
        logits = self.sngp_layer(input_ids=batch_token_ids, token_type_ids=batch_token_type_ids,
                attention_mask = batch_mask_ids, return_gp_cov=return_gp_cov,
                update_cov=update_cov, forward_mode=forward_mode, mean_field_factor=0.1)
        return logits
    
output_path = args_path['output_path']
import time, os
local_time_ticket = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime(time.time()))
logger.addHandler(logging.FileHandler(os.path.join(output_path, "train_{}.log".format(local_time_ticket)), 'w'))

class DedupList(list):
    """定义去重的list
    """
    def append(self, x):
        if x not in self:
            super(DedupList, self).append(x)

def neighbors(host, argus, links):
    """构建邻集（host节点与其所有邻居的集合）
    """
    results = [host]
    for argu in argus:
        if host[2:] + argu[2:] in links:
            results.append(argu)
    return list(sorted(results))


def clique_search(argus, links):
    """搜索每个节点所属的完全子图作为独立事件
    搜索思路：找出不相邻的节点，然后分别构建它们的邻集，递归处理。
    """
    Argus = DedupList()
    for i1, (_, _, h1, t1) in enumerate(argus):
        for i2, (_, _, h2, t2) in enumerate(argus):
            if i2 > i1:
                if (h1, t1, h2, t2) not in links:
                    Argus.append(neighbors(argus[i1], argus, links))
                    Argus.append(neighbors(argus[i2], argus, links))
    if Argus:
        results = DedupList()
        for A in Argus:
            for a in clique_search(A, links):
                results.append(a)
        return results
    else:
        return [list(sorted(argus))]
    
def extract_event_types(net, text, threshold=0.5):
    """抽取输入text所包含的类型
    """
    token2char_span_mapping = tokenizer(text, return_offsets_mapping=True, max_length=256)["offset_mapping"]
    encoder_txt = tokenizer.encode_plus(text, max_length=256)
    input_ids = torch.tensor(encoder_txt["input_ids"]).long().unsqueeze(0).to(device)
    token_type_ids = torch.tensor(encoder_txt["token_type_ids"]).unsqueeze(0).to(device)
    attention_mask = torch.tensor(encoder_txt["attention_mask"]).unsqueeze(0).to(device)
    
    scores = net(input_ids, attention_mask, token_type_ids, 
                 return_gp_cov = True, update_cov=False,
                forward_mode = "inference")
    scores = torch.nn.Sigmoid()(scores)[0].data.cpu().numpy()
    
    et_types = set()
    for index, score in enumerate(scores):
        if score > threshold:
            et_types.add(id2et_schema[index])
    
    et_types = list(et_types)
    return et_types
    

def extract_events(net_detection, net_sngp, text, threshold=0, trigger=True, et_list=[], gold_et=True):
    """抽取输入text所包含的所有事件
    """
    net_detection.eval()
    if net_sngp:
        net_sngp.eval()
    token2char_span_mapping = tokenizer(text, return_offsets_mapping=True, max_length=256)["offset_mapping"]
    new_span, entities = [], []
    for i in token2char_span_mapping:
        if i[0] == i[1]:
            new_span.append([])
        else:
            if i[0] + 1 == i[1]:
                new_span.append([i[0]])
            else:
                new_span.append([i[0], i[-1] - 1])
    
    if not gold_et:
        if net_sngp:
            et_list = extract_event_types(net_sngp, text, threshold=0.4)
        else:
            et_list = list(et_schema.keys())
    
    encoder_txt = tokenizer.encode_plus(text, max_length=256)
    input_ids = encoder_txt["input_ids"]
    token_type_ids = encoder_txt["token_type_ids"]
    attention_mask = encoder_txt["attention_mask"]
    
    events = []
    
    for e_t in et_list:
        et_ids = tokenizer(e_t)['input_ids'][1:] #  [cls] text [sep] relation [sep]
        new_input_ids = input_ids + et_ids    
        token_type_ids = [0]*len(new_input_ids)
        attention_mask = [1]*len(new_input_ids)

        new_input_ids = torch.tensor(new_input_ids).long().unsqueeze(0).to(device)
        new_token_type_ids = torch.tensor(token_type_ids).unsqueeze(0).to(device)
        new_attention_mask = torch.tensor(attention_mask).unsqueeze(0).to(device)
        scores = net_detection(new_input_ids, new_attention_mask, new_token_type_ids)
    
        outputs = [o[0].data.cpu().numpy() for o in scores]
        # 抽取论元
        argus = set()
        outputs[0][:, [0, -1]] -= np.inf
        outputs[0][:, :, [0, -1]] -= np.inf
        for l, h, t in zip(*np.where(outputs[0] > threshold)):
            if h >= len(input_ids) or t >= len(input_ids):
                continue
            if apply_universal_schema:
                universal_schema_key = id2universal_schema[l]
                if (e_t, universal_schema_key) in universal2schema:
                    schema_key = universal2schema[(e_t, universal_schema_key)]
                    argus.add(schema_key + (h, t))
            else:
                argus.add(id2schema[l] + (h, t))
                
        # 构建链接
        links = set()
        for i1, (_, _, h1, t1) in enumerate(argus):
            for i2, (_, _, h2, t2) in enumerate(argus):
                if i2 > i1:
                    if outputs[1][0, min(h1, h2), max(h1, h2)] > threshold:
                        if outputs[2][0, min(t1, t2), max(t1, t2)] > threshold:
                            links.add((h1, t1, h2, t2))
                            links.add((h2, t2, h1, t1))
        # 析出事件
        for _, sub_argus in groupby(sorted(argus), key=lambda s: s[0]):
            for event in clique_search(list(sub_argus), links):
                events.append([])
                for argu in event:
                    try:
                        start, end = new_span[argu[2]][0], new_span[argu[3]][-1] + 1
                    except:
                        print(argu[2], argu[3])
                        continue
                    events[-1].append(argu[:2] + (text[start:end], start))
                if trigger and all([argu[1] != u'触发词' for argu in event]):
                    events.pop()
    return events

def evaluate(net_detection, net_sngp, data, threshold=0, gold_et=True):
    """评估函数，计算f1、precision、recall
    """
    ex, ey, ez = 0, 0, 0  # 事件级别
    ax, ay, az = 0, 0, 0  # 论元级别
    for d in tqdm(data, ncols=0):
        et_list = set()
        for event in d['events']:
            for e in event:
                et_list.add(e[0])
        pred_events = extract_events(net_detection, net_sngp, d['text'], threshold, trigger=False, et_list=list(et_list), gold_et=gold_et)
        # 事件级别
        R, T = DedupList(), DedupList()
        for event in pred_events:
            if any([argu[1] == u'触发词' for argu in event]):
                R.append(list(sorted(event)))
        for event in d['events']:
            T.append(list(sorted(event)))
        for event in R:
            if event in T:
                ex += 1
        ey += len(R)
        ez += len(T)
        # 论元级别
        R, T = DedupList(), DedupList()
        for event in pred_events:
            for argu in event:
                if argu[1] != u'触发词':
                    R.append(argu)
        for event in d['events']:
            for argu in event:
                if argu[1] != u'触发词':
                    T.append(argu)
        for argu in R:
            if argu in T:
                ax += 1
        ay += len(R)
        az += len(T)
    e_f1, e_pr, e_rc = 2 * ex / (ey + ez + 1e-20), ex / (ey + 1e-20), ex / (ez + 1e-20)
    a_f1, a_pr, a_rc = 2 * ax / (ay + az+ + 1e-20), ax / (ay + 1e-20), ax / (az + 1e-20)
    result = {
        'event_type_f1':e_f1,
        "event_type_pr":e_pr,
        "event_type_rc":e_rc,
        "event_type_argument_f1": a_f1,
        "event_type_argument_pr": a_pr,
        "event_type_argument_rc": a_rc
    }
    return result

def evaluate_et(net_sngp, data, threshold=0.5):
    X, Y, Z = 0, 0, 0  # 事件级别
    for d in tqdm(data, ncols=0):
        pred_et = extract_event_types(net_sngp, d['text'], threshold=threshold)
        pred_et = set(pred_et)
        gold_et = set()
        for event in d['events']:
            for e in event:
                gold_et.add(e[0])
        
        X += len(gold_et & pred_et)
        Y += len(pred_et)
        Z += len(gold_et)
        
    f1, precision, recall = 2 * X / (Y + Z + 1e-10), X / (Y + 1e-10), X / (Z + 1e-10)
    result = {
        'event_type_f1':f1,
        "event_type_pr":precision,
        "event_type_rc":recall
    }
    return result

net_detection = DetectionStage(apply_universal_schema=apply_universal_schema)
net_detection = net_detection.to(device)
detection_model_path = os.path.join(args_path['output_path'], 'event_extraction.pth.{}'.format(9))
net_detection.load_state_dict(torch.load(detection_model_path))
net_detection.eval()

net_sngp = SNGPStage()
net_sngp = net_sngp.to(device)
cls_model_path = os.path.join(args_path['output_path'], 'event_et.pth.{}'.format(9))
net_sngp.load_state_dict(torch.load(cls_model_path))
net_sngp.eval()

# with open('/data/albert.xht/unified_generation/duuie_test_a-1.json.result.duee.roformer.two_stage', 'w') as fwobj: 
#     with open('/data/albert.xht/unified_generation/duuie_test_a-1.json', 'r') as frobj:
#         for line in frobj:
#             content = json.loads(line.strip())
#             if content['schema'] not in ['体育竞赛', '灾害意外']:
#                 tmp_dict = {
#                     'id':content['id'],
#                     'entity': [],
#                     'relation': [],
#                     'event':[]
#                 }
#                 fwobj.write(json.dumps(tmp_dict, ensure_ascii=False)+'\n')
#             else:
#                 if content['schema'] in ['体育竞赛', '灾害意外']:
#                     event_list =  extract_events(net_detection, net_sngp, content['text'], threshold=0, trigger=True, et_list=[], gold_et=False)
#                     tmp_dict = {
#                         'id':content['id'],''
#                         'entity': [],
#                         'relation': [],
#                         'event':[]
#                     }
#                     for event in event_list:
#                         """
#                         [('夺冠', '冠军', '沈阳小伙郭劲岐', 0)], [('夺冠', '夺冠赛事', '世锦赛选拔赛', 8)]
#                         """
#                         if event[0][0] not in ['爆炸', '车祸', '地震', '洪灾', '起火', '坠机', '坍/垮塌', '袭击', '坠机', '夺冠', '晋级', '禁赛', '胜负', '退赛', '退役']:
#                             continue
#                         event_dict = {
#                             "type":event[0][0],
#                             'text':"",
#                             "args":[]

#                         }
#                         for item in event:
#                             if item[1] == u'触发词':
#                                 event_dict['text'] = item[2]
#                             else:
#                                 event_dict['args'].append({
#                                     'type':item[1],
#                                     'text':item[2]
#                                 })
#                         if event_dict['args']:
#                             tmp_dict['event'].append(event_dict)
#                     fwobj.write(json.dumps(tmp_dict, ensure_ascii=False)+'\n')
                    
with open('/data/albert.xht/unified_generation/duuie_test_a-1.json.result.duee.only.roformer.two_stage.large.raw', 'w') as fwobj: 
    with open('/data/albert.xht/unified_generation/duuie_test_a-1.json', 'r') as frobj:
        for line in frobj:
            content = json.loads(line.strip())
            if content['schema'] in ['体育竞赛', '灾害意外']:
                event_list =  extract_events(net_detection, net_sngp, content['text'], threshold=0, trigger=True, et_list=[], gold_et=False)
                tmp_dict = {
                    'id':content['id'],''
                    'entity': [],
                    'relation': [],
                    'event':[],
                    'event_type':[]
                }
                for event in event_list:
                    tmp_dict['event_type'].append(event[0][0])
                    """
                    [('夺冠', '冠军', '沈阳小伙郭劲岐', 0)], [('夺冠', '夺冠赛事', '世锦赛选拔赛', 8)]
                    """
                    if event[0][0] not in ['爆炸', '车祸', '地震', '洪灾', '起火', '坠机', '坍/垮塌', '袭击', '坠机', '夺冠', '晋级', '禁赛', '胜负', '退赛', '退役']:
                        continue
                    event_dict = {
                        "type":event[0][0],
                        'text':"",
                        "args":[],
                    }
                    for item in event:
                        if item[1] == u'触发词':
                            event_dict['text'] = item[2]
                        else:
                            event_dict['args'].append({
                                'type':item[1],
                                'text':item[2]
                            })
                    if event_dict['args']:
                        tmp_dict['event'].append(event_dict)
                fwobj.write(json.dumps(tmp_dict, ensure_ascii=False)+'\n')