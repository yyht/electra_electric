# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys
import numpy as np
import torch.nn as nn
from nets.gpNet import RawGlobalPointer, sparse_multilabel_categorical_crossentropy
from transformers import BertTokenizerFast, BertModel
from utils.dataloader import data_generator, load_name
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
from multidataset_balanced_sampler import BalancedBatchSchedulerSampler
from torch.utils.data.dataset import ConcatDataset
import logging
from tqdm import tqdm

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
con.read('./config_duie_life_org_asa_duie.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained(args_path["model_path"], do_lower_case=True)
from roformer import RoFormerModel
encoder = RoFormerModel.from_pretrained(args_path["model_path"])

from roformer import RoFormerModel, RoFormerConfig
config = RoFormerConfig.from_pretrained(args_path["model_path"])

schema = {}
idx = 0
for schema_path in args_path["schema_data"].split(','):
    with open(schema_path, 'r', encoding='utf-8') as f:
        for _, item in enumerate(f):
            item = json.loads(item.rstrip())
            for key in item['object_type']:
                p = item["subject_type"]+"_"+item["predicate"]+"_"+item['object_type'][key]
                if p not in schema:
                    schema[p] = idx
                    idx += 1
id2schema = {}
for k,v in schema.items(): id2schema[v]=k

print(schema)

total_train_dataset = []
largest_size = 0
for label_index, train_file in enumerate(args_path["train_file"].split(',')):
    train_dataset = data_generator(load_name(train_file), tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, label=label_index)
    print(train_file, '====', len(train_dataset))
    if len(train_dataset) > largest_size:
        largest_size = len(train_dataset)
    total_train_dataset.append(train_dataset)
    collate_fn = train_dataset.collate
    
import random
train_data = ConcatDataset(total_train_dataset)

dev_data = {}
for dev_file in args_path["val_file"].split(','):
    key = dev_file.split('/')[-2]
    print('===dev key===', key)
    dev_data[key] = load_name(dev_file)

train_loader = DataLoader(train_data , batch_size=con.getint("para", "batch_size"), collate_fn=collate_fn,
                         sampler=BalancedBatchSchedulerSampler(dataset=train_data,
                                    batch_size=con.getint("para", "batch_size"),
                                    mix_batch=True))

device = torch.device("cuda:0")

mention_detect = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=2, inner_dim=128, RoPE=True).to(device)#实体关系抽取任务默认不提取实体类型
s_o_head = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=len(schema), inner_dim=128, RoPE=False, tril_mask=False).to(device)
s_o_tail = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=len(schema), inner_dim=128, RoPE=False, tril_mask=False).to(device)

class ERENet(nn.Module):
    def __init__(self, encoder, a, b, c):
        super(ERENet, self).__init__()
        self.mention_detect = a
        self.s_o_head = b
        self.s_o_tail = c
        self.encoder = encoder

    def forward(self, batch_token_ids, batch_mask_ids, batch_token_type_ids):
        outputs = self.encoder(batch_token_ids, batch_mask_ids, batch_token_type_ids)

        mention_outputs = self.mention_detect(outputs, batch_mask_ids)
        so_head_outputs = self.s_o_head(outputs, batch_mask_ids)
        so_tail_outputs = self.s_o_tail(outputs, batch_mask_ids)
        return mention_outputs, so_head_outputs, so_tail_outputs

net = ERENet(encoder, mention_detect, s_o_head, s_o_tail).to(device)

def set_optimizer(model, train_steps=None):
    param_optimizer = list(model.named_parameters())
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=2e-5,
                         warmup=0.01,
                         t_total=train_steps)
    return optimizer

def set_group_optimizer(model_list, train_steps=None):
    param_optimizer = []
    for model in model_list:
        param_optimizer.extend(list(model.named_parameters()))
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=2e-5,
                         warmup=0.01,
                         t_total=train_steps)
    return optimizer

optimizer = set_optimizer(net, train_steps= (int(largest_size*len(total_train_dataset) / con.getint("para", "batch_size")) + 1) * con.getint("para", "epochs"))
linear_optimizer = set_group_optimizer([s_o_head, s_o_tail], train_steps= (int(largest_size*len(total_train_dataset) / con.getint("para", "batch_size")) + 1) * con.getint("para", "epochs"))

print(len(train_loader), "===batch-num===")

output_path = args_path['output_path']
import time, os
local_time_ticket = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime(time.time()))
logger.addHandler(logging.FileHandler(os.path.join(output_path, "train_{}.log".format(local_time_ticket)), 'w'))

def extract_spoes(text, threshold=0):
    """抽取输入text所包含的三元组
    """
    token2char_span_mapping = tokenizer(text, return_offsets_mapping=True, max_length=256)["offset_mapping"]
    new_span, entities = [], []
    for i in token2char_span_mapping:
        if i[0] == i[1]:
            new_span.append([])
        else:
            if i[0] + 1 == i[1]:
                new_span.append([i[0]])
            else:
                new_span.append([i[0], i[-1] - 1])
    encoder_txt = tokenizer.encode_plus(text, max_length=256)
    input_ids = torch.tensor(encoder_txt["input_ids"]).long().unsqueeze(0).to(device)
    token_type_ids = torch.tensor(encoder_txt["token_type_ids"]).unsqueeze(0).to(device)
    attention_mask = torch.tensor(encoder_txt["attention_mask"]).unsqueeze(0).to(device)
    
    scores = net(input_ids, attention_mask, token_type_ids)
    outputs = [o[0].data.cpu().numpy() for o in scores]
    subjects, objects = set(), set()
    outputs[0][:, [0, -1]] -= np.inf
    outputs[0][:, :, [0, -1]] -= np.inf
    for l, h, t in zip(*np.where(outputs[0] > 0)):
        if l == 0:
            subjects.add((h, t))
        else:
            objects.add((h, t))
    spoes = set()
    for sh, st in subjects:
        for oh, ot in objects:
            p1s = np.where(outputs[1][:, sh, oh] > threshold)[0]
            p2s = np.where(outputs[2][:, st, ot] > threshold)[0]
            ps = set(p1s) & set(p2s)
            for p in ps:
                spoes.add((
                    text[new_span[sh][0]:new_span[st][-1] + 1], id2schema[p],
                    text[new_span[oh][0]:new_span[ot][-1] + 1]
                ))
    spoes = list(spoes)
    spo_list = []
    for spo in spoes:
        """
        (spo["subject"], spo["predicate"], spo["object"][key], spo["subject_type"], spo["object_type"][key])
        """
        [subject_type, predicate, object_type] = spo[1].split('_')
        spo_list.append((spo[0], predicate, spo[-1], subject_type, object_type))
    return spo_list

class SPO(tuple):
    """用来存三元组的类
    表现跟tuple基本一致，只是重写了 __hash__ 和 __eq__ 方法，
    使得在判断两个三元组是否等价时容错性更好。
    """
    def __init__(self, spo):
        self.spox = (
            tuple(tokenizer.tokenize(spo[0])),
            spo[1],
            tuple(tokenizer.tokenize(spo[2])),
            spo[-1]
        )

    def __hash__(self):
        return self.spox.__hash__()

    def __eq__(self, spo):
        return self.spox == spo.spox


def evaluate(data, eo):
    """评估函数，计算f1、precision、recall
    """
    import os
    X, Y, Z = 1e-10, 1e-10, 1e-10
    dev_result_path = os.path.join(output_path, 'spo_life.pth.{}.dev'.format(eo))
    f = open(dev_result_path, 'w', encoding='utf-8')
    pbar = tqdm()
    for d in data:
        R = set([SPO(spo) for spo in extract_spoes(d['text'])])
        T = set([SPO(spo) for spo in d['spo_list']])
        X += len(R & T)
        Y += len(R)
        Z += len(T)
        f1, precision, recall = 2 * X / (Y + Z), X / Y, X / Z
        pbar.update()
        pbar.set_description(
            'f1: %.5f, precision: %.5f, recall: %.5f' % (f1, precision, recall)
        )
        s = json.dumps({
            'text': d['text'],
            'spo_list': list(T),
            'spo_list_pred': list(R),
            'new': list(R - T),
            'lack': list(T - R),
        },
                       ensure_ascii=False,
                       indent=4)
        f.write(s + '\n')
    pbar.close()
    f.close()
    return f1, precision, recall

total_loss, total_f1 = 0., 0.
for eo in range(con.getint("para", "linear_epochs")):
    total_loss = 0
    n_steps = 0
    for idx, batch in enumerate(train_loader):
        text, batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_entity_labels, batch_head_labels, batch_tail_labels = batch
        batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_entity_labels, batch_head_labels, batch_tail_labels = \
            batch_token_ids.to(device), batch_mask_ids.to(device), batch_token_type_ids.to(device), batch_entity_labels.to(device), batch_head_labels.to(device), batch_tail_labels.to(device)
        logits1, logits2, logits3 = net(batch_token_ids, batch_mask_ids, batch_token_type_ids)
                
        loss1 = sparse_multilabel_categorical_crossentropy(y_true=batch_entity_labels, y_pred=logits1, mask_zero=True)
        loss2 = sparse_multilabel_categorical_crossentropy(y_true=batch_head_labels, y_pred=logits2, mask_zero=True)
        loss3 = sparse_multilabel_categorical_crossentropy(y_true=batch_tail_labels, y_pred=logits3, mask_zero=True)
        loss = sum([loss1, loss2, loss3]) / 3
        linear_optimizer.zero_grad()
        loss.backward()
        linear_optimizer.step()
        total_loss += loss.item()
        n_steps += 1
        if np.mod(idx, 1000) == 0:
            logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)

total_loss, total_f1 = 0., 0.
for eo in range(con.getint("para", "epochs")):
    total_loss = 0
    n_steps = 0
    for idx, batch in enumerate(train_loader):
        text, batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_entity_labels, batch_head_labels, batch_tail_labels = batch
        batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_entity_labels, batch_head_labels, batch_tail_labels = \
            batch_token_ids.to(device), batch_mask_ids.to(device), batch_token_type_ids.to(device), batch_entity_labels.to(device), batch_head_labels.to(device), batch_tail_labels.to(device)
        logits1, logits2, logits3 = net(batch_token_ids, batch_mask_ids, batch_token_type_ids)
                
        loss1 = sparse_multilabel_categorical_crossentropy(y_true=batch_entity_labels, y_pred=logits1, mask_zero=True)
        loss2 = sparse_multilabel_categorical_crossentropy(y_true=batch_head_labels, y_pred=logits2, mask_zero=True)
        loss3 = sparse_multilabel_categorical_crossentropy(y_true=batch_tail_labels, y_pred=logits3, mask_zero=True)
        loss = sum([loss1, loss2, loss3]) / 3
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        n_steps += 1
        if np.mod(idx, 1000) == 0:
            logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)
    import os
    torch.save(net.state_dict(), os.path.join(output_path, 'spo_life.pth.{}'.format(eo)))
    
    for key in dev_data:
        f1, precision, recall = evaluate(dev_data[key], eo)
        logger.info(" epoch=%d, loss=%.5f , dataset=%s", eo, loss, key)
        logger.info("f1=%.5f, precision=%.5f, recall=%.5f, dataset=%s", f1, precision, recall, key)
    
    
    



