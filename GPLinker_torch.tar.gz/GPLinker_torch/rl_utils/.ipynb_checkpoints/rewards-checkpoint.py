

import torch
from collections import namedtuple
import numpy as np
import re, os
from scipy.optimize import linear_sum_assignment
import numpy as np
import os
import logging
import json

logger = logging.getLogger(__name__)
log = logger

from functools import reduce
def deleteDuplicate_v1(input_dict_lst):
    f = lambda x,y:x if y in x else x + [y]
    return reduce(f, [[], ] + input_dict_lst)

def get_tokens_seq_from_token_ids(token_ids, tokenizer):
    ''' Retruns tokens from a sequence of token ids '''

    tokens = []

    for seq_ids in token_ids.to('cpu').numpy().tolist():
        seq_toks = tokenizer.decode(
            seq_ids,
            skip_special_tokens=False,
            clean_up_tokenization_spaces=False
        )
        tokens.append(seq_toks)

    return tokens

def parse_single_triples(data, task_dict, schema_dict, **kargs):
    pred_list = []
    idx = kargs.get('idx', 0)
    
    remove_pad = re.sub('\\[PAD\\]', '', ''.join(data.split()))
    valid_strings = remove_pad.split('[SEP]')[0]
    
    decoded_token_group = re.split('(<T>)', valid_strings) # remove blank for easy evaluation
    for decoded_tokens in (decoded_token_group):
        if decoded_tokens in ['<T>']:
            continue
  
        pred_role_list_tmp = re.split('(\\[unused\d+\\])', decoded_tokens)
        start_index = 0
        end_index = 0
        
        pred_set = set()
        
        for role_index, pred_role in enumerate(pred_role_list_tmp):
            if re.search('(\\[unused\d+\\])', pred_role):
                pred_role_element = pred_role_list_tmp[start_index:role_index][0]
                # print(pred_role_list_tmp[start_index:role_index], '=======', pred_role_list_tmp[start_index:role_index][0], '====', idx)
                if pred_role_element:
                    pred_set.add((pred_role, pred_role_element))
                start_index = role_index + 1
        if pred_set:
            pred_list.append(pred_set)
    
    rank = int(os.environ.get("RANK", "0"))
    global_step = kargs.get('global_step', -1)
    # if rank == 0 and np.mod(global_step, 1000) == 0:
    #     print(pred_list, '=====', idx)
    pred_list = deleteDuplicate_v1(pred_list)
    return pred_list

def get_triples(data, task_dict, schema_dict, **kargs):
    triples_set = []
    for idx, sample in enumerate(data):
        triples = parse_single_triples(sample, task_dict, schema_dict, idx=idx, **kargs)
        triples_set.append(triples)
    return triples_set

def hungarian_matcher_instance(predicted_set_list, target_set_list, **kargs):
    """
    match single-instance predict and target set
    """
    parser_target = kargs.get('parser_target', 'none')
    idx = kargs.get('idx', 0)
    cost_spans = np.zeros((len(predicted_set_list), len(target_set_list))).astype(np.float32)
    
    for p_index, predict_set in enumerate(predicted_set_list):
        X, Y, Z = 0.0, 0.0, 0.0
        for q_index, target_set in enumerate(target_set_list):
            X += len(predict_set & target_set)
            Y += len(predict_set)
            Z += len(target_set)
            f_score = 2 * (X + 1e-10) / (Y + Z + 1e-10)
            cost_spans[p_index, q_index] = 1.0 - f_score
    indices = linear_sum_assignment(cost_spans)
    
    rank = int(os.environ.get("RANK", "0"))
    global_step = kargs.get('global_step', -1)
    
    idx_preds, idx_targets = indices
    X, Y, Z = 0.0, 0.0, 0.0
    for idx_pred, idx_target in zip(idx_preds, idx_targets):
        pred_set = predicted_set_list[idx_pred]
        target_set = target_set_list[idx_target]
        
        X += len(pred_set & target_set)
        Y += len(pred_set)
        Z += len(target_set)
        
    if rank == 0 and np.mod(global_step, 1000) == 0:
        print(predicted_set_list, '==predicted_set_list==', parser_target, '=====', idx)
        print(target_set_list, '==target_set_list==', '=====', idx)
        print(indices, '==indices==', '====', idx)
        f1, precision, recall = 2 * (X) / (Y + Z + 1e-10), (X) / (Y+1e-10), (X) / (Z+1e-10)
        print('==match==score', f1, precision, recall)
        
    # add false-positive
    for idx_pred, pred_set in enumerate(predicted_set_list):
        if idx_pred not in idx_preds:
            Y += len(pred_set)
    
    # add true-negative
    for idx_target, target_set in enumerate(target_set_list):
        if idx_target not in idx_targets:
            Z += len(target_set)
            
    f1, precision, recall = 2 * (X ) / (Y + Z + 1e-10), (X ) / (Y+1e-10), (X) / (Z+1e-10)

    rank = int(os.environ.get("RANK", "0"))
    global_step = kargs.get('global_step', -1)
    if rank == 0 and np.mod(global_step, 1000) == 0:
        print(f1, precision, recall, '==f1, precision, recall==', parser_target, '=====', idx)
    
    return {'f1':f1, 'precision':precision, 'recall':recall}
    

def hungarian_matcher(predicted_set_list, target_set_list, **kargs):
    """
    Args:
        predictions: prediction of one arg role type, list of [s,e]
        targets: target of one arg role type, list of [s,e]
    Return:
        (index_i, index_j) where index_i in prediction, index_j in target 
    """
    parser_target = kargs.get('parser_target', 'none')
    rank = int(os.environ.get("RANK", "0"))
    global_step = kargs.get('global_step', -1)
    # if rank == 0 and np.mod(global_step, 1000) == 0:
    #     print(len(predicted_set_list), len(target_set_list), '====', parser_target)
    
    # L1 cost between spans
    score_dict = {
        'f1':[],
        'precision':[],
        'recall':[]
    }
    for idx, (predict_set_list_, target_set_list_) in enumerate(zip(predicted_set_list, target_set_list)):
        output = hungarian_matcher_instance(predict_set_list_, target_set_list_, idx=idx, **kargs)
        for key in output:
            score_dict[key].append(output[key])
    
    for key in score_dict:
        score_dict[key] = np.array(score_dict[key])
    return score_dict
    
def self_critical_reward_triple(source_seq, greedy_seq, target_seq, sample_seq, tokenizer, task_dict, schema_dict, exact_F1_weight=1.0, normalize_weights=True,
                            **kargs):
    
    """
    https://github.com/IBM/regen
    Computes SCST reward for triple given greedy decode results (greedy_seq), ground_truth (target_seq)
    and generated sample results (sample_seq)
    https://arxiv.org/pdf/1705.04304.pdf
    """
    
    exact_F1_reward = 0.0

    rewards = {}
    weights = []
    scores = []
    
    bsize = len(target_seq)

    greedy_seq_fmt = get_triples(greedy_seq, task_dict, schema_dict, parser_target='greedy', **kargs)
    target_seq_fmt = get_triples(target_seq, task_dict, schema_dict, parser_target='target', **kargs)
    sample_seq_fmt = get_triples(sample_seq, task_dict, schema_dict, parser_target='sample', **kargs)
    
    rank = int(os.environ.get("RANK", "0"))
    global_step = kargs.get('global_step', -1)
    if np.mod(global_step, 1000) == 0 and rank == 0:
        for idx in range(len(target_seq)):
            print('==greedy_seq==', greedy_seq_fmt[idx], '====greedy_seq=====', greedy_seq[idx], '=====', rank, source_seq[idx])
            print('==target_seq==', target_seq_fmt[idx], '====target_seq=====', target_seq[idx], '=====', rank, source_seq[idx])
            print('==sample_seq==', sample_seq_fmt[idx], '====sample_seq=====', sample_seq[idx], '=====', rank, source_seq[idx])

    score_sample = hungarian_matcher(sample_seq_fmt, target_seq_fmt, parser_target='sample', **kargs)
    score_greedy = hungarian_matcher(greedy_seq_fmt, target_seq_fmt, parser_target='greedy', **kargs)
    
    rewards['exact_F1_greedy'] = score_greedy['f1']
    rewards['exact_F1_sample'] = score_sample['f1']
    
    exact_F1_reward = score_sample['f1'] - score_greedy['f1']
    
    if np.mod(global_step, 1000) == 0 and rank == 0:
        print(exact_F1_reward, '=====exact_F1_reward=====', score_sample['f1'], '===sample==', '==greedy==', score_greedy['f1'])

    weights.append(exact_F1_weight)
    scores.append(exact_F1_reward)

    # reward
    reward = np.zeros((bsize), np.float32)
    norm = sum(weights) if normalize_weights else 1.0

    for weight, score in zip(weights, scores):
        reward += weight / norm * score

    return {'reward': reward, 'rewards': rewards}
    
    
    
    
    
    
        
        