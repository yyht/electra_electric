# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys
import numpy as np
import torch.nn as nn
from nets.gpNet import RawGlobalPointer, sparse_multilabel_categorical_crossentropy, EfficientGlobalPointer
from transformers import BertTokenizerFast, BertModel
from utils.dataloader_duee import data_generator, load_name
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
import logging
from itertools import groupby
from tqdm import tqdm

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
con.read('./config_duee_fin_roformer_large.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained(args_path["model_path"], do_lower_case=True)
from roformer import RoFormerModel
encoder = RoFormerModel.from_pretrained(args_path["model_path"])

from roformer import RoFormerModel, RoFormerConfig
config = RoFormerConfig.from_pretrained(args_path["model_path"])


with open(args_path["schema_data"], 'r', encoding='utf-8') as f:
    """
    {"event_type": "财经/交易-出售/收购", "role_list": [{"role": "时间"}, {"role": "出售方"}, {"role": "交易物"}, {"role": "出售价格"}, {"role": "收购方"}], "id": "804336473abe8b8124d00876a5387151", "class": "财经/交易"}
    """
    schema = {}
    enum_roles, enum_items = [], {}
    idx = 0
    for _, item in enumerate(f):
        item = json.loads(item.rstrip())
        t = item['event_type']
        schema[(t, u'触发词')] = idx
        idx += 1
        for s in item['role_list']:
            if 'enum_items' in s:
                enum_roles.append((t, s['role']))
                for r in s['enum_items']:
                    schema[(t, r)] = idx
                    idx += 1
                    enum_items[(t, r)] = (t, s['role'])
            else:
                schema[(t, s['role'])] = idx
                idx += 1

id2schema = {}
for k,v in schema.items(): id2schema[v]=k

device = torch.device("cuda:0")
mention_detect = EfficientGlobalPointer(hidden_size=config.hidden_size, heads=len(schema), head_size=64, RoPE=True).to(device)#实体关系抽取任务默认不提取实体类型
s_o_head = EfficientGlobalPointer(hidden_size=config.hidden_size, heads=1, head_size=64, RoPE=False).to(device)
s_o_tail = EfficientGlobalPointer(hidden_size=config.hidden_size, heads=1, head_size=64, RoPE=False).to(device)

class ERENet(nn.Module):
    def __init__(self, encoder, a, b, c):
        super(ERENet, self).__init__()
        self.mention_detect = a
        self.s_o_head = b
        self.s_o_tail = c
        self.encoder = encoder

    def forward(self, batch_token_ids, batch_mask_ids, batch_token_type_ids):
        outputs = self.encoder(batch_token_ids, batch_mask_ids, batch_token_type_ids)

        mention_outputs = self.mention_detect(outputs, batch_mask_ids)
        so_head_outputs = self.s_o_head(outputs, batch_mask_ids)
        so_tail_outputs = self.s_o_tail(outputs, batch_mask_ids)
        return mention_outputs, so_head_outputs, so_tail_outputs

net = ERENet(encoder, mention_detect, s_o_head, s_o_tail).to(device)

class DedupList(list):
    """定义去重的list
    """
    def append(self, x):
        if x not in self:
            super(DedupList, self).append(x)

def neighbors(host, argus, links):
    """构建邻集（host节点与其所有邻居的集合）
    """
    results = [host]
    for argu in argus:
        if host[2:] + argu[2:] in links:
            results.append(argu)
    return list(sorted(results))


def clique_search(argus, links):
    """搜索每个节点所属的完全子图作为独立事件
    搜索思路：找出不相邻的节点，然后分别构建它们的邻集，递归处理。
    """
    Argus = DedupList()
    for i1, (_, _, h1, t1) in enumerate(argus):
        for i2, (_, _, h2, t2) in enumerate(argus):
            if i2 > i1:
                if (h1, t1, h2, t2) not in links:
                    Argus.append(neighbors(argus[i1], argus, links))
                    Argus.append(neighbors(argus[i2], argus, links))
    if Argus:
        results = DedupList()
        for A in Argus:
            for a in clique_search(A, links):
                results.append(a)
        return results
    else:
        return [list(sorted(argus))]

def extract_events(text, threshold=0, trigger=True):
    """抽取输入text所包含的所有事件
    """
    token2char_span_mapping = tokenizer(text, return_offsets_mapping=True, max_length=256)["offset_mapping"]
    new_span, entities = [], []
    for i in token2char_span_mapping:
        if i[0] == i[1]:
            new_span.append([])
        else:
            if i[0] + 1 == i[1]:
                new_span.append([i[0]])
            else:
                new_span.append([i[0], i[-1] - 1])
    
    encoder_txt = tokenizer.encode_plus(text, max_length=256)
    input_ids = torch.tensor(encoder_txt["input_ids"]).long().unsqueeze(0).to(device)
    token_type_ids = torch.tensor(encoder_txt["token_type_ids"]).unsqueeze(0).to(device)
    attention_mask = torch.tensor(encoder_txt["attention_mask"]).unsqueeze(0).to(device)
    scores = net(input_ids, attention_mask, token_type_ids)
    
    outputs = [o[0].data.cpu().numpy() for o in scores]
    # 抽取论元
    argus = set()
    outputs[0][:, [0, -1]] -= np.inf
    outputs[0][:, :, [0, -1]] -= np.inf
    for l, h, t in zip(*np.where(outputs[0] > threshold)):
        argus.add(id2schema[l] + (h, t))
    # 构建链接
    links = set()
    for i1, (_, _, h1, t1) in enumerate(argus):
        for i2, (_, _, h2, t2) in enumerate(argus):
            if i2 > i1:
                if outputs[1][0, min(h1, h2), max(h1, h2)] > threshold:
                    if outputs[2][0, min(t1, t2), max(t1, t2)] > threshold:
                        links.add((h1, t1, h2, t2))
                        links.add((h2, t2, h1, t1))
    # 析出事件
    events = []
    for _, sub_argus in groupby(sorted(argus), key=lambda s: s[0]):
        for event in clique_search(list(sub_argus), links):
            events.append([])
            for argu in event:
                start, end = new_span[argu[2]][0], new_span[argu[3]][-1] + 1
                events[-1].append(argu[:2] + (text[start:end], start))
            # if trigger and all([argu[1] != u'触发词' for argu in event]):
            #     events.pop()
    return events
import os
net = ERENet(encoder, mention_detect, s_o_head, s_o_tail).to(device)
# model_path = os.path.join(args_path['output_path'], 'event.pth.{}'.format(16))
# net.load_state_dict(torch.load(model_path))
# net.load_state_dict(torch.load('/data/albert.xht/DUEE_FIN_LITE/global_pointer/event.pth.{}'.format(17)))

eo = 16
output_path = args_path['output_path']
try:
    ckpt = torch.load(os.path.join(output_path, 'event.pth.{}'.format(eo)))
    net.load_state_dict(ckpt)
except:
    ckpt = torch.load(os.path.join(output_path, 'event.pth.{}'.format(eo)))
    new_ckpt = {}
    for key in ckpt:
        name = key.split('.')
        new_ckpt[".".join(name[1:])] = ckpt[key]
    net.load_state_dict(new_ckpt)

net.eval()

with open('/data/albert.xht/unified_generation/duuie_test_a-1.json.result.duee_fin.roformer.large', 'w') as fwobj: 
    with open('/data/albert.xht/unified_generation/duuie_test_a-1.json', 'r') as frobj:
        for line in frobj:
            content = json.loads(line.strip())
            if content['schema'] not in ['金融信息']:
                tmp_dict = {
                    'id':content['id'],
                    'entity': [],
                    'relation': [],
                    'event':[]
                }
                fwobj.write(json.dumps(tmp_dict, ensure_ascii=False)+'\n')
            else:
                if content['schema'] in ['金融信息']:
                    event_list = extract_events(content['text'], threshold=0)
                    tmp_dict = {
                        'id':content['id'],''
                        'entity': [],
                        'relation': [],
                        'event':[]
                    }
                    for event in event_list:
                        """
                        [('夺冠', '冠军', '沈阳小伙郭劲岐', 0)], [('夺冠', '夺冠赛事', '世锦赛选拔赛', 8)]
                        """
                        if event[0][0] not in ['中标', '亏损', '企业收购', '企业破产', '企业融资', '公司上市', '股东减持', '股东增持', '股份回购', 
                                               '被约谈', '解除质押', '质押', '高管变动']:
                            continue
                        event_dict = {
                            "type":event[0][0],
                            'text':"",
                            "args":[]

                        }
                        for item in event:
                            if item[1] == u'触发词':
                                event_dict['text'] = item[2]
                            else:
                                event_dict['args'].append({
                                    'type':item[1],
                                    'text':item[2]
                                })
                        if event_dict['args']:
                            tmp_dict['event'].append(event_dict)
                    fwobj.write(json.dumps(tmp_dict, ensure_ascii=False)+'\n')
                    
with open('/data/albert.xht/unified_generation/duuie_test_a-1.json.result.duee_fin.only.roformer.large', 'w') as fwobj: 
    with open('/data/albert.xht/unified_generation/duuie_test_a-1.json', 'r') as frobj:
        for line in frobj:
            content = json.loads(line.strip())
            if content['schema'] in ['金融信息']:
                event_list = extract_events(content['text'], threshold=0)
                tmp_dict = {
                    'id':content['id'],''
                    'entity': [],
                    'relation': [],
                    'event':[]
                }
                for event in event_list:
                    """
                    [('夺冠', '冠军', '沈阳小伙郭劲岐', 0)], [('夺冠', '夺冠赛事', '世锦赛选拔赛', 8)]
                    """
                    if event[0][0] not in ['中标', '亏损', '企业收购', '企业破产', '企业融资', '公司上市', '股东减持', '股东增持', '股份回购', 
                                           '被约谈', '解除质押', '质押', '高管变动']:
                        continue
                    event_dict = {
                        "type":event[0][0],
                        'text':"",
                        "args":[]

                    }
                    for item in event:
                        if item[1] == u'触发词':
                            event_dict['text'] = item[2]
                        else:
                            event_dict['args'].append({
                                'type':item[1],
                                'text':item[2]
                            })
                    if event_dict['args']:
                        tmp_dict['event'].append(event_dict)
                fwobj.write(json.dumps(tmp_dict, ensure_ascii=False)+'\n')
                 
