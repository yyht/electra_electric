# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys
import numpy as np
import torch.nn as nn
from transformers import BertTokenizerFast
from utils.seq2struct_dataloader import (data_generator_single_schema, 
                                         load_ie_schema, load_ee_schema, load_entity_schema, 
                                         load_entity, load_duie, load_duee,
                                        MultiTaskDataset, MultiTaskBatchSampler)
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
from multidataset_balanced_sampler import BalancedBatchSchedulerSampler
import logging
import torch
import io
import torch.nn.functional as F
import random
import numpy as np
import time
import math
import datetime
import torch.nn as nn
import logging
from torch.nn.modules.loss import _Loss
from tqdm import tqdm
from torch.utils.data.dataset import ConcatDataset

class LabelSmoothingLoss(_Loss):
    """
    With label smoothing,
    KL-divergence between q_{smoothed ground truth prob.}(w)
    and p_{prob. computed by model}(w) is minimized.
    """

    def __init__(self, label_smoothing=0, tgt_vocab_size=0, ignore_index=0, size_average=None, reduce=None, reduction='mean'):
        assert 0.0 < label_smoothing <= 1.0
        self.ignore_index = ignore_index
        super(LabelSmoothingLoss, self).__init__(
            size_average=size_average, reduce=reduce, reduction=reduction)

        assert label_smoothing > 0
        assert tgt_vocab_size > 0

        smoothing_value = label_smoothing / (tgt_vocab_size - 2)
        one_hot = torch.full((tgt_vocab_size,), smoothing_value)
        one_hot[self.ignore_index] = 0
        self.register_buffer('one_hot', one_hot.unsqueeze(0))
        self.confidence = 1.0 - label_smoothing
        self.tgt_vocab_size = tgt_vocab_size

    def forward(self, output, target):
        """
        output (FloatTensor): batch_size * num_pos * n_classes
        target (LongTensor): batch_size * num_pos
        """
        assert self.tgt_vocab_size == output.size(2)
        batch_size, num_pos = target.size(0), target.size(1)
        output = output.view(-1, self.tgt_vocab_size)
        target = target.reshape(-1)
        model_prob = self.one_hot.float().repeat(target.size(0), 1).to(output.device)
        model_prob.scatter_(1, target.unsqueeze(1), self.confidence)
        model_prob.masked_fill_((target == self.ignore_index).unsqueeze(1), 0)

        return F.kl_div(output, model_prob, reduction='none').view(batch_size, num_pos, -1).sum(2)

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
con.read('./config_unilm_large.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained('hfl/chinese-roberta-wwm-ext', do_lower_case=True)

print(tokenizer.tokenize('我是中国人[SEP]'), args_path['output_path'])

class MyUniLM(nn.Module):
    def __init__(self, config_path, model_path, eos_token_id, **kargs):
        super().__init__()
        
        from nets.unilm_bert import BertForCausalLM
        from transformers import BertConfig

        self.model_path = model_path
        self.config_path = config_path
        self.eos_token_id = eos_token_id
        
        self.config = BertConfig.from_pretrained(config_path)
        self.config.is_decoder = True
        self.config.eos_token_id = self.eos_token_id
        
        self.transformer = BertForCausalLM.from_pretrained(
                                pretrained_model_name_or_path=model_path,
                                config=self.config)
        
    def forward(self, input_ids, input_mask, segment_ids=None, mode='train', **kargs):
        if mode == "train":
            idxs = torch.cumsum(segment_ids, dim=1)
            attention_mask_3d = (idxs[:, None, :] <= idxs[:, :, None]).to(dtype=torch.float32)
            model_outputs = self.transformer(input_ids, 
                                             attention_mask=attention_mask_3d, 
                                             token_type_ids=segment_ids)
            return model_outputs # return prediction-scores
        elif mode == "generation":
            model_outputs = self.transformer.generate(
                                            input_ids=input_ids, 
                                            attention_mask=input_mask, 
                                            token_type_ids=segment_ids, 
                                            **kargs) # we need to generate output-scors
        return model_outputs

duie_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'信息抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True,
    "greedy_search":True,
    "schema_shuffle":False,
    "role_shuffle":False
}

duee_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'事件抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True,
    "greedy_search":False,
    "schema_shuffle":False,
    "role_shuffle":True
}

entity_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'实体抽取',
    'sentinel_start_idx':1,
    'add_schema_type':False,
    "greedy_search":False
}

schema = []
for schema_info in args_path["schema_data"].split(','):
    schema_type, schema_path = schema_info.split(':')
    print(schema_type, schema_path, '===schema-path===')
    if schema_type == 'duie':
        schema.extend(load_ie_schema(schema_path))
    elif schema_type == 'duee':
        schema.extend(load_ee_schema(schema_path))
    elif schema_type == 'entity':
        schema.extend(load_entity_schema(schema_path))
        
add_role_shuffle = True
        
total_train_dataset = []
largest_size = 0
for label_index, data_info in enumerate(args_path["train_file"].split(',')):
    data_type, data_path = data_info.split(':')
    print(data_type, data_path, '==data-path==')
    if data_type == 'duie':
        load_fn = load_duie
        task_dict = duie_task_dict
        dup_factor = 1
    elif data_type == 'duee':
        load_fn = load_duee
        task_dict = duee_task_dict
        dup_factor = 1
    elif data_type == 'entity':
        load_fn = load_entity
        task_dict = entity_task_dict
        dup_factor = 1
        
    data_list = load_fn(data_path)
    if len(data_list) <= 10000:
        data_list *= (3)
    
    data_list *= dup_factor
    
    train_dataset = data_generator_single_schema(data_list, tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, label=label_index,
                                                task_dict=task_dict, mode='train', add_role_shuffle=False)
    
    print(len(train_dataset), '==size of train_dataset==')
    if len(train_dataset) > largest_size:
        largest_size = len(train_dataset)
    total_train_dataset.append(train_dataset)
    collate_fn = train_dataset.collate_unilm
    
print(largest_size, '=====largest_size=====', len(train_dataset))
    
import random
# train_data = ConcatDataset(total_train_dataset)
# train_loader = DataLoader(train_data , batch_size=con.getint("para", "batch_size"), collate_fn=collate_fn,
#                          sampler=BalancedBatchSchedulerSampler(dataset=train_data,
#                                     batch_size=con.getint("para", "batch_size"),
#                                     mix_batch=True))
# data_size = largest_size*len(total_train_dataset)

train_data = ConcatDataset(total_train_dataset)
train_loader = DataLoader(train_data , batch_size=con.getint("para", "batch_size"), collate_fn=collate_fn,
                         shuffle=True)

data_size = len(train_data)

# train_data = MultiTaskDataset(total_train_dataset)
# multi_task_batch_sampler = MultiTaskBatchSampler(
#             total_train_dataset,
#             con.getint("para", "batch_size"),
#             mix_opt=0.1,
#             extra_task_ratio=0.0,
#         )
# train_loader = DataLoader(
#     train_data,
#     batch_sampler=multi_task_batch_sampler,
#     collate_fn=collate_fn
# )

data_size = len(train_data)

print("===size of dataset==", data_size)

device = torch.device("cuda:0")

def set_optimizer(model, train_steps=None):
    param_optimizer = list(model.named_parameters())
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=2e-5,
                         warmup=0.01,
                         t_total=train_steps)
    return optimizer

output_path = args_path['output_path']
import time, os
local_time_ticket = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime(time.time()))
logger.addHandler(logging.FileHandler(os.path.join(output_path, "train_{}.log".format(local_time_ticket)), 'w'))

net = MyUniLM(config_path=args_path["config_path"], 
              model_path=args_path["model_path"], 
              eos_token_id=duee_task_dict['end_token'])
net.to(device)
net.train()

import os
file_name_list = os.listdir(output_path)
model_name_list = []
for file_name in file_name_list:
    if 'unilm_mixture.pth' in file_name:
        model_name_list.append(file_name)

if model_name_list:
    latest_model = sorted(model_name_list)[-1]
    net.load_state_dict(torch.load(os.path.join(output_path, latest_model)))
    print('==loading latest model==', latest_model)

optimizer = set_optimizer(net, train_steps= (int(data_size / con.getint("para", "batch_size")) + 1) * con.getint("para", "epochs"))

total_loss, total_f1 = 0., 0.
label_smoothing = 0.1
for eo in range(con.getint("para", "epochs")):
    total_loss = 0
    n_steps = 0
    for idx, batch in enumerate(train_loader):
        batch_token_ids, batch_mask_ids, batch_token_type_ids = batch
        if idx == 0:
            print(tokenizer.decode(batch_token_ids[0]), batch_token_type_ids[0])
        
        batch_token_ids, batch_mask_ids, batch_token_type_ids = batch_token_ids.to(device), batch_mask_ids.to(device), batch_token_type_ids.to(device)
        
        model_outputs = net(input_ids=batch_token_ids, input_mask=batch_mask_ids, segment_ids=batch_token_type_ids, mode='train')
        logits = model_outputs[0]
        
        num_classes = logits.shape[-1]
        
        pred_logits = logits[:, :-1] # [batch_size, seq-1, num_classes]
        true_labels = batch_token_ids[:, 1:] # [batch_size, seq-1]
        y_mask = batch_token_type_ids[:, 1:].float() # [batch_size, seq-1]
        
        log_pred_logits = F.log_softmax(pred_logits, dim=-1)
        
        # [batch_size, seq-1]
        if label_smoothing > 0:
            lm_loss_fn = LabelSmoothingLoss(
                    label_smoothing, num_classes, ignore_index=0, reduction='none')
        else:
            lm_loss_fn = nn.CrossEntropyLoss(reduction='none')

        # [batch_size, seq-1]
        if label_smoothing > 0:
            loss_ = lm_loss_fn(log_pred_logits, true_labels)
        else:
            # sum over label-dim
            loss_ = lm_loss_fn(pred_logits.transpose(1, 2).float(), true_labels)
    
        loss = torch.sum(loss_ * y_mask) / (1e-12+torch.sum(y_mask))
        
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        n_steps += 1
        if np.mod(idx, 1000) == 0:
            logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)
    torch.save(net.state_dict(), os.path.join(output_path, 'unilm_mixture.pth.{}'.format(eo)))