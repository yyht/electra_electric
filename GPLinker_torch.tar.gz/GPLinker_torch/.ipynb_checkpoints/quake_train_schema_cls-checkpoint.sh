#!/usr/bin/env bash

# 运行本代码前请先安装quake-client客户端
# 安装方法见文档: https://yuque.antfin-inc.com/ulgf01/bbe97u/qxwvgv

model_folder=$1
model_tar=$2
requirements=$3

echo ${model_folder}

if [ ! -f ${model_tar} ]
then
  rm ${model_tar}
fi

# quake中本地上传文件时, 只支持tar压缩的文件
tar cvzf ${model_tar}  --exclude=${model_folder}/.DS_Store --exclude=${model_folder}/.git --exclude=${model_folder}/.idea ${model_folder} ${requirements}
code_path="file://${model_tar}"

project_name="volcano"
# 用户的工号
user_id="195865"
timestamp=$(date +%Y%m%d%H%M%S)
job_name="ner-generative-${timestamp}"
train_torch_image="reg.docker.alibaba-inc.com/algorithm/quake:torch-1.8.0-cuda102-cudnn7-centos7-train-v2.0"
train_tf_image="reg.docker.alibaba-inc.com/algorithm/quake:tensorflow-1.15-horovod"
train_torch_image="reg.docker.alibaba-inc.com/algorithm/quake:torch-1.8.2-cuda111-centos7-train-v2.0"
# train_torch_image="reg.docker.alibaba-inc.com/algorithm/quake:torch-1.8.0-cuda102-cudnn7-centos7-train-v2.1-elastic"
# 表示要用多少张卡进行训练

if [ ! -n "${instance_num}" ] ; then
    instance_num=1

fi
quakecmd train \
--emp_id ${user_id} \
--job_name "${job_name}" \
--project_name "${project_name}" \
--code_url "${code_path}" \
--training_image_path "${train_torch_image}" \
--entry_file "./GPLinker_torch/quake/quake_schema_sngp_cls.py" \
--train_node_num "${instance_num}" \
--training_start_params "" \
--gpu_type "3090" \
--training_inputs '/mnt/albert.xht:datastore:train-nas-part1:/albert.xht' \

