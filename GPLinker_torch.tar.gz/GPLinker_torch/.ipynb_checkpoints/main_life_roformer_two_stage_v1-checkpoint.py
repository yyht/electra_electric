# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys
import numpy as np
import torch.nn as nn
from nets.gpNet import RawGlobalPointer, sparse_multilabel_categorical_crossentropy, EfficientGlobalPointer
from transformers import BertTokenizerFast, BertModel
from utils.dataloader import data_generator_cls_then_extraction, load_name
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
import logging
from nets.sngp import SNGP
import torch.nn.functional as F
from nets import utils as net_utils
from tqdm import tqdm

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
con.read('./config_duie_life_roformer_two_stage.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained(args_path["model_path"], do_lower_case=True)

from roformer import RoFormerModel, RoFormerConfig
config = RoFormerConfig.from_pretrained(args_path["model_path"])

print(config, '=====')

with open(args_path["schema_data"], 'r', encoding='utf-8') as f:
    schema = {}
    for idx, item in enumerate(f):
        item = json.loads(item.rstrip())
        for key in item['object_type']:
            schema[item["subject_type"]+"_"+item["predicate"]+"_"+item['object_type'][key]] = idx
id2schema = {}
for k,v in schema.items(): id2schema[v]=k

print(schema)

device = torch.device("cuda:0")
seg_token = '[SEP]'

class DetectionStage(nn.Module):
    def __init__(self):
        super(DetectionStage, self).__init__()
        from roformer import RoFormerModel
        self.encoder = RoFormerModel.from_pretrained(args_path["model_path"])
        # self.mention_detect = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=2, inner_dim=128, RoPE=True).to(device)#实体关系抽取任务默认不提取实体类型
        # self.s_o_head = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=1, inner_dim=128, RoPE=False, tril_mask=False).to(device)
        # self.s_o_tail = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=1, inner_dim=128, RoPE=False, tril_mask=False).to(device)
        
        self.mention_detect = EfficientGlobalPointer(hidden_size=config.hidden_size, heads=2, head_size=128, RoPE=True).to(device)#实体关系抽取任务默认不提取实体类
        self.s_o_head = EfficientGlobalPointer(hidden_size=config.hidden_size, heads=1, head_size=128, RoPE=False, tril_mask=False).to(device)#实体关系抽取任务默认不提取实体类型
        self.s_o_tail = EfficientGlobalPointer(hidden_size=config.hidden_size, heads=1, head_size=128, RoPE=False, tril_mask=False).to(device)#实体关系抽取任务默认不提取实体类型
        
    def get_extra(self):
        return [self.mention_detect, self.s_o_head, self.s_o_tail]

    def forward(self, batch_token_ids, batch_mask_ids, batch_token_type_ids):
        outputs = self.encoder(batch_token_ids, batch_mask_ids, batch_token_type_ids)
        mention_outputs = self.mention_detect(outputs, batch_mask_ids)
        so_head_outputs = self.s_o_head(outputs, batch_mask_ids)
        so_tail_outputs = self.s_o_tail(outputs, batch_mask_ids)
        return mention_outputs, so_head_outputs, so_tail_outputs

class SNGPStage(nn.Module):
    def __init__(self):
        super(SNGPStage, self).__init__()
        from roformer import RoFormerModel
        self.encoder = RoFormerModel.from_pretrained(args_path["model_path"])
        self.sngp_layer = SNGP(
                 backbone=self.encoder,
                 hidden_size=config.hidden_size,
                 gp_kernel_scale=1.0,
                 num_inducing=1024,
                 gp_output_bias=0.,
                 layer_norm_eps=1e-12,
                 n_power_iterations=1,
                 spec_norm_bound=0.95,
                 scale_random_features=True,
                 normalize_input=True,
                 gp_cov_momentum=0.999,
                 gp_cov_ridge_penalty=1e-3,
                 epochs=40,
                 num_classes=len(schema),
                 device=device).to(device)
        
    def reset_cov(self):
        self.sngp_layer.reset_cov()

    def forward(self, batch_token_ids, batch_mask_ids, batch_token_type_ids, return_gp_cov=False, update_cov=False, forward_mode='training'):
        logits = self.sngp_layer(input_ids=batch_token_ids, token_type_ids=batch_token_type_ids,
                attention_mask = batch_mask_ids, return_gp_cov=return_gp_cov,
                update_cov=update_cov, forward_mode=forward_mode, mean_field_factor=0.1)
        return logits

def set_optimizer(model, train_steps=None):
    param_optimizer = list(model.named_parameters())
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=2e-5,
                         warmup=0.01,
                         t_total=train_steps)
    return optimizer

def set_group_optimizer(model_list, train_steps=None):
    param_optimizer = []
    for model in model_list:
        param_optimizer.extend(list(model.named_parameters()))
    param_optimizer = [n for n in param_optimizer if 'pooler' not in n[0]]
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=2e-5,
                         warmup=0.01,
                         t_total=train_steps)
    return optimizer

output_path = args_path['output_path']
import time, os
local_time_ticket = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime(time.time()))
logger.addHandler(logging.FileHandler(os.path.join(output_path, "train_{}.log".format(local_time_ticket)), 'w'))

def extract_p(net, text, threshold=0.5):
    """抽取输入text所包含的类型
    """
    token2char_span_mapping = tokenizer(text, return_offsets_mapping=True, max_length=256)["offset_mapping"]
    encoder_txt = tokenizer.encode_plus(text, max_length=256)
    input_ids = torch.tensor(encoder_txt["input_ids"]).long().unsqueeze(0).to(device)
    token_type_ids = torch.tensor(encoder_txt["token_type_ids"]).unsqueeze(0).to(device)
    attention_mask = torch.tensor(encoder_txt["attention_mask"]).unsqueeze(0).to(device)
    
    scores = net(input_ids, attention_mask, token_type_ids, 
                 return_gp_cov = True, update_cov=False,
                forward_mode = "inference")
    
    scores = torch.nn.Sigmoid()(scores)[0].data.cpu().numpy()
    
    spoes = set()
    for index, score in enumerate(scores):
        if score > threshold:
            spoes.add(id2schema[index])
    
    spoes = list(spoes)
    spo_list = []
    for p in spoes:
        """
        (spo["subject"], spo["predicate"], spo["object"][key], spo["subject_type"], spo["object_type"][key])
        """
        subject_type, predicate, object_type = p.split('_')
        spo_list.append(('_', predicate, '_', subject_type, object_type, p))
    return spo_list

def extract_spoes(net_detection, net_sngp, text, p_list=[], threshold=0, gold_p=True):
    """抽取输入text所包含的三元组
    """
    encoder_txt = tokenizer(text, return_offsets_mapping=True, max_length=256)
    token2char_span_mapping = encoder_txt["offset_mapping"]
    new_span, entities = [], []
    for i in token2char_span_mapping:
        if i[0] == i[1]:
            new_span.append([])
        else:
            if i[0] + 1 == i[1]:
                new_span.append([i[0]])
            else:
                new_span.append([i[0], i[-1] - 1])
                
    input_ids = encoder_txt["input_ids"]
    token_type_ids = encoder_txt["token_type_ids"]
    attention_mask = encoder_txt["attention_mask"]
    
    if not gold_p:
        if net_sngp:
            p_list = extract_p(net_sngp, text, threshold=0.5)
        else:
            p_list = []
            for p in schema:
                subject_type, predicate, object_type = p.split('_')
                p_list.append(('_', predicate, '_', subject_type, object_type, p))
    
    spo_list = []
    for p_key in p_list:
        p_ids = tokenizer(p_key[-1].replace('_', seg_token))['input_ids'][1:] #  [cls] text [sep] relation [sep]
        p_input_ids = torch.tensor(encoder_txt["input_ids"] + p_ids).long().unsqueeze(0).to(device)   
        p_token_type_ids = torch.tensor([0]*len(p_input_ids)).long().unsqueeze(0).to(device)
        p_attention_mask = torch.tensor([1]*len(p_input_ids)).long().unsqueeze(0).to(device)
        
        scores = net_detection(p_input_ids, p_attention_mask, p_token_type_ids)
        
        outputs = [o[0].data.cpu().numpy() for o in scores]
        subjects, objects = set(), set()
        outputs[0][:, [0, -1]] -= np.inf
        outputs[0][:, :, [0, -1]] -= np.inf

        subjects, objects = set(), set()
        for l, h, t in zip(*np.where(outputs[0] > 0)):
            if l == 0:
                subjects.add((h, t))
            else:
                objects.add((h, t))
                
        spoes = set()
        for sh, st in subjects:
            for oh, ot in objects:
                p1s = np.where(outputs[1][:, sh, oh] > threshold)[0]
                p2s = np.where(outputs[2][:, st, ot] > threshold)[0]
                ps = set(p1s) & set(p2s)
                for p in ps:
                    spoes.add((
                        text[new_span[sh][0]:new_span[st][-1] + 1], p_key[-1],
                        text[new_span[oh][0]:new_span[ot][-1] + 1]
                    ))
        spoes = list(spoes)
        for spo in spoes:
            """
            (spo["subject"], spo["predicate"], spo["object"][key], spo["subject_type"], spo["object_type"][key])
            """
            [subject_type, predicate, object_type] = spo[1].split('_')
            spo_list.append((spo[0], predicate, spo[-1], subject_type, object_type))
    return spo_list

class SPO(tuple):
    """用来存三元组的类
    表现跟tuple基本一致，只是重写了 __hash__ 和 __eq__ 方法，
    使得在判断两个三元组是否等价时容错性更好。
    """
    def __init__(self, spo):
        self.spox = (
            tuple(tokenizer.tokenize(spo[0])),
            spo[1],
            tuple(tokenizer.tokenize(spo[2])),
            spo[-1]
        )

    def __hash__(self):
        return self.spox.__hash__()

    def __eq__(self, spo):
        return self.spox == spo.spox
    
class Predicate(tuple):
    """用来存三元组的类
    表现跟tuple基本一致，只是重写了 __hash__ 和 __eq__ 方法，
    使得在判断两个三元组是否等价时容错性更好。
    """
    def __init__(self, spo):
        self.spox = (
            spo[1],
            spo[3],
            spo[4]
        )

    def __hash__(self):
        return self.spox.__hash__()

    def __eq__(self, spo):
        return self.spox == spo.spox

def evaluate_predicate(data, eo, net_sngp):
    import os
    X, Y, Z = 1e-10, 1e-10, 1e-10
    dev_result_path = os.path.join(output_path, 'spo_life.pth.{}.dev'.format(eo))
    f = open(dev_result_path, 'w', encoding='utf-8')
    pbar = tqdm()
    for index, d in enumerate(data):
        R = set([Predicate(spo) for spo in extract_p(net_sngp, d['text'])])
        T = set([Predicate(spo) for spo in d['spo_list']])
        
        X += len(R & T)
        Y += len(R)
        Z += len(T)
        f1, precision, recall = 2 * X / (Y + Z), X / Y, X / Z
        pbar.update()
        pbar.set_description(
            'f1: %.5f, precision: %.5f, recall: %.5f' % (f1, precision, recall)
        )
        s = json.dumps({
            'text': d['text'],
            'spo_list': list(T),
            'spo_list_pred': list(R),
            'new': list(R - T),
            'lack': list(T - R),
        },
                       ensure_ascii=False,
                       indent=4)
        f.write(s + '\n')
    pbar.close()
    f.close()
    return f1, precision, recall
        

def evaluate_spoes(data, eo, net_detection, net_sngp):
    """评估函数，计算f1、precision、recall
    """
    import os
    X, Y, Z = 1e-10, 1e-10, 1e-10
    dev_result_path = os.path.join(output_path, 'spo_life.pth.{}.dev'.format(eo))
    f = open(dev_result_path, 'w', encoding='utf-8')
    pbar = tqdm()
    for d in data:
        if net_sngp is None:
            p_list = []
            for spo in d['spo_list']:
                p_list.append(('_', spo[1], '_', spo[3], spo[4], "_".join([spo[3], spo[1], spo[4]])))
            R = set([SPO(spo) for spo in extract_spoes(net_detection, net_sngp, d['text'], p_list=p_list)])
        else:
            R = set([SPO(spo) for spo in extract_spoes(net_detection, net_sngp, d['text'], p_list=[])])
        T = set([SPO(spo) for spo in d['spo_list']])
        X += len(R & T)
        Y += len(R)
        Z += len(T)
        f1, precision, recall = 2 * X / (Y + Z), X / Y, X / Z
        pbar.update()
        pbar.set_description(
            'f1: %.5f, precision: %.5f, recall: %.5f' % (f1, precision, recall)
        )
        s = json.dumps({
            'text': d['text'],
            'spo_list': list(T),
            'spo_list_pred': list(R),
            'new': list(R - T),
            'lack': list(T - R),
        },
                       ensure_ascii=False,
                       indent=4)
        f.write(s + '\n')
    pbar.close()
    f.close()
    return f1, precision, recall

def train_and_evaluate_detection():
    
    net = DetectionStage()
    net_extra = net.get_extra()
    net = net.to(device)
    
    train_data = data_generator_cls_then_extraction(load_name(args_path["train_file"]), tokenizer, 
                                                    max_len=con.getint("para", "maxlen"), schema=schema, 
                                                    mode='p_extraction',
                                                    seg_token=seg_token)
    dev_data = load_name(args_path["val_file"])
    
    optimizer = set_optimizer(net, train_steps= (int(len(train_data) / con.getint("para", "batch_size")) + 1) * con.getint("para", "epochs"))
    linear_optimizer = set_group_optimizer(net_extra, train_steps= (int(len(train_data) / con.getint("para", "batch_size")) + 1) * con.getint("para", "linear_epochs"))

    train_loader = DataLoader(train_data , batch_size=con.getint("para", "batch_size"), shuffle=True, collate_fn=train_data.collate_p_extraction)

    total_loss, total_f1 = 0., 0.
    best_f1 = 0.0
    best_epoch = 0.0
    for eo in range(con.getint("para", "linear_epochs")):
        total_loss = 0
        n_steps = 0
        for idx, batch in enumerate(train_loader):
            text, batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_entity_labels, batch_head_labels, batch_tail_labels = batch
            batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_entity_labels, batch_head_labels, batch_tail_labels = \
                batch_token_ids.to(device), batch_mask_ids.to(device), batch_token_type_ids.to(device), batch_entity_labels.to(device), batch_head_labels.to(device), batch_tail_labels.to(device)
            logits1, logits2, logits3 = net(batch_token_ids, batch_mask_ids, batch_token_type_ids)

            loss1 = sparse_multilabel_categorical_crossentropy(y_true=batch_entity_labels, y_pred=logits1, mask_zero=True)
            loss2 = sparse_multilabel_categorical_crossentropy(y_true=batch_head_labels, y_pred=logits2, mask_zero=True)
            loss3 = sparse_multilabel_categorical_crossentropy(y_true=batch_tail_labels, y_pred=logits3, mask_zero=True)
            loss = sum([loss1, loss2, loss3]) / 3
            linear_optimizer.zero_grad()
            loss.backward()
            linear_optimizer.step()
            total_loss += loss.item()
            n_steps += 1
            if np.mod(idx, 1000) == 0:
                logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)

    total_loss, total_f1 = 0., 0.
    for eo in range(con.getint("para", "epochs")):
        total_loss = 0
        n_steps = 0
        for idx, batch in enumerate(train_loader):
            text, batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_entity_labels, batch_head_labels, batch_tail_labels = batch
            batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_entity_labels, batch_head_labels, batch_tail_labels = \
                batch_token_ids.to(device), batch_mask_ids.to(device), batch_token_type_ids.to(device), batch_entity_labels.to(device), batch_head_labels.to(device), batch_tail_labels.to(device)
            logits1, logits2, logits3 = net(batch_token_ids, batch_mask_ids, batch_token_type_ids)
            loss1 = sparse_multilabel_categorical_crossentropy(y_true=batch_entity_labels, y_pred=logits1, mask_zero=True)
            loss2 = sparse_multilabel_categorical_crossentropy(y_true=batch_head_labels, y_pred=logits2, mask_zero=True)
            loss3 = sparse_multilabel_categorical_crossentropy(y_true=batch_tail_labels, y_pred=logits3, mask_zero=True)
            loss = sum([loss1, loss2, loss3]) / 3
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
            n_steps += 1
            if np.mod(idx, 1000) == 0:
                logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)
        import os
        torch.save(net.state_dict(), os.path.join(output_path, 'spo_detection.pth.{}'.format(eo)))

        f1, precision, recall = evaluate_spoes(dev_data, eo, net, net_sngp=None)
        
        logger.info(" epoch=%d, loss=%.5f ", eo, loss)
        logger.info("f1=%.5f, precision=%.5f, recall=%.5f", f1, precision, recall)
    
        if f1 > best_f1:
            best_f1 = f1
            best_epoch = eo

def train_and_evaluate_cls():
    
    import os
    
    net = SNGPStage()
    net = net.to(device)
    
    train_data = data_generator_cls_then_extraction(load_name(args_path["train_file"]), tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, 
                                            mode='cls',
                                            seg_token=seg_token
                                            )
    dev_data = load_name(args_path["val_file"])
    
    optimizer = set_optimizer(net, train_steps= (int(len(train_data) / con.getint("para", "batch_size")) + 1) * con.getint("para", "epochs"))

    train_loader = DataLoader(train_data , batch_size=con.getint("para", "batch_size"), shuffle=True, collate_fn=train_data.collate_cls_nli)

    total_loss, total_f1 = 0., 0.
    best_f1 = 0.0
    best_epoch = 0.0
    for eo in range(con.getint("para", "epochs")):
        total_loss = 0
        n_steps = 0
        
        net.train()
        
        for idx, batch in enumerate(train_loader):
            text, batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_labels = batch
            batch_labels = batch_labels.float()
                                    
            batch_token_ids, batch_mask_ids, batch_token_type_ids, batch_labels = \
                batch_token_ids.to(device), batch_mask_ids.to(device), batch_token_type_ids.to(device), batch_labels.to(device)
            logits = net(batch_token_ids, batch_mask_ids, batch_token_type_ids, return_gp_cov=False, update_cov=True, forward_mode='training')
            
            loss = torch.nn.BCEWithLogitsLoss()(logits, batch_labels)
            loss = torch.mean(loss)
            
            net.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
            n_steps += 1
            if np.mod(idx, 1000) == 0:
                logger.info(" epoch=%d, loss=%.5f ", eo, total_loss/n_steps)
        import os
        torch.save(net.state_dict(), os.path.join(output_path, 'spo_cls.pth.{}'.format(eo)))
        net.eval()
        f1, precision, recall = evaluate_predicate(dev_data, eo, net)
        logger.info(" epoch=%d, loss=%.5f ", eo, loss)
        logger.info("f1=%.5f, precision=%.5f, recall=%.5f", f1, precision, recall)
    
        if f1 > best_f1:
            best_f1 = f1
            best_epoch = eo
            
        net.reset_cov()

# train_and_evaluate_cls()
train_and_evaluate_detection()


# net_detection = DetectionStage()
# net_detection = net_detection.to(device)

# net_sngp = SNGPStage()
# net_sngp = net_sngp.to(device)
    

