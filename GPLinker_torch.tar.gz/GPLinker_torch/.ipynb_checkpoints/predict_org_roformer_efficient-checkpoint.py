# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys
import numpy as np
import torch.nn as nn
from nets.gpNet import RawGlobalPointer, sparse_multilabel_categorical_crossentropy, EfficientGlobalPointer
from transformers import BertTokenizerFast, BertModel
from utils.dataloader import data_generator, load_name
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
import logging
from tqdm import tqdm

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
con.read('./config_duie_org_roformer_large_efficient.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained(args_path["model_path"], do_lower_case=True)
from roformer import RoFormerModel
encoder = RoFormerModel.from_pretrained(args_path["model_path"])

from roformer import RoFormerModel, RoFormerConfig
config = RoFormerConfig.from_pretrained(args_path["model_path"])

with open(args_path["schema_data"], 'r', encoding='utf-8') as f:
    schema = {}
    for idx, item in enumerate(f):
        item = json.loads(item.rstrip())
        for key in item['object_type']:
            schema[item["subject_type"]+"_"+item["predicate"]+"_"+item['object_type'][key]] = idx
            
print(schema)

id2schema = {}
for k,v in schema.items(): id2schema[v]=k

device = torch.device("cuda:0")

mention_detect = EfficientGlobalPointer(hidden_size=config.hidden_size, heads=2, head_size=128, RoPE=True).to(device)#实体关系抽取任务默认不提取实体类
s_o_head = EfficientGlobalPointer(hidden_size=config.hidden_size, heads=len(schema), head_size=128, RoPE=False, tril_mask=False).to(device)#实体关系抽取任务默认不提取实体类型
s_o_tail = EfficientGlobalPointer(hidden_size=config.hidden_size, heads=len(schema), head_size=128, RoPE=False, tril_mask=False).to(device)#实体关系抽取任务默认不提取实体类型

# mention_detect = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=2, inner_dim=128, RoPE=True).to(device)#实体关系抽取任务默认不提取实体类型
# s_o_head = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=len(schema), inner_dim=128, RoPE=False, tril_mask=False).to(device)
# s_o_tail = RawGlobalPointer(hiddensize=config.hidden_size, ent_type_size=len(schema), inner_dim=128, RoPE=False, tril_mask=False).to(device)

class ERENet(nn.Module):
    def __init__(self, encoder, a, b, c):
        super(ERENet, self).__init__()
        self.mention_detect = a
        self.s_o_head = b
        self.s_o_tail = c
        self.encoder = encoder

    def forward(self, batch_token_ids, batch_mask_ids, batch_token_type_ids):
        outputs = self.encoder(batch_token_ids, batch_mask_ids, batch_token_type_ids)

        mention_outputs = self.mention_detect(outputs, batch_mask_ids)
        so_head_outputs = self.s_o_head(outputs, batch_mask_ids)
        so_tail_outputs = self.s_o_tail(outputs, batch_mask_ids)
        return mention_outputs, so_head_outputs, so_tail_outputs

import os
net = ERENet(encoder, mention_detect, s_o_head, s_o_tail).to(device)
model_path = os.path.join(args_path['output_path'], 'spo_life.pth.{}'.format(16))
net.load_state_dict(torch.load(model_path))
# net.load_state_dict(torch.load('./erenet.pth'))
# net.load_state_dict(torch.load('/data/albert.xht/DUIE_ORG_SPO/global_pointer/spo_org.pth.{}'.format(15)))
net.eval()

def extract_spoes(text, threshold=0):
    """抽取输入text所包含的三元组
    """
    token2char_span_mapping = tokenizer(text, return_offsets_mapping=True, max_length=256)["offset_mapping"]
    new_span, entities = [], []
    for i in token2char_span_mapping:
        if i[0] == i[1]:
            new_span.append([])
        else:
            if i[0] + 1 == i[1]:
                new_span.append([i[0]])
            else:
                new_span.append([i[0], i[-1] - 1])
    encoder_txt = tokenizer.encode_plus(text, max_length=256)
    input_ids = torch.tensor(encoder_txt["input_ids"]).long().unsqueeze(0).to(device)
    token_type_ids = torch.tensor(encoder_txt["token_type_ids"]).unsqueeze(0).to(device)
    attention_mask = torch.tensor(encoder_txt["attention_mask"]).unsqueeze(0).to(device)
    
    scores = net(input_ids, attention_mask, token_type_ids)
    outputs = [o[0].data.cpu().numpy() for o in scores]
    subjects, objects = set(), set()
    outputs[0][:, [0, -1]] -= np.inf
    outputs[0][:, :, [0, -1]] -= np.inf
    for l, h, t in zip(*np.where(outputs[0] > 0)):
        if l == 0:
            subjects.add((h, t))
        else:
            objects.add((h, t))
    spoes = set()
    for sh, st in subjects:
        for oh, ot in objects:
            p1s = np.where(outputs[1][:, sh, oh] > threshold)[0]
            p2s = np.where(outputs[2][:, st, ot] > threshold)[0]
            ps = set(p1s) & set(p2s)
            for p in ps:
                spoes.add((
                    text[new_span[sh][0]:new_span[st][-1] + 1], id2schema[p],
                    text[new_span[oh][0]:new_span[ot][-1] + 1]
                ))
    spoes = list(spoes)
    spo_list = []
    for spo in spoes:
        """
        (spo["subject"], spo["predicate"], spo["object"][key], spo["subject_type"], spo["object_type"][key])
        """
        [subject_type, predicate, object_type] = spo[1].split('_')
        spo_list.append((spo[0], predicate, spo[-1], subject_type, object_type))
    return spo_list

with open('/data/albert.xht/unified_generation/duuie_test_a-1.json.result.org.only.roformer.large.efficient.v1', 'w') as fwobj: 
    with open('/data/albert.xht/unified_generation/duuie_test_a-1.json', 'r') as frobj:
        for line in frobj:
            content = json.loads(line.strip())
            # if content['schema'] not in ['机构信息']:
            #     # tmp_dict = {
            #     #     'id':content['id'],
            #     #     'entity': [],
            #     #     'relation': [],
            #     #     'event':[]
            #     # }
            #     # fwobj.write(json.dumps(tmp_dict, ensure_ascii=False)+'\n')
            #     continue
            # else:
            if content['schema'] in ['机构信息']:
                spo_list = extract_spoes(content['text'], threshold=0)
                tmp_dict = {
                    'id':content['id'],
                    'entity': [],
                    'relation': [],
                    'event':[]
                }
                for spo in spo_list:
                    subject, predicate, objects, subject_type, object_type = spo
                    sub_dict = {
                        'type':predicate,
                        'args':[
                            {'type':subject_type, 'text':subject},
                            {'type':object_type, 'text':objects},
                        ]
                    }
                    tmp_dict['relation'].append(sub_dict)
                fwobj.write(json.dumps(tmp_dict, ensure_ascii=False)+'\n')