# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys
import numpy as np
import torch.nn as nn
from transformers import BertTokenizerFast
from utils.seq2struct_dataloader import (data_generator_single_schema, data_generator_single_schema_str,
                                         data_generator_single_schema_single_role, data_generator_element,
                                         data_generator_elemnt_group,
                                         load_ie_schema, load_ee_schema, load_entity_schema, 
                                         load_entity, load_duie, load_duee,
                                        MultiTaskDataset, MultiTaskBatchSampler)
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
from multidataset_balanced_sampler import BalancedBatchSchedulerSampler
import logging
import torch
import io
import torch.nn.functional as F
import random
import numpy as np
import time
import math
import datetime
import torch.nn as nn
import logging
from torch.nn.modules.loss import _Loss
from tqdm import tqdm
from torch.utils.data.dataset import ConcatDataset

con = configparser.ConfigParser()
con.read('./config_unilm.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained('hfl/chinese-roberta-wwm-ext', do_lower_case=True)

print(tokenizer.tokenize('我是中国人[SEP]'))

duie_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'信息抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True,
    'schema_shuffle': False,
    "role_shuffle":False,
    'role_schema_order': True,
    'element_start_idx': 20,
    'remove_dup':True
}

duee_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'事件抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True,
    'schema_shuffle': False,
    'role_schema_order': True,
    'element_start_idx': 20,
    'remove_dup':True,
    'span_pos_order': 'pos_order'
}

entity_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'实体抽取',
    'sentinel_start_idx':1,
    'add_schema_type':False,
    'role_schema_order':False,
    'remove_dup':True
}

element_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'要素值抽取',
    'sentinel_start_idx':1,
    'add_schema_type':False,
    "greedy_search":False,
    'role_schema_order': True,
    'remove_dup':True
}

schema = []
for schema_info in args_path["schema_data"].split(','):
    schema_type, schema_path = schema_info.split(':')
    print(schema_type, schema_path, '===schema-path===')
    if schema_type == 'duie':
        schema.extend(load_ie_schema(schema_path))
    elif schema_type == 'duee':
        schema.extend(load_ee_schema(schema_path))
    elif schema_type == 'entity':
        schema.extend(load_entity_schema(schema_path))
        
largest_size = 0
import re
dupe_factor = 1
add_role_shuffle = True
if add_role_shuffle:
    dupe_factor = 1
    
total_train_dataset = []
    
# with open('/data/albert.xht/unilm_general.train.txt.str.shuffle', 'w') as fwobj:
for label_index, data_info in enumerate(args_path["train_file"].split(',')):
    data_type, data_path = data_info.split(':')
    print(data_type, data_path, '==data-path==')
    if data_type == 'duie':
        load_fn = load_duie
        task_dict = duie_task_dict
        dupe_factor = 1
    elif data_type == 'duee':
        load_fn = load_duee
        task_dict = duee_task_dict
        dupe_factor = 1
    elif data_type == 'entity':
        load_fn = load_entity
        task_dict = entity_task_dict
        dupe_factor = 1

    
    if data_type in ['duee']:
        data_list = load_fn(data_path)

        if add_role_shuffle:
            data_list *= dupe_factor
        else:
            if len(data_list) <= 10000:
                data_list *= 3
    
        # for i, data in enumerate(data_list):
        train_dataset = data_generator_elemnt_group(data_list, tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, label=label_index,
                                                    task_dict=duee_task_dict, mode='train', add_role_shuffle=True)
        total_train_dataset.append(train_dataset)

        # for item in train_dataset:
        #     (text, instruction_input_ids, instruction_token_type_ids, instruction_attention_mask,
        #                span_input_ids, span_type_ids, span_attention_mask,
        #                schema_input_ids, schema_token_type_ids, schema_attention_mask,
        #                target_input_ids, target_token_type_ids, target_attention_mask) = item
        #     print(tokenizer.decode(span_input_ids), tokenizer.decode(schema_input_ids), tokenizer.decode(target_input_ids))

#         for item in train_dataset:
#             (instruction_strings, span_strings, schema_strings, target_strings) = item
        
#             input_string = instruction_strings + span_strings + schema_strings
#             input_string = re.sub('\n', ' ', input_string)
#             target_string = target_strings
#             target_string = re.sub('\n', ' ', target_string)

#             if target_string and target_string != ' ':
#                 fwobj.write("&&***&&".join([input_string, target_string])+'\n')
#             else:
#                 target_string = 'null'
#                 fwobj.write("&&***&&".join([input_string, target_string])+'\n')

from torch.utils.data.dataset import ConcatDataset
train_data = ConcatDataset(total_train_dataset)

# print(total_train_dataset[0].get_labels())

# labels = []
# for dataset in total_train_dataset:
#     print(len(dataset.get_labels()), dataset.get_labels()[0], '====')
#     labels.extend(dataset.get_labels())

from utils.class_balanced_sampler import BalanceClassSampler
# sampler_fn = BalanceClassSampler(labels=labels, mode='upsampling')  # here 2 modes: downsampling/upsampling

# print(len(sampler_fn), len(train_data), len(labels))

train_loader = torch.utils.data.DataLoader(
    train_data,
    batch_size=8,
    pin_memory=False,
    drop_last=True,
    collate_fn=train_dataset.collate_unilm
)

max_len = 0

for item in train_loader:
    input_ids, input_mask, input_segment = item
    for input_id in input_ids:
        lens = (torch.max(torch.sum(input_mask, dim=1)))
        if lens > max_len:
            max_len = lens
            
print(max_len)

# with open('/data/albert.xht/unilm_general.dev.txt.str', 'w') as fwobj:
#     for label_index, data_info in enumerate(args_path["val_file"].split(',')):
#         data_type, data_path = data_info.split(':')
#         print(data_type, data_path, '==data-path==')
#         if data_type == 'duie':
#             load_fn = load_duie
#             task_dict = duie_task_dict
#         elif data_type == 'duee':
#             load_fn = load_duee
#             task_dict = duee_task_dict
#         elif data_type == 'entity':
#             load_fn = load_entity
#             task_dict = entity_task_dict

#         data_list = load_fn(data_path)
#         train_dataset = data_generator_single_schema_str(data_list, tokenizer, max_len=con.getint("para", "maxlen"), schema=schema, label=label_index,
#                                                     task_dict=task_dict, mode='train', add_role_shuffle=False)

#         for item in train_dataset:
#             (instruction_strings, span_strings, schema_strings, target_strings) = item

#             input_string = instruction_strings + span_strings + schema_strings
#             input_string = re.sub('\n', ' ', input_string)
#             target_string = target_strings
#             target_string = re.sub('\n', ' ', target_string)

            # if target_string and target_string != ' ':
            #     fwobj.write("&&***&&".join([input_string, target_string])+'\n')
            # else:
            #     target_string = 'null'
            #     fwobj.write("&&***&&".join([input_string, target_string])+'\n')