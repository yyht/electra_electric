# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys, os
import numpy as np
import torch.nn as nn
from transformers import BertTokenizerFast
from utils.seq2struct_dataloader import (data_generator_single_schema, 
                                         load_ie_schema, load_ee_schema, load_entity_schema, 
                                         load_entity, load_duie, load_duee)
from torch.utils.data import DataLoader
import configparser
import re
from utils.bert_optimization import BertAdam
from multidataset_balanced_sampler import BalancedBatchSchedulerSampler
import logging
import torch
import io
import torch.nn.functional as F
import random
import numpy as np
import time
import math
import datetime
import torch.nn as nn
import logging
from torch.nn.modules.loss import _Loss
from tqdm import tqdm
from torch.utils.data.dataset import ConcatDataset

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
con.read('./config_unilm.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained('hfl/chinese-roberta-wwm-ext', do_lower_case=True)

print(tokenizer.tokenize('我是中国人[SEP]'))

class MyUniLM(nn.Module):
    def __init__(self, config_path, model_path, eos_token_id, **kargs):
        super().__init__()
        
        from nets.unilm_bert import BertForCausalLM
        from transformers import BertConfig

        self.model_path = model_path
        self.config_path = config_path
        self.eos_token_id = eos_token_id
        
        self.config = BertConfig.from_pretrained(config_path)
        self.config.is_decoder = True
        self.config.eos_token_id = self.eos_token_id
        
        self.transformer = BertForCausalLM.from_pretrained(
                                pretrained_model_name_or_path=model_path,
                                config=self.config)
        
    def forward(self, input_ids, input_mask, segment_ids=None, mode='train', **kargs):
        if mode == "train":
            idxs = torch.cumsum(segment_ids, dim=1)
            attention_mask_3d = (idxs[:, None, :] <= idxs[:, :, None]).to(dtype=torch.float32)
            model_outputs = self.transformer(input_ids, 
                                             attention_mask=attention_mask_3d, 
                                             token_type_ids=segment_ids)
            return model_outputs # return prediction-scores
        elif mode == "generation":
            model_outputs = self.transformer.generate(
                                            input_ids=input_ids, 
                                            attention_mask=input_mask, 
                                            token_type_ids=segment_ids, 
                                            **kargs) # we need to generate output-scors
        return model_outputs

duie_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'信息抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

duee_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'事件抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

entity_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'实体抽取',
    'sentinel_start_idx':1,
    'add_schema_type':False
}

schema_dict_list = []
for schema_info in args_path["schema_data"].split(','):
    schema_type, schema_path = schema_info.split(':')
    print(schema_type, schema_path, '===schema-path===')
    if schema_type == 'duie':
        schema_dict_list.extend(load_ie_schema(schema_path))
    elif schema_type == 'duee':
        schema_dict_list.extend(load_ee_schema(schema_path))
    elif schema_type == 'entity':
        schema_dict_list.extend(load_entity_schema(schema_path))
        

def search(pattern, sequence):
    """从sequence中寻找子串pattern
    如果找到，返回第一个下标；否则返回-1。
    """
    n = len(pattern)
    for i in range(len(sequence)):
        if sequence[i:i + n] == pattern:
            return i
    return -1

from collections import namedtuple
_DocSpan = namedtuple(  # pylint: disable=invalid-name
        "DocSpan", ["start", "length"])

def slide_window(all_doc_tokens, max_length, doc_stride, offset=32):
    doc_spans = []
    start_offset = 0
    while start_offset < len(all_doc_tokens):
        length = len(all_doc_tokens) - start_offset
        if length > max_length - offset:
            length = max_length - offset
        doc_spans.append(_DocSpan(start=start_offset, length=length))
        if start_offset + length == len(all_doc_tokens):
            break
        start_offset += min(length, doc_stride)
    return doc_spans

def extract(item, task_dict, all_schema_dict, target_type, max_len):
    text = item['text']
    
    # generate instruction input-ids
    instruction_strings = task_dict['instruction'] + task_dict['sep_token']

    schema_dict = all_schema_dict[target_type]
    if task_dict['add_schema_type']:
        schema_strings = target_type + task_dict['sep_token']
    else:
        schema_strings = ''
    for role in schema_dict['role2sentinel']:
        schema_strings += role + schema_dict['role2sentinel'][role] # role sentinel

    # schema_strings += task_dict['sep_token']
        
    output_list = []
    doc_spans = slide_window(text, max_len, 64, offset=32)
    for doc_span in doc_spans:
        span_start = doc_span.start
        span_end = doc_span.start + doc_span.length

        span_strings = text[span_start:span_end] + task_dict['sep_token']
        output_list.append((instruction_strings, span_strings, schema_strings))
    return output_list
    
def build_schema(task_dict, schema_dict_list):
    sentinel_token = task_dict['sentinel_token']
    sentinel_start_idx = task_dict['sentinel_start_idx']
    all_schema_dict = {}
    for schema_dict in schema_dict_list:
        if schema_dict['type'] not in all_schema_dict:
            all_schema_dict[schema_dict['type']] = {
                    'role2sentinel':{},
                    'sentinel2role':{},
                    'role2type':{},
                    'type2role':{}
            }
        for role_index, role_dict in enumerate(schema_dict['role_list']):
            role_type = role_dict['type'] + role_dict['role']
            all_schema_dict[schema_dict['type']]['role2sentinel'][role_type] = sentinel_token.format(role_index+sentinel_start_idx)
            all_schema_dict[schema_dict['type']]['sentinel2role'][sentinel_token.format(role_index+sentinel_start_idx)] = role_type
            all_schema_dict[schema_dict['type']]['role2type'][role_dict['role']] = role_type
            all_schema_dict[schema_dict['type']]['type2role'][role_type] = role_dict['role']
    return all_schema_dict

schema_mapping_dict = {
    '金融信息':'duee',
    '影视情感':'duie',
    '人生信息':'duie',
    '机构信息':'duie',
    '体育竞赛':'duee',
    '灾害意外':'duee'
}

with open('/data/albert.xht/unified_generation/duuie_test_a-1.json.result.m6.test', 'w') as fwobj: 
    with open('/data/albert.xht/unified_generation/duuie_test_a-1.json.result.cls', 'r') as frobj:
        for line in frobj:
            content = json.loads(line.strip())
            schema_type = content['schema']
            if schema_mapping_dict[schema_type] == 'duie':
                task_dict = duie_task_dict
            elif schema_mapping_dict[schema_type] == 'duee':
                task_dict = duee_task_dict
            all_schema_dict = build_schema(task_dict, schema_dict_list)
            
            for target_type in content['schema_type']:   
                output_list = extract(content, task_dict, all_schema_dict, target_type, max_len=256)
                for output in output_list:
                    (instruction_strings, span_strings, schema_strings) = output
                    input_string = instruction_strings + span_strings + schema_strings
                    input_string = re.sub('\n', ' ', input_string)
                    content['target_schema_type'] = target_type
                    fwobj.write("&&***&&".join([input_string, json.dumps(content, ensure_ascii=False)])+"\n")