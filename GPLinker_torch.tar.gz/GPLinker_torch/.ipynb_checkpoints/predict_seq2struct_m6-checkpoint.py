# -*- coding: utf-8 -*-
"""
@Auth: Xhw
@Description: token-pair范式的实体关系抽取pytorch实现
"""
import torch
import json
import sys, os
import numpy as np
import torch.nn as nn
from transformers import BertTokenizerFast
from utils.seq2struct_dataloader import (data_generator_single_schema, 
                                         load_ie_schema, load_ee_schema, load_entity_schema, 
                                         load_entity, load_duie, load_duee)
from torch.utils.data import DataLoader
import configparser
from utils.bert_optimization import BertAdam
from multidataset_balanced_sampler import BalancedBatchSchedulerSampler
import logging
import torch
import io
import torch.nn.functional as F
import random
import numpy as np
import time
import math
import datetime
import torch.nn as nn
import logging
from torch.nn.modules.loss import _Loss
from tqdm import tqdm
from torch.utils.data.dataset import ConcatDataset

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

con = configparser.ConfigParser()
con.read('./config_unilm.ini', encoding='utf8')
args_path = dict(dict(con.items('paths')), **dict(con.items("para")))
tokenizer = BertTokenizerFast.from_pretrained('hfl/chinese-roberta-wwm-ext', do_lower_case=True)

print(tokenizer.tokenize('我是中国人[SEP]'))

class MyUniLM(nn.Module):
    def __init__(self, config_path, model_path, eos_token_id, **kargs):
        super().__init__()
        
        from nets.unilm_bert import BertForCausalLM
        from transformers import BertConfig

        self.model_path = model_path
        self.config_path = config_path
        self.eos_token_id = eos_token_id
        
        self.config = BertConfig.from_pretrained(config_path)
        self.config.is_decoder = True
        self.config.eos_token_id = self.eos_token_id
        
        self.transformer = BertForCausalLM.from_pretrained(
                                pretrained_model_name_or_path=model_path,
                                config=self.config)
        
    def forward(self, input_ids, input_mask, segment_ids=None, mode='train', **kargs):
        if mode == "train":
            idxs = torch.cumsum(segment_ids, dim=1)
            attention_mask_3d = (idxs[:, None, :] <= idxs[:, :, None]).to(dtype=torch.float32)
            model_outputs = self.transformer(input_ids, 
                                             attention_mask=attention_mask_3d, 
                                             token_type_ids=segment_ids)
            return model_outputs # return prediction-scores
        elif mode == "generation":
            model_outputs = self.transformer.generate(
                                            input_ids=input_ids, 
                                            attention_mask=input_mask, 
                                            token_type_ids=segment_ids, 
                                            **kargs) # we need to generate output-scors
        return model_outputs

duie_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'信息抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

duee_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'事件抽取',
    'sentinel_start_idx':1,
    'add_schema_type':True
}

entity_task_dict = {
    'sep_token':'[SEP]',
    'seg_token':'<S>',
    'group_token':'<T>',
    'start_token':'[CLS]',
    'end_token':'[SEP]',
    'sentinel_token':'[unused{}]',
    'instruction':'实体抽取',
    'sentinel_start_idx':1,
    'add_schema_type':False
}

schema_dict_list = []
for schema_info in args_path["schema_data"].split(','):
    schema_type, schema_path = schema_info.split(':')
    print(schema_type, schema_path, '===schema-path===')
    if schema_type == 'duie':
        schema_dict_list.extend(load_ie_schema(schema_path))
    elif schema_type == 'duee':
        schema_dict_list.extend(load_ee_schema(schema_path))
    elif schema_type == 'entity':
        schema_dict_list.extend(load_entity_schema(schema_path))
        

def search(pattern, sequence):
    """从sequence中寻找子串pattern
    如果找到，返回第一个下标；否则返回-1。
    """
    n = len(pattern)
    for i in range(len(sequence)):
        if sequence[i:i + n] == pattern:
            return i
    return -1

def extract(item, task_dict, all_schema_dict, target_type, max_len):
    text = item['text']
    
    # generate input-ids
    encoder_text = tokenizer(text, return_offsets_mapping=True, max_length=max_len, truncation=True, add_special_tokens=False)
    input_ids = encoder_text["input_ids"]
    token_type_ids = encoder_text["token_type_ids"] #RoBERTa不需要NSP任务
    attention_mask = encoder_text["attention_mask"]

    # generate schema
    offset_mapping = encoder_text.offset_mapping
    
    return offset_mapping, input_ids
    
from utils.seq2struct_decoder import single_schema_decoder
decoder = single_schema_decoder(tokenizer, 256, schema_dict_list, label=0, 
                 task_dict=entity_task_dict, mode='train')

output_path = args_path['output_path']

def find_lcseque(s1, s2): 
     # 生成字符串长度加1的0矩阵，m用来保存对应位置匹配的结果
    m = [ [ 0 for x in range(len(s2)+1) ] for y in range(len(s1)+1) ] 
    # d用来记录转移方向
    d = [ [ None for x in range(len(s2)+1) ] for y in range(len(s1)+1) ] 

    for p1 in range(len(s1)): 
        for p2 in range(len(s2)): 
            if s1[p1] == s2[p2]:            #字符匹配成功，则该位置的值为左上方的值加1
                m[p1+1][p2+1] = m[p1][p2]+1
                d[p1+1][p2+1] = 'ok'          
            elif m[p1+1][p2] > m[p1][p2+1]:  #左值大于上值，则该位置的值为左值，并标记回溯时的方向
                m[p1+1][p2+1] = m[p1+1][p2] 
                d[p1+1][p2+1] = 'left'          
            else:                           #上值大于左值，则该位置的值为上值，并标记方向up
                m[p1+1][p2+1] = m[p1][p2+1]   
                d[p1+1][p2+1] = 'up'         
    (p1, p2) = (len(s1), len(s2)) 
    l = []
    while m[p1][p2]:    #不为None时
        c = d[p1][p2]
        if c == 'ok':   #匹配成功，插入该字符，并向左上角找下一个
            l.append(p1-1)
            p1-=1
            p2-=1 
        if c =='left':  #根据标记，向左找下一个
            p2 -= 1
        if c == 'up':   #根据标记，向上找下一个
            p1 -= 1
    l.reverse()
    if l:
        return s1[l[0]:l[-1]+1]
    else:
        return []

from collections import namedtuple
Result = namedtuple('Result', ['sequences'])

import re

def predict_seq2struct(data, target_type, target_list, task_dict, schema_dict):
    decoded_list = []  
    # [('丈夫', '人物', '赵楚'), ('丈夫', '人物', '柳思孝')]
    offset_mapping, ori_input_ids = extract(data, task_dict, schema_dict, target_type, max_len=256)
    text = data['text']
    for target in target_list:
        target = re.sub('<t>', '<T>', target)
        target = re.sub('(\[unk\])', '[UNK]', target)
        
        group_split = target.split('<T>')
        group_string = ''
        for target in group_split:
            if not target:
                continue
        
            target_split = re.split(r"(\[unused\d+\])", target)
            target_list = []
            for item in target_split:
                if re.search('(\[unused\d+\])', item):
                    target_list.append(item)
                    continue
                if '[UNK]' in item:
                    target_list.append(item)
                elif re.search('[a-z]+', item):
                    l = find_lcseque(text.lower(), item)
                    if l:
                        target_list.append(l)
                    else:
                        target_list.append(item)
                else:
                    target_list.append(item)
                
            target_string = "".join(target_list+['<T>'])
            group_string += target_string
        
        features = tokenizer(group_string, truncation=False, add_special_tokens=False)
        model_outputs = Result(sequences=[features['input_ids']])

        decode_output_list = decoder.single_schema_decode(text, offset_mapping, target_type, model_outputs, [], ori_input_ids, mode='seq2seq')

        for output in decode_output_list:
            # [('正向情感', '意见对象', '阿婴'), ('正向情感', '情感表达', '挺刺激')]
            # if len(output) >= 2:
            decoded_list.append(output)
    return decoded_list
    
def build_schema(task_dict, schema_dict_list):
    sentinel_token = task_dict['sentinel_token']
    sentinel_start_idx = task_dict['sentinel_start_idx']
    all_schema_dict = {}
    for schema_dict in schema_dict_list:
        if schema_dict['type'] not in all_schema_dict:
            all_schema_dict[schema_dict['type']] = {
                    'role2sentinel':{},
                    'sentinel2role':{},
                    'role2type':{},
                    'type2role':{}
            }
        for role_index, role_dict in enumerate(schema_dict['role_list']):
            role_type = role_dict['type'] + role_dict['role']
            all_schema_dict[schema_dict['type']]['role2sentinel'][role_type] = sentinel_token.format(role_index+sentinel_start_idx)
            all_schema_dict[schema_dict['type']]['sentinel2role'][sentinel_token.format(role_index+sentinel_start_idx)] = role_type
            all_schema_dict[schema_dict['type']]['role2type'][role_dict['role']] = role_type
            all_schema_dict[schema_dict['type']]['type2role'][role_type] = role_dict['role']
    return all_schema_dict

schema_mapping_dict = {
    '金融信息':'duee',
    '影视情感':'duie',
    '人生信息':'duie',
    '机构信息':'duie',
    '体育竞赛':'duee',
    '灾害意外':'duee'
}

doc_id_set = {}

with open('/data/albert.xht/m6_extraction/ccks_2022_m6_predict.json.txt.predict', 'w') as fwobj:
    with open('/data/albert.xht/m6_extraction/ccks_2022_m6_predict.json.txt', 'r') as frobj:
        for i, line in enumerate(frobj):
            content = line.strip().split('******&&&&&&&******')
            if i >= 1:
                original = json.loads(content[0])
                target = content[-1]
                if original['id'] not in doc_id_set:
                    doc_id_set[original['id']] = {
                        'id':original['id'],
                        'text':original['text'],
                        'schema_type':original['schema_type'],
                        'schema':original['schema'],
                        'target_type_tuple':[]
                    }
                doc_id_set[original['id']]['target_type_tuple'].append((original['target_schema_type'], target.split('@@')))

    with open('/data/albert.xht/unified_generation/duuie_test_a-1.json.result.cls', 'r') as frobj:
        for line in frobj:
            content = json.loads(line.strip())
            if content['id'] not in doc_id_set:
                tmp_dict = {
                    'id':content['id'],
                    'text':content['text'],
                    'schema_type':[],
                    'schema':content['schema'],
                    'target_type_tuple':[]
                }
                doc_id_set[content['id']] = tmp_dict
    for doc_id in doc_id_set:
        fwobj.write(json.dumps(doc_id_set[doc_id], ensure_ascii=False)+'\n')

print(len(doc_id_set))
                    
    
from functools import reduce
def deleteDuplicate_v1(input_dict_lst):
    f = lambda x,y:x if y in x else x + [y]
    return reduce(f, [[], ] + input_dict_lst)

from collections import Counter
sss = Counter()
                
with open('/data/albert.xht/unified_generation/duuie_test_a-1.json.result.m6', 'w') as fwobj: 
    with open('/data/albert.xht/m6_extraction/ccks_2022_m6_predict.json.txt.predict', 'r') as frobj:
        for line in frobj:
            content = json.loads(line.strip())
            schema_type = content['schema']
            if schema_mapping_dict[schema_type] == 'duie':
                task_dict = duie_task_dict
            elif schema_mapping_dict[schema_type] == 'duee':
                task_dict = duee_task_dict
            all_schema_dict = build_schema(task_dict, schema_dict_list)
            tmp_dict = {
                    'id':content['id'],
                    'entity': [],
                    'relation': [],
                    'event':[]
                }
            
            sss[content['id']] += 1
                
            
            if schema_mapping_dict[schema_type] == 'duie':
                for target_type, target_list in content['target_type_tuple']:
                    decoded_list = predict_seq2struct(content, target_type, target_list, task_dict, all_schema_dict)
                    for decoded in decoded_list:
                        """
                        [('正向情感', '意见对象', '阿婴'), ('正向情感', '情感表达', '挺刺激')]
                        """
                        if len(decoded) == 2:
                            sub_dict = {
                                'type':decoded[0][0],
                                'args':[
                                ]
                            }
                            for output in decoded:
                                sub_dict['args'].append({
                                    'type':str(output[1]),
                                    'text':str(output[2]),
                                })

                            tmp_dict['relation'].append(sub_dict)
                        else:
                            print(decoded, '====')
                tmp_dict['relation'] = deleteDuplicate_v1(tmp_dict['relation'])
                fwobj.write(json.dumps(tmp_dict, ensure_ascii=False)+'\n')
                
            elif schema_mapping_dict[schema_type] == 'duee':
                for target_type, target_list in content['target_type_tuple']:
                    decoded_list = predict_seq2struct(content, target_type, target_list, task_dict, all_schema_dict)
                    for decoded in decoded_list: 
                        """
                        [('夺冠', '触发词', '金牌'), ('夺冠', '时间', '今天上午'), ('夺冠', '冠军', '中谷爱凌'), ('夺冠', '夺冠赛事', '北京冬奥会自由式滑雪女子大跳台决赛')]
                        """
                        if decoded:
                            event_dict = {
                                    "type":decoded[0][0],
                                    'text':"",
                                    "args":[]

                                }
                            for item in decoded:
                                if item[1] == u'触发词':
                                    event_dict['text'] = str(item[2])
                                else:
                                    event_dict['args'].append({
                                        'type':str(item[1]),
                                        'text':str(item[2])
                                    })
                            tmp_dict['event'].append(event_dict)
                tmp_dict['event'] = deleteDuplicate_v1(tmp_dict['event'])
                fwobj.write(json.dumps(tmp_dict, ensure_ascii=False)+'\n')
                
print(len(sss))